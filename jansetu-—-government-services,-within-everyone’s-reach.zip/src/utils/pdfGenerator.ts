import { jsPDF } from 'jspdf';
import { PDFDocument, rgb, StandardFonts } from 'pdf-lib';
import { ServiceItem, RequiredDocument } from '../data/services';

export interface UploadedDocFile {
  docId: string;
  name: string;
  size: string;
  dataUrl: string;
  uploadedAt: string;
  isImage: boolean;
  pageCount?: number;
}

export interface CompiledPdfRecord {
  id: string;
  serviceId: string;
  serviceTitle: string;
  citizenName: string;
  fileName: string;
  fileSize: string;
  pageCount: number;
  dataUrl: string;
  timestamp: string;
  attachedDocsCount: number;
  portalName: string;
}

/**
 * Normalizes any raster image dataUrl into standard JPEG bytes for reliable PDF embedding
 */
function normalizeImageToJpgBytes(dataUrl: string): Promise<Uint8Array> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      const canvas = document.createElement('canvas');
      canvas.width = img.naturalWidth || img.width || 800;
      canvas.height = img.naturalHeight || img.height || 600;
      const ctx = canvas.getContext('2d');
      if (!ctx) {
        reject(new Error('Canvas context not available'));
        return;
      }
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.drawImage(img, 0, 0);
      const jpegDataUrl = canvas.toDataURL('image/jpeg', 0.92);
      const base64 = jpegDataUrl.split(',')[1];
      const binary = atob(base64);
      const bytes = new Uint8Array(binary.length);
      for (let i = 0; i < binary.length; i++) {
        bytes[i] = binary.charCodeAt(i);
      }
      resolve(bytes);
    };
    img.onerror = (e) => reject(e);
    img.src = dataUrl;
  });
}

/**
 * Extracts raw Uint8Array bytes from base64 dataUrl
 */
function dataUrlToBytes(dataUrl: string): Uint8Array {
  const base64Data = dataUrl.includes(',') ? dataUrl.split(',')[1] : dataUrl;
  const binaryString = atob(base64Data);
  const bytes = new Uint8Array(binaryString.length);
  for (let i = 0; i < binaryString.length; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

/**
 * Generates an official compiled dossier PDF:
 * 1. Creates an official cover page with citizen details, timestamp, target portal, and document index.
 * 2. Merges all actual pages from uploaded PDFs directly into the document.
 * 3. Embeds all uploaded images directly onto full-size A4 pages with official header stamps.
 */
export async function generateOfficialDossierPDF(
  service: ServiceItem,
  citizenName: string,
  uploadedDocs: Record<string, UploadedDocFile>,
  customDocsOrder?: RequiredDocument[]
): Promise<{ fileName: string; pageCount: number; dataUrl: string; fileSizeStr: string }> {
  const docsList = customDocsOrder && customDocsOrder.length > 0 ? customDocsOrder : service.requiredDocumentsOrder;

  // ==========================================
  // STEP 1: GENERATE OFFICIAL COVER PAGE (jsPDF)
  // ==========================================
  const coverPdf = new jsPDF('p', 'mm', 'a4');
  const pageWidth = coverPdf.internal.pageSize.getWidth();
  const pageHeight = coverPdf.internal.pageSize.getHeight();

  // Top header banner
  coverPdf.setFillColor(15, 23, 42); // Slate 900
  coverPdf.rect(0, 0, pageWidth, 42, 'F');

  // Accent line
  coverPdf.setFillColor(37, 99, 235); // Blue 600
  coverPdf.rect(0, 42, pageWidth, 2.5, 'F');

  // Title text
  coverPdf.setTextColor(255, 255, 255);
  coverPdf.setFont('helvetica', 'bold');
  coverPdf.setFontSize(14);
  coverPdf.text('JANSETU — CITIZEN APPLICATION DOSSIER', 14, 18);

  coverPdf.setFontSize(9);
  coverPdf.setFont('helvetica', 'normal');
  coverPdf.setTextColor(203, 213, 225);
  coverPdf.text('All supporting documents bundled in sequence required by the official portal', 14, 26);
  coverPdf.text(`Target Official Portal: ${service.portalName}`, 14, 34);

  // Service Details Card
  let y = 54;
  coverPdf.setDrawColor(226, 232, 240);
  coverPdf.setFillColor(248, 250, 252);
  coverPdf.roundedRect(14, y, pageWidth - 28, 42, 3, 3, 'FD');

  coverPdf.setTextColor(15, 23, 42);
  coverPdf.setFont('helvetica', 'bold');
  coverPdf.setFontSize(12.5);
  coverPdf.text(service.title, 20, y + 9.5);

  coverPdf.setFontSize(8.5);
  coverPdf.setFont('helvetica', 'normal');
  coverPdf.setTextColor(71, 85, 105);
  coverPdf.text(`Department: ${service.department}`, 20, y + 17);
  coverPdf.text(`Applicant Name / Reference: ${citizenName || 'Citizen Applicant'}`, 20, y + 24.5);
  coverPdf.text(`Official Fee: ${service.fee} | Processing SLA: ${service.processingDays}`, 20, y + 32);
  coverPdf.text(`Compilation Timestamp: ${new Date().toLocaleString()}`, 20, y + 39.5);

  // Document Index Table Header
  y += 50;
  coverPdf.setFont('helvetica', 'bold');
  coverPdf.setFontSize(10.5);
  coverPdf.setTextColor(15, 23, 42);
  coverPdf.text('ATTACHED DOCUMENTS INDEX & PORTAL SEQUENCE:', 14, y);

  y += 5.5;
  coverPdf.setFillColor(241, 245, 249);
  coverPdf.rect(14, y, pageWidth - 28, 7.5, 'F');
  coverPdf.setFontSize(8);
  coverPdf.setFont('helvetica', 'bold');
  coverPdf.setTextColor(51, 65, 85);
  coverPdf.text('SEQ', 18, y + 5);
  coverPdf.text('REQUIRED DOCUMENT NAME', 32, y + 5);
  coverPdf.text('STATUS', 138, y + 5);
  coverPdf.text('FILE ATTACHED', 165, y + 5);

  y += 7.5;
  coverPdf.setFont('helvetica', 'normal');

  docsList.forEach((reqDoc, idx) => {
    const uploaded = uploadedDocs[reqDoc.id];
    const isAttached = Boolean(uploaded);

    // Zebra striping
    if (idx % 2 === 1) {
      coverPdf.setFillColor(248, 250, 252);
      coverPdf.rect(14, y, pageWidth - 28, 8, 'F');
    }

    coverPdf.setTextColor(71, 85, 105);
    coverPdf.setFontSize(8);
    coverPdf.text(`#${idx + 1}`, 18, y + 5.5);

    coverPdf.setTextColor(15, 23, 42);
    coverPdf.text(reqDoc.name.substring(0, 52), 32, y + 5.5);

    if (isAttached) {
      coverPdf.setTextColor(16, 185, 129); // Emerald
      coverPdf.setFont('helvetica', 'bold');
      coverPdf.text('✓ Included in PDF', 138, y + 5.5);
      coverPdf.setFont('helvetica', 'normal');
      coverPdf.setTextColor(100, 116, 139);
      coverPdf.text((uploaded.name || 'File attached').substring(0, 18), 165, y + 5.5);
    } else {
      coverPdf.setTextColor(239, 68, 68); // Red
      coverPdf.text('— Pending', 138, y + 5.5);
      coverPdf.setTextColor(148, 163, 184);
      coverPdf.text('Not Uploaded', 165, y + 5.5);
    }

    y += 8;
  });

  // Precaution notice box on cover
  y += 6;
  coverPdf.setFillColor(254, 243, 199);
  coverPdf.setDrawColor(251, 191, 36);
  coverPdf.roundedRect(14, y, pageWidth - 28, 24, 2, 2, 'FD');

  coverPdf.setTextColor(146, 64, 14);
  coverPdf.setFont('helvetica', 'bold');
  coverPdf.setFontSize(8);
  coverPdf.text('OFFICIAL VERIFICATION NOTICE:', 18, y + 6);

  coverPdf.setFont('helvetica', 'normal');
  coverPdf.setFontSize(7.5);
  coverPdf.setTextColor(120, 53, 15);
  coverPdf.text('• All pages following this cover sheet contain the authentic full content of attached documents.', 18, y + 11.5);
  coverPdf.text('• Always carry original certificates to Grama/Ward Sachivalayam or MeeSeva for physical inspection.', 18, y + 16.5);
  coverPdf.text('• Never share OTPs or passwords. Submit this compiled dossier directly via the official portal.', 18, y + 21.5);

  // Footer on cover
  coverPdf.setFontSize(8);
  coverPdf.setTextColor(148, 163, 184);
  coverPdf.text('JanSetu — Andhra Pradesh Government Services Application Dossier', 14, pageHeight - 8);
  coverPdf.text('Cover Page', pageWidth - 30, pageHeight - 8);

  const coverBytes = coverPdf.output('arraybuffer');

  // ==========================================
  // STEP 2: LOAD INTO PDF-LIB & MERGE ACTUAL FILES
  // ==========================================
  const masterDoc = await PDFDocument.create();
  const coverDoc = await PDFDocument.load(coverBytes);
  const [coverPage] = await masterDoc.copyPages(coverDoc, [0]);
  masterDoc.addPage(coverPage);

  const helveticaFont = await masterDoc.embedFont(StandardFonts.Helvetica);
  const helveticaBold = await masterDoc.embedFont(StandardFonts.HelveticaBold);

  // Merge each uploaded document in proper order
  for (let i = 0; i < docsList.length; i++) {
    const reqDoc = docsList[i];
    const uploaded = uploadedDocs[reqDoc.id];
    if (!uploaded) continue;

    const isPdf =
      !uploaded.isImage &&
      (uploaded.dataUrl.startsWith('data:application/pdf') ||
        uploaded.name.toLowerCase().endsWith('.pdf'));

    if (isPdf) {
      // It is an actual PDF document: Copy all its real pages directly into masterDoc!
      try {
        const rawBytes = dataUrlToBytes(uploaded.dataUrl);
        const donorPdf = await PDFDocument.load(rawBytes, { ignoreEncryption: true });
        const pageIndices = donorPdf.getPageIndices();
        const copiedPages = await masterDoc.copyPages(donorPdf, pageIndices);

        for (let p = 0; p < copiedPages.length; p++) {
          const donorPage = copiedPages[p];
          masterDoc.addPage(donorPage);
        }
      } catch (err) {
        console.warn(`Could not merge PDF page for ${uploaded.name}:`, err);
        // Fallback: Create placeholder page for corrupted PDF
        const fallbackPage = masterDoc.addPage([595.28, 841.89]);
        fallbackPage.drawText(`DOCUMENT #${i + 1}: ${reqDoc.name.toUpperCase()}`, {
          x: 40,
          y: 800,
          size: 12,
          font: helveticaBold,
          color: rgb(0.06, 0.09, 0.16)
        });
        fallbackPage.drawText(`File: ${uploaded.name} (${uploaded.size})`, {
          x: 40,
          y: 780,
          size: 10,
          font: helveticaFont,
          color: rgb(0.2, 0.25, 0.3)
        });
      }
    } else {
      // It is an image (JPG, PNG, WebP): Embed actual image directly onto a full A4 page!
      try {
        const jpgBytes = await normalizeImageToJpgBytes(uploaded.dataUrl);
        const embeddedImage = await masterDoc.embedJpg(jpgBytes);

        // Standard A4 dimensions in points: 595.28 x 841.89
        const a4Width = 595.28;
        const a4Height = 841.89;
        const page = masterDoc.addPage([a4Width, a4Height]);

        // Draw top header band
        page.drawRectangle({
          x: 0,
          y: a4Height - 40,
          width: a4Width,
          height: 40,
          color: rgb(0.06, 0.09, 0.16)
        });
        page.drawRectangle({
          x: 0,
          y: a4Height - 43,
          width: a4Width,
          height: 3,
          color: rgb(0.15, 0.39, 0.92)
        });

        page.drawText(`DOCUMENT #${i + 1}: ${reqDoc.name.toUpperCase()}`, {
          x: 20,
          y: a4Height - 22,
          size: 10,
          font: helveticaBold,
          color: rgb(1, 1, 1)
        });
        page.drawText(`Category: ${reqDoc.type} | File: ${uploaded.name} (${uploaded.size})`, {
          x: 20,
          y: a4Height - 34,
          size: 7.5,
          font: helveticaFont,
          color: rgb(0.8, 0.85, 0.9)
        });

        // Compute aspect ratio scaling
        const imgDims = embeddedImage.scale(1);
        const margin = 20;
        const maxDisplayWidth = a4Width - margin * 2;
        const maxDisplayHeight = a4Height - 75; // Leave room for top banner and bottom footer

        const scale = Math.min(
          maxDisplayWidth / imgDims.width,
          maxDisplayHeight / imgDims.height,
          1 // Don't upscale tiny images beyond 100%
        );

        const renderWidth = imgDims.width * scale;
        const renderHeight = imgDims.height * scale;
        const renderX = margin + (maxDisplayWidth - renderWidth) / 2;
        const renderY = 25 + (maxDisplayHeight - renderHeight) / 2;

        page.drawImage(embeddedImage, {
          x: renderX,
          y: renderY,
          width: renderWidth,
          height: renderHeight
        });

        // Footer
        page.drawText(`JanSetu Official Dossier • Document #${i + 1}`, {
          x: margin,
          y: 12,
          size: 7.5,
          font: helveticaFont,
          color: rgb(0.5, 0.55, 0.6)
        });
      } catch (err) {
        console.warn(`Could not embed image for ${uploaded.name}:`, err);
      }
    }
  }

  // ==========================================
  // STEP 3: EXPORT, DOWNLOAD, AND RETURN
  // ==========================================
  const mergedPdfBytes = await masterDoc.save();
  const pageCount = masterDoc.getPageCount();

  // Create clean work-specific filename
  const cleanWork = service.shortName.replace(/[^a-zA-Z0-9]/g, '_');
  const cleanCitizen = (citizenName || '').trim().replace(/[^a-zA-Z0-9]/g, '_');
  const fileName = cleanCitizen
    ? `${cleanWork}_Application_Dossier_${cleanCitizen}.pdf`
    : `${cleanWork}_Official_Application_Dossier.pdf`;

  // Calculate file size string
  const totalSizeBytes = mergedPdfBytes.byteLength;
  const fileSizeStr =
    totalSizeBytes > 1024 * 1024
      ? `${(totalSizeBytes / (1024 * 1024)).toFixed(1)} MB`
      : `${Math.round(totalSizeBytes / 1024)} KB`;

  // Create blob and dataUrl
  const blob = new Blob([mergedPdfBytes.buffer as ArrayBuffer], { type: 'application/pdf' });
  const objectUrl = URL.createObjectURL(blob);

  // Trigger browser download
  const downloadLink = document.createElement('a');
  downloadLink.href = objectUrl;
  downloadLink.download = fileName;
  document.body.appendChild(downloadLink);
  downloadLink.click();
  document.body.removeChild(downloadLink);

  // Also convert to dataUrl for in-app preview storage
  const reader = new FileReader();
  const dataUrlPromise = new Promise<string>((resolve) => {
    reader.onloadend = () => {
      resolve(reader.result as string);
    };
    reader.readAsDataURL(blob);
  });
  const dataUrl = await dataUrlPromise;

  return { fileName, pageCount, dataUrl, fileSizeStr };
}
