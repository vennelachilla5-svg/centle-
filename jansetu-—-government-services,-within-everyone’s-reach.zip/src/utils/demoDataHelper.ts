import { UploadedDocFile } from './pdfGenerator';

/**
 * Creates a clean simulated document image data URL for instant demonstration
 */
function createSimulatedDocDataUrl(docTitle: string, docDetails: string, sealColor: string = '#1e3a8a'): string {
  const canvas = document.createElement('canvas');
  canvas.width = 600;
  canvas.height = 800;
  const ctx = canvas.getContext('2d');
  if (!ctx) return '';

  // Background
  ctx.fillStyle = '#fcfdfe';
  ctx.fillRect(0, 0, 600, 800);

  // Border
  ctx.strokeStyle = '#cbd5e1';
  ctx.lineWidth = 4;
  ctx.strokeRect(16, 16, 568, 768);

  // Inner security pattern border
  ctx.strokeStyle = '#e2e8f0';
  ctx.lineWidth = 1;
  ctx.strokeRect(26, 26, 548, 748);

  // Header band
  ctx.fillStyle = sealColor;
  ctx.fillRect(30, 30, 540, 60);

  // Header text
  ctx.fillStyle = '#ffffff';
  ctx.font = 'bold 16px sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText('GOVERNMENT OF ANDHRA PRADESH / CITIZEN SERVICES', 300, 65);

  // Document Title
  ctx.fillStyle = '#0f172a';
  ctx.font = 'bold 22px sans-serif';
  ctx.fillText(docTitle.toUpperCase(), 300, 140);

  // Subtitle
  ctx.fillStyle = '#64748b';
  ctx.font = '12px sans-serif';
  ctx.fillText('OFFICIAL DEMONSTRATION RECORD · VERIFIED DIGITAL COPY', 300, 165);

  // Decorative divider
  ctx.strokeStyle = '#e2e8f0';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(60, 185);
  ctx.lineTo(540, 185);
  ctx.stroke();

  // Document content details
  ctx.textAlign = 'left';
  ctx.fillStyle = '#1e293b';
  ctx.font = 'bold 14px monospace';

  const lines = docDetails.split('\n');
  let y = 220;
  for (const line of lines) {
    if (line.startsWith('---')) {
      ctx.strokeStyle = '#e2e8f0';
      ctx.beginPath();
      ctx.moveTo(60, y);
      ctx.lineTo(540, y);
      ctx.stroke();
      y += 20;
    } else {
      ctx.fillText(line, 60, y);
      y += 26;
    }
  }

  // Official Stamp simulation
  ctx.save();
  ctx.translate(430, 660);
  ctx.rotate(-0.15);
  ctx.strokeStyle = sealColor;
  ctx.lineWidth = 3;
  ctx.strokeRect(-80, -35, 160, 70);
  ctx.fillStyle = sealColor;
  ctx.font = 'bold 11px sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText('TAHSILDAR OFFICE', 0, -10);
  ctx.fillText('DIGITALLY SIGNED', 0, 10);
  ctx.fillText('REF: AP-2026-VERIFIED', 0, 25);
  ctx.restore();

  // Bottom barcode / verification bar
  ctx.fillStyle = '#f1f5f9';
  ctx.fillRect(30, 730, 540, 36);
  ctx.fillStyle = '#475569';
  ctx.font = '10px monospace';
  ctx.textAlign = 'center';
  ctx.fillText('BARCODE: ||||| | |||| ||||| || |||||| | ||||| | AP-SEVA-SECURE-2026', 300, 752);

  return canvas.toDataURL('image/jpeg', 0.85);
}

/**
 * Returns a realistic demo application documents package with:
 * 1. Aadhaar Card (Applicant: Ramesh Kumar)
 * 2. Secondary School SSC Marks Memo (Applicant: R. Kumar - INTENTIONAL INITIAL MISMATCH)
 * 3. Income Certificate (Annual Family Income: ₹1,80,000 - EXPIRING MARCH 31, 2026)
 * Note: Rice Card / Ration Card is intentionally omitted to trigger mandatory missing check!
 */
export function getDemoDocumentsPackage(serviceId: string): Record<string, UploadedDocFile> {
  const now = new Date().toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });

  const aadhaarData = createSimulatedDocDataUrl(
    'Unique Identification Authority of India (Aadhaar)',
    `APPLICANT NAME : RAMESH KUMAR\nDOB            : 15/08/2004 (15-Aug-2004)\nGENDER         : MALE\nFATHER'S NAME  : K. ANAND KUMAR\nADDRESS        : D.No 4-12, Main Road,\n                 Anakapalle, Visakhapatnam,\n                 Andhra Pradesh - 531001\n---\nAADHAAR NO     : XXXX-XXXX-4819\nVERIFICATION   : E-KYC BIOMETRICS MATCHED`,
    '#1e3a8a'
  );

  const sscMemoData = createSimulatedDocDataUrl(
    'Board of Secondary Education, Andhra Pradesh',
    `RECORD TYPE    : SSC (CLASS X) MARKS MEMORANDUM\nCANDIDATE NAME : R. KUMAR  [Notice: Initial instead of Full Name]\nFATHER'S NAME  : K. ANAND KUMAR\nMOTHER'S NAME  : K. LAKSHMI\nDATE OF BIRTH  : 15/08/2004\nROLL NUMBER    : 2004128941\nGPA OBTAINED   : 9.8 / 10.0 (GRADE A+)\n---\nINSTITUTION    : Z.P. HIGH SCHOOL, ANAKAPALLE\nPASSING YEAR   : MARCH 2020`,
    '#047857'
  );

  const incomeData = createSimulatedDocDataUrl(
    'MeeSeva Income Certificate',
    `REVENUE DIVISION : VISAKHAPATNAM / ANAKAPALLE MANDAL\nCERTIFICATE NO   : IC-AP-2025-883921\nAPPLICANT        : RAMESH KUMAR\nHEAD OF FAMILY   : K. ANAND KUMAR\nGROSS INCOME     : Rs. 1,80,000/- (ONE LAKH EIGHTY THOUSAND)\nCATEGORY         : B.C. (BACKWARD CLASS)\n---\nVALIDITY PERIOD  : 01-APR-2025 TO 31-MAR-2026\nISSUING AUTH     : TAHSILDAR, ANAKAPALLE MANDAL`,
    '#7c3aed'
  );

  const transferCertData = createSimulatedDocDataUrl(
    'College Study & Conduct Certificate',
    `INSTITUTION      : GAYATRI VIDYA PARISHAD COLLEGE OF ENGG\nSTUDENT NAME     : RAMESH KUMAR\nBRANCH / COURSE  : B.TECH (COMPUTER SCIENCE & ENGG)\nADMISSION YEAR   : 2023-2027 (CURRENT 2ND YEAR)\nROLL NUMBER      : 23071A0582\nBIOMETRIC ATTEND : 82.4% (QUALIFIES > 75% MANDATE)\n---\nTUITION FEE DUE  : Rs. 70,000/- PER ANNUM`,
    '#c2410c'
  );

  // Map into appropriate slots based on service
  if (serviceId === 'ap-caste-integrated') {
    return {
      'doc-caste-app-form': {
        docId: 'doc-caste-app-form',
        name: 'AP_Seva_Form1_Signed_Ramesh.pdf',
        size: '142 KB',
        dataUrl: transferCertData,
        uploadedAt: now,
        isImage: true,
        pageCount: 1
      },
      'doc-caste-aadhaar': {
        docId: 'doc-caste-aadhaar',
        name: 'Aadhaar_Card_RameshKumar.jpg',
        size: '184 KB',
        dataUrl: aadhaarData,
        uploadedAt: now,
        isImage: true,
        pageCount: 1
      },
      'doc-caste-ssc': {
        docId: 'doc-caste-ssc',
        name: 'SSC_Marks_Memo_R_Kumar.jpg',
        size: '215 KB',
        dataUrl: sscMemoData,
        uploadedAt: now,
        isImage: true,
        pageCount: 1
      }
      // 'doc-caste-ration-card' is intentionally omitted to demonstrate missing document detection!
    };
  }

  // Default fallback map
  return {
    'doc-aadhaar': {
      docId: 'doc-aadhaar',
      name: 'Aadhaar_Card_RameshKumar.jpg',
      size: '184 KB',
      dataUrl: aadhaarData,
      uploadedAt: now,
      isImage: true,
      pageCount: 1
    },
    'doc-income': {
      docId: 'doc-income',
      name: 'Income_Certificate_MeeSeva_2025.jpg',
      size: '198 KB',
      dataUrl: incomeData,
      uploadedAt: now,
      isImage: true,
      pageCount: 1
    },
    'doc-marks': {
      docId: 'doc-marks',
      name: 'SSC_Marks_Memo_R_Kumar.jpg',
      size: '215 KB',
      dataUrl: sscMemoData,
      uploadedAt: now,
      isImage: true,
      pageCount: 1
    }
  };
}
