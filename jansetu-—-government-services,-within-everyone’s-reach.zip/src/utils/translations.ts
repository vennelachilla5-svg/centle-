export interface UITranslations {
  // Navigation & Branding
  brand_title: string;
  brand_tagline: string;
  nav_studio: string;
  nav_radar: string;
  nav_dossiers: string;
  nav_portals: string;
  nav_tracker: string;
  how_it_works: string;
  ask_ai: string;
  
  // Controls & Actions
  load_demo: string;
  print_report: string;
  run_preflight: string;
  compile_pdf: string;
  compiling: string;
  launch_portal: string;
  back_to_schemes: string;
  view_details: string;
  search_schemes: string;
  search_portals: string;
  all_categories: string;
  category_scholarships: string;
  category_certificates: string;
  category_agriculture: string;
  category_social: string;
  category_identity: string;
  
  // Section Headers
  procedure_heading: string;
  procedure_subheading: string;
  eligibility_heading: string;
  precautions_heading: string;
  documents_heading: string;
  applicant_heading: string;
  audit_findings_heading: string;
  health_scorecard: string;
  
  // Field Labels
  applicant_name: string;
  date_of_birth: string;
  annual_income: string;
  mandatory: string;
  optional: string;
  attached: string;
  missing: string;
  needs_verification: string;
  attach_file: string;
  replace: string;
  remove: string;
  preview: string;
  view_guide: string;
  sla_time: string;
  official_fee: string;
  
  // Statuses
  ready_for_review: string;
  issues_to_fix: string;
  readiness_score: string;
}

export const UI_STRINGS: Record<'en' | 'te' | 'hi', UITranslations> = {
  en: {
    brand_title: 'JanSetu Preflight',
    brand_tagline: 'Catch the problem before the application.',
    nav_studio: 'Preflight Studio',
    nav_radar: 'Rule Change Radar',
    nav_dossiers: 'PDF Archive',
    nav_portals: 'Portals Directory',
    nav_tracker: 'Application Tracker',
    how_it_works: 'How It Works',
    ask_ai: 'Ask AI Counselor',
    load_demo: 'Load Demo Application',
    print_report: 'Print Report',
    run_preflight: 'Run Preflight Audit',
    compile_pdf: 'Compile Master PDF',
    compiling: 'Compiling PDF...',
    launch_portal: 'Launch Official Portal',
    back_to_schemes: '← Back to All Schemes',
    view_details: 'View Procedure & Preflight →',
    search_schemes: 'Search schemes (e.g. Caste, NMMS, Income, Vidya Deevena)...',
    search_portals: 'Search official government portals...',
    all_categories: 'All Schemes',
    category_scholarships: 'Scholarships',
    category_certificates: 'AP Certificates',
    category_agriculture: 'Agriculture & Farmer',
    category_social: 'Social Security',
    category_identity: 'Identity & Utilities',
    procedure_heading: 'Official Application Procedure & Scrutiny Flow',
    procedure_subheading: 'Official statutory steps from citizen application to revenue approval and certificate issuance.',
    eligibility_heading: 'Statutory Eligibility Criteria',
    precautions_heading: 'Anti-Rejection Precautions',
    documents_heading: 'Required Documents Checklist & Upload',
    applicant_heading: 'Applicant Profile Information',
    audit_findings_heading: 'Preflight Deterministic Scrutiny Findings',
    health_scorecard: 'Preflight Health',
    applicant_name: 'Applicant Full Name',
    date_of_birth: 'Date of Birth',
    annual_income: 'Annual Family Income (₹)',
    mandatory: 'Mandatory',
    optional: 'Optional',
    attached: 'Attached',
    missing: 'Missing',
    needs_verification: 'Needs Verification',
    attach_file: 'Choose File / Attach',
    replace: 'Replace',
    remove: 'Remove',
    preview: 'Preview',
    view_guide: 'View Guide',
    sla_time: 'SLA Turnaround',
    official_fee: 'Official Fee',
    ready_for_review: 'Ready for Review',
    issues_to_fix: 'Issues to Fix',
    readiness_score: 'Readiness Score'
  },
  te: {
    brand_title: 'జనసేతు ప్రిఫ్లైట్',
    brand_tagline: 'దరఖాస్తుకు ముందే లోపాలను సరిచూసుకోండి.',
    nav_studio: 'ప్రిఫ్లైట్ స్టూడియో',
    nav_radar: 'నిబంధనల మార్పు రాడార్',
    nav_dossiers: 'PDF ఆర్కైవ్',
    nav_portals: 'పోర్టల్స్ డైరెక్టరీ',
    nav_tracker: 'దరఖాస్తు ట్రాకర్',
    how_it_works: 'ఎలా పనిచేస్తుంది',
    ask_ai: 'AI సలహాదారు',
    load_demo: 'డెమో దరఖాస్తును లోడ్ చేయండి',
    print_report: 'రిపోర్ట్ ముద్రించండి',
    run_preflight: 'ప్రిఫ్లైట్ తనిఖీని ప్రారంభించండి',
    compile_pdf: 'మాస్టర్ PDF రూపొందించండి',
    compiling: 'PDF తయారవుతోంది...',
    launch_portal: 'అధికారిక పోర్టల్ తెరవండి',
    back_to_schemes: '← అన్ని పథకాల జాబితాకు వెళ్లండి',
    view_details: 'విధానం & ప్రిఫ్లైట్ చూడండి →',
    search_schemes: 'పథకాలను వెతకండి (ఉదా: కులం, ఆదాయం, విద్యా దీవెన)...',
    search_portals: 'అధికారిక ప్రభుత్వ పోర్టల్స్ వెతకండి...',
    all_categories: 'అన్ని పథకాలు',
    category_scholarships: 'స్కాలర్‌షిప్‌లు',
    category_certificates: 'ఏపీ సర్టిఫికెట్లు',
    category_agriculture: 'రైతు పథకాలు',
    category_social: 'సామాజిక భద్రత',
    category_identity: 'గుర్తింపు & సేవలు',
    procedure_heading: 'అధికారిక దరఖాస్తు విధానం & పరిశీలన క్రమం',
    procedure_subheading: 'దరఖాస్తు సమర్పణ నుండి రెవెన్యూ అధికారుల ఆమోదం మరియు సర్టిఫికేట్ జారీ వరకు అధికారిక దశలు.',
    eligibility_heading: 'అర్హత నిబంధనలు',
    precautions_heading: 'తిరస్కరణను నివారించే సూచనలు',
    documents_heading: 'తప్పనిసరి పత్రాల చెక్‌లిస్ట్ & అప్‌లోడ్',
    applicant_heading: 'దరఖాస్తుదారు సమాచారం',
    audit_findings_heading: 'ప్రిఫ్లైట్ పరిశీలన ఫలితాలు & ఆధారాలు',
    health_scorecard: 'ప్రిఫ్లైట్ హెల్త్ స్కోర్',
    applicant_name: 'దరఖాస్తుదారు పూర్తి పేరు',
    date_of_birth: 'పుట్టిన తేదీ',
    annual_income: 'కుటుంబ వార్షిక ఆదాయం (₹)',
    mandatory: 'తప్పనిసరి',
    optional: 'ఐచ్ఛికం',
    attached: 'అప్‌లోడ్ అయ్యింది',
    missing: 'లోపించింది',
    needs_verification: 'పరిశీలన అవసరం',
    attach_file: 'ఫైల్ ఎంచుకోండి / జతచేయండి',
    replace: 'మార్చండి',
    remove: 'తొలగించండి',
    preview: 'చూడండి',
    view_guide: 'గైడ్ చూడండి',
    sla_time: 'కాలపరిమితి (SLA)',
    official_fee: 'అధికారిక రుసుము',
    ready_for_review: 'సమీక్షకు సిద్ధంగా ఉంది',
    issues_to_fix: 'సవరించాల్సిన లోపాలు',
    readiness_score: 'సిద్ధత స్కోర్'
  },
  hi: {
    brand_title: 'जनसेतु प्रीफ़्लाइट',
    brand_tagline: 'आवेदन करने से पहले ही त्रुटियों को पकड़ें।',
    nav_studio: 'प्रीफ़्लाइट स्टूडियो',
    nav_radar: 'नियम परिवर्तन रडार',
    nav_dossiers: 'पीडीएफ़ संग्रह',
    nav_portals: 'पोर्टल निर्देशिका',
    nav_tracker: 'आवेदन ट्रैकर',
    how_it_works: 'यह कैसे काम करता है',
    ask_ai: 'एआई सलाहकार से पूछें',
    load_demo: 'डेमो आवेदन लोड करें',
    print_report: 'रिपोर्ट प्रिंट करें',
    run_preflight: 'प्रीफ़्लाइट ऑडिट चलाएं',
    compile_pdf: 'मास्टर पीडीएफ़ बनाएं',
    compiling: 'पीडीएफ़ तैयार हो रही है...',
    launch_portal: 'आधिकारिक पोर्टल खोलें',
    back_to_schemes: '← सभी योजनाओं पर वापस जाएं',
    view_details: 'प्रक्रिया और प्रीफ़्लाइट देखें →',
    search_schemes: 'योजनाएं खोजें (उदा. जाति, आय, छात्रवृत्ति, विद्या दीवेना)...',
    search_portals: 'आधिकारिक सरकारी पोर्टल खोजें...',
    all_categories: 'सभी योजनाएं',
    category_scholarships: 'छात्रवृत्तियां',
    category_certificates: 'प्रमाण पत्र सेवाएं',
    category_agriculture: 'कृषि एवं किसान योजनाएं',
    category_social: 'सामाजिक सुरक्षा',
    category_identity: 'पहचान एवं जनोपयोगी सेवाएं',
    procedure_heading: 'आधिकारिक आवेदन प्रक्रिया एवं जांच चरण',
    procedure_subheading: 'नागरिक आवेदन से लेकर राजस्व जांच और अंतिम प्रमाण पत्र/लाभ जारी होने तक के आधिकारिक चरण।',
    eligibility_heading: 'वैधानिक पात्रता मानदंड',
    precautions_heading: 'आवेदन अस्वीकृति से बचने के उपाय',
    documents_heading: 'आवश्यक दस्तावेजों की चेकलिस्ट एवं अपलोड',
    applicant_heading: 'आवेदक की व्यक्तिगत जानकारी',
    audit_findings_heading: 'प्रीफ़्लाइट जांच परिणाम एवं साक्ष्य',
    health_scorecard: 'प्रीफ़्लाइट स्वास्थ्य स्कोर',
    applicant_name: 'आवेदक का पूरा नाम',
    date_of_birth: 'जन्म तिथि',
    annual_income: 'वार्षिक पारिवारिक आय (₹)',
    mandatory: 'अनिवार्य',
    optional: 'वैकल्पिक',
    attached: 'संलग्न है',
    missing: 'अनुपलब्ध',
    needs_verification: 'सत्यापन आवश्यक',
    attach_file: 'फ़ाइल चुनें / अपलोड करें',
    replace: 'बदलें',
    remove: 'हटाएं',
    preview: 'देखें',
    view_guide: 'दिशानिर्देश देखें',
    sla_time: 'समय सीमा (SLA)',
    official_fee: 'सरकारी शुल्क',
    ready_for_review: 'समीक्षा के लिए तैयार',
    issues_to_fix: 'सुधार योग्य समस्याएं',
    readiness_score: 'तैयारी स्कोर'
  }
};

export interface ServiceHindiData {
  titleHi: string;
  departmentHi: string;
  descriptionHi: string;
  shortNameHi: string;
  procedureStepsHi: { labelHi: string; detailHi: string }[];
}

export const SERVICES_HINDI_DATA: Record<string, ServiceHindiData> = {
  'ap-caste-integrated': {
    titleHi: 'आंध्र प्रदेश एकीकृत प्रमाण पत्र (जाति, अधिवास और जन्म तिथि)',
    departmentHi: 'राजस्व विभाग, आंध्र प्रदेश सरकार',
    shortNameHi: 'जाति / एकीकृत प्रमाण पत्र',
    descriptionHi: 'शैक्षणिक प्रवेश, छात्रवृत्ति और सरकारी नौकरियों के लिए जाति, स्थानीय निवास और जन्म तिथि को प्रमाणित करने वाला संयुक्त प्रमाण पत्र।',
    procedureStepsHi: [
      {
        labelHi: 'अनिवार्य दस्तावेजों को क्रमबद्ध कर पीडीएफ डोजियर बनाएं',
        detailHi: 'तहसीलदार और ग्राम राजस्व अधिकारी (VRO) की जांच के लिए निर्धारित क्रम में रखें।'
      },
      {
        labelHi: 'दस्तावेजों की पूर्णता और लंबित प्रतियों की जांच करें',
        detailHi: 'पोर्टल पर जमा करने से पहले सुनिश्चित करें कि कोई भी अनिवार्य प्रमाण पत्र छूटा नहीं है।'
      },
      {
        labelHi: 'आधार कार्ड के साथ नाम और जन्म तिथि की वर्तनी (Spelling) मिलाएं',
        detailHi: 'विद्यालय रिकॉर्ड और आधार में अक्षरों की वर्तनी बिल्कुल समान होनी चाहिए।'
      },
      {
        labelHi: 'आधार ओटीपी ई-केवाईसी के लिए सक्रिय मोबाइल नंबर तैयार रखें',
        detailHi: 'डिजिटल हस्ताक्षर और बायोमेट्रिक सत्यापन के लिए ओटीपी आवश्यक है।'
      },
      {
        labelHi: 'एपी सेवा पोर्टल पर आवेदन जमा करें और टोकन नंबर सुरक्षित करें',
        detailHi: 'आधिकारिक पोर्टल खोलें, डोजियर अपलोड करें और टोकन नंबर से स्थिति ट्रैक करें।'
      }
    ]
  },
  'ap-income-certificate': {
    titleHi: 'आंध्र प्रदेश वार्षिक आय प्रमाण पत्र',
    departmentHi: 'राजस्व विभाग, आंध्र प्रदेश सरकार',
    shortNameHi: 'आय प्रमाण पत्र',
    descriptionHi: 'छात्रवृत्ति, कॉलेज शुल्क प्रतिपूर्ति और सरकारी कल्याणकारी योजनाओं के लिए वार्षिक पारिवारिक आय का राजस्व प्रमाण पत्र।',
    procedureStepsHi: [
      {
        labelHi: 'आय और पारिवारिक प्रमाणों को पीडीएफ डोजियर में संकलित करें',
        detailHi: 'राजस्व निरीक्षक और तहसीलदार द्वारा डेस्क समीक्षा हेतु आधिकारिक प्रारूप।'
      },
      {
        labelHi: 'वेतन पर्ची अथवा नोटरी आय हलफनामे की वैधता जांचें',
        detailHi: 'चालू वित्तीय वर्ष का वैध आय साक्ष्य संलग्न करें।'
      },
      {
        labelHi: 'राइस कार्ड और आधार विवरण का मिलान करें',
        detailHi: 'परिवार के सभी सदस्यों के नाम राशन कार्ड से मेल खाने चाहिए।'
      },
      {
        labelHi: 'सचिवालय / मीसेवा पर आधार ओटीपी सत्यापन पूरा करें',
        detailHi: 'नागरिक पोर्टल पर त्वरित डिजिटल ई-केवाईसी।'
      },
      {
        labelHi: 'मीसेवा पोर्टल पर आवेदन जमा कर पावती रसीद लें',
        detailHi: '7 कार्य दिवसों में तहसीलदार के डिजिटल हस्ताक्षर के साथ प्रमाण पत्र जारी होता है।'
      }
    ]
  },
  'ap-rice-card': {
    titleHi: 'एपी नया राइस कार्ड / परिवार राशन कार्ड सेवा',
    departmentHi: 'नागरिक आपूर्ति एवं उपभोक्ता मामले विभाग, आंध्र प्रदेश',
    shortNameHi: 'राइस कार्ड',
    descriptionHi: 'रियायती खाद्यान्न और आंध्र प्रदेश की नवरत्नालु योजनाओं की पात्रता के लिए परिवार राशन कार्ड।',
    procedureStepsHi: [
      {
        labelHi: 'सभी सदस्यों के आधार और महिला मुखिया की बैंक पासबुक संकलित करें',
        detailHi: 'ग्राम/वार्ड सचिवालय के सत्यापन हेतु तैयार करें।'
      },
      {
        labelHi: 'परिवार के सदस्यों का जनसांख्यिकी डेटा सत्यापित करें',
        detailHi: 'सुनिश्चित करें कि किसी सदस्य का नाम दूसरे राशन कार्ड में दर्ज न हो।'
      },
      {
        labelHi: 'सचिवालय स्वयंसेवक द्वारा घर-घर सत्यापन पूरा करें',
        detailHi: 'स्थानीय स्वयंसेवक भौतिक सत्यापन रिपोर्ट सबमिट करता है।'
      },
      {
        labelHi: 'नागरिक आपूर्ति पोर्टल पर अंतिम अनुमोदन प्राप्त करें',
        detailHi: 'नया राइस कार्ड डिजिटल रूप से सक्रिय होकर जारी किया जाता है।'
      }
    ]
  },
  'ap-birth-certificate': {
    titleHi: 'जन्म प्रमाण पत्र (मीसेवा एवं नगर निगम)',
    departmentHi: 'स्वास्थ्य एवं परिवार कल्याण / नगर निगम प्रशासन',
    shortNameHi: 'जन्म प्रमाण पत्र',
    descriptionHi: 'स्कूल प्रवेश, पासपोर्ट और नागरिक अधिकारों के लिए आधिकारिक जन्म पंजीकरण प्रमाण पत्र।',
    procedureStepsHi: [
      {
        labelHi: 'अस्पताल डिस्चार्ज समरी और माता-पिता के पहचान पत्र संकलित करें',
        detailHi: 'संबंधित नगर निगम अथवा ग्राम पंचायत रिकॉर्ड के लिए आवश्यक।'
      },
      {
        labelHi: 'जन्म तिथि और बच्चे के नाम की वर्तनी की जांच करें',
        detailHi: 'बाद में सुधार से बचने के लिए प्रारंभिक चरण में ही सही वर्तनी दर्ज करें।'
      },
      {
        labelHi: 'सचिवालय अथवा मीसेवा केंद्र पर आवेदन प्रस्तुत करें',
        detailHi: 'जन्म एवं मृत्यु रजिस्ट्रार द्वारा सत्यापन किया जाता है।'
      },
      {
        labelHi: 'डिजिटल रूप से हस्ताक्षरित जन्म प्रमाण पत्र डाउनलोड करें',
        detailHi: 'क्यूआर कोड युक्त कानूनी प्रमाण पत्र ऑनलाइन प्राप्त करें।'
      }
    ]
  },
  'ap-ews-certificate': {
    titleHi: 'आर्थिक रूप से कमजोर वर्ग (EWS) 10% आरक्षण प्रमाण पत्र',
    departmentHi: 'राजस्व विभाग, आंध्र प्रदेश सरकार',
    shortNameHi: 'ईडब्ल्यूएस प्रमाण पत्र',
    descriptionHi: 'केंद्र और राज्य सरकार के उच्च शिक्षण संस्थानों और नौकरियों में 10% आरक्षण के लिए ईडब्ल्यूएस प्रमाण पत्र।',
    procedureStepsHi: [
      {
        labelHi: 'परिवार की कुल आय, कृषि भूमि और आवासीय संपत्ति के दस्तावेज तैयार करें',
        detailHi: 'वार्षिक आय ₹8 लाख से कम और आवासीय भूखंड सीमा के अनुसार होना अनिवार्य है।'
      },
      {
        labelHi: 'सभी परिवारिक सदस्यों के आधार और संपत्ति विवरण की जांच करें',
        detailHi: 'राजस्व निरीक्षक द्वारा भूमि रिकॉर्ड वेबलैंड से सत्यापित किए जाते हैं।'
      },
      {
        labelHi: 'तहसीलदार कार्यालय द्वारा फील्ड जांच पूरी कराएं',
        detailHi: 'वीआरओ और आरआई द्वारा स्थलीय निरीक्षण किया जाता है।'
      },
      {
        labelHi: 'मीसेवा से डिजिटल रूप से हस्ताक्षरित ईडब्ल्यूएस प्रमाण पत्र प्राप्त करें',
        detailHi: 'चालू वित्तीय वर्ष की प्रवेश परीक्षाओं के लिए मान्य।'
      }
    ]
  },
  'ap-residence-certificate': {
    titleHi: 'आंध्र प्रदेश निवास / अधिवास प्रमाण पत्र',
    departmentHi: 'राजस्व विभाग, आंध्र प्रदेश सरकार',
    shortNameHi: 'निवास प्रमाण पत्र',
    descriptionHi: 'राज्य में 7 वर्ष अथवा निरंतर निवास को प्रमाणित करने वाला आधिकारिक राजस्व दस्तावेज।',
    procedureStepsHi: [
      {
        labelHi: 'आधार कार्ड, बिजली बिल और निरंतर अध्ययन प्रमाण पत्र जोड़ें',
        detailHi: 'राज्य में वास्तविक निवास सिद्ध करने वाले प्रमाण।'
      },
      {
        labelHi: 'तहसीलदार कार्यालय द्वारा निवास अवधि का सत्यापन कराएं',
        detailHi: 'ग्राम राजस्व अधिकारी द्वारा स्थानीय जांच रिपोर्ट दर्ज की जाती है।'
      },
      {
        labelHi: 'मीसेवा पोर्टल से डिजिटल प्रमाण पत्र डाउनलोड करें',
        detailHi: 'कौंसलिंग और सरकारी नौकरियों में स्थानीय कोटे हेतु प्रस्तुत करें।'
      }
    ]
  },
  'ap-vidya-deevena': {
    titleHi: 'जगन्ना विद्या दीवेना (आईटीआई, पॉलिटेक्निक, डिग्री शुल्क प्रतिपूर्ति)',
    departmentHi: 'उच्च शिक्षा एवं समाज कल्याण विभाग, आंध्र प्रदेश',
    shortNameHi: 'विद्या दीवेना छात्रवृत्ति',
    descriptionHi: 'पॉलीटेक्निक, आईटीआई, इंजीनियरिंग और डिग्री के छात्रों के लिए 100% कॉलेज ट्यूशन फीस प्रतिपूर्ति योजना।',
    procedureStepsHi: [
      {
        labelHi: 'छात्र आधार, आय प्रमाण पत्र, जाति प्रमाण पत्र और माता का बैंक खाता जोड़ें',
        detailHi: 'छात्रवृत्ति की राशि सीधे माता के आधार से जुड़े बैंक खाते में अंतरित होती है।'
      },
      {
        labelHi: 'कॉलेज प्राचार्य द्वारा बायोमेट्रिक सत्यापन और ज्ञानभूमि उपस्थिति जांचें',
        detailHi: 'न्यूनतम 75% कॉलेज उपस्थिति अनिवार्य है।'
      },
      {
        labelHi: 'ग्राम/वार्ड कल्याण सहायक (WEDPS) द्वारा 6-चरणीय सामाजिक जांच पूरी कराएं',
        detailHi: 'चार पहिया वाहन, बिजली खपत और भूमि सीमा की सरकारी जांच।'
      },
      {
        labelHi: 'ज्ञानभूमि पोर्टल पर त्रैमासिक फीस प्रतिपूर्ति प्राप्त करें',
        detailHi: 'ट्यूशन फीस का प्रत्यक्ष लाभ अंतरण (DBT) सुनिश्चित करें।'
      }
    ]
  },
  'ap-nmms-scholarship': {
    titleHi: 'राष्ट्रीय साधन-सह-योग्यता छात्रवृत्ति (NMMS कक्षा 9 से 12)',
    departmentHi: 'स्कूल शिक्षा विभाग एवं सरकारी परीक्षा निदेशालय (DGE AP)',
    shortNameHi: 'एनएमएमएस छात्रवृत्ति',
    descriptionHi: 'कक्षा 8 उत्तीर्ण मेधावी आर्थिक रूप से कमजोर छात्रों को कक्षा 9 से 12 तक ₹12,000 प्रति वर्ष की छात्रवृत्ति।',
    procedureStepsHi: [
      {
        labelHi: 'कक्षा 7 के न्यूनतम 55% अंक और ₹3,50,000 से कम का आय प्रमाण पत्र संलग्न करें',
        detailHi: 'केवल सरकारी एवं सहायता प्राप्त स्कूलों के नियमित छात्र पात्र हैं।'
      },
      {
        labelHi: 'छात्र के नाम से खुले व्यक्तिगत बचत बैंक खाते को एनपीसीआई से मैप कराएं',
        detailHi: 'डीबीटी छात्रवृत्ति भुगतान के लिए आधार सीडिंग आवश्यक है।'
      },
      {
        labelHi: 'स्कूल हेडमास्टर द्वारा ऑनलाइन एनएमएमएस पोर्टल पर सत्यापन कराएं',
        detailHi: 'डीजीई आंध्र प्रदेश द्वारा जारी हॉल टिकट से राज्य स्तरीय परीक्षा दें।'
      },
      {
        labelHi: 'चयन के बाद राष्ट्रीय छात्रवृत्ति पोर्टल (NSP) पर पंजीकरण पूरा करें',
        detailHi: 'प्रति वर्ष ₹12,000 की छात्रवृत्ति सीधे खाते में प्राप्त करें।'
      }
    ]
  },
  'central-nsp-scholarship': {
    titleHi: 'राष्ट्रीय छात्रवृत्ति पोर्टल (NSP केंद्रीय पोस्ट-मैट्रिक एवं मेरिट)',
    departmentHi: 'शिक्षा मंत्रालय एवं सामाजिक न्याय मंत्रालय, भारत सरकार',
    shortNameHi: 'केंद्रीय एनएसपी छात्रवृत्ति',
    descriptionHi: 'अल्पसंख्यक, एससी, एसटी, ओबीसी और उच्च शिक्षा के छात्रों के लिए केंद्र सरकार की राष्ट्रीय छात्रवृत्ति योजनाएं।',
    procedureStepsHi: [
      {
        labelHi: 'बोनाफाइड कॉलेज प्रमाण पत्र, पिछली अंकतालिका और वार्षिक आय प्रमाण पत्र जोड़ें',
        detailHi: 'एनएसपी पोर्टल पर ओट्रपी (OTR) पंजीकरण हेतु आवश्यक।'
      },
      {
        labelHi: 'बैंक खाते को एनपीसीआई आधार सीडिंग से सत्यापित करें',
        detailHi: 'खाते में आधार सक्रिय न होने पर भुगतान असफल हो जाता है।'
      },
      {
        labelHi: 'कॉलेज नोडल अधिकारी (INO) और जिला नोडल अधिकारी (DNO) से सत्यापन कराएं',
        detailHi: 'संस्थान स्तर पर मूल दस्तावेजों की जांच की जाती है।'
      },
      {
        labelHi: 'डीएफएमएस / डीबीटी द्वारा खाते में छात्रवृत्ति का सीधा अंतरण प्राप्त करें',
        detailHi: 'scholarships.gov.in पर लाइव स्थिति ट्रैक करें।'
      }
    ]
  },
  'ap-sadarem-udid': {
    titleHi: 'सदरम दिव्यांगता प्रमाण पत्र एवं राष्ट्रीय यूडीआईडी कार्ड',
    departmentHi: 'दिव्यांगजन सशक्तिकरण एवं स्वास्थ्य विभाग, आंध्र प्रदेश',
    shortNameHi: 'सदरम / यूडीआईडी कार्ड',
    descriptionHi: 'दिव्यांगता पेंशन, बस पास और आरक्षण लाभों के लिए सरकारी मेडिकल बोर्ड द्वारा मूल्यांकित दिव्यांगता प्रमाण पत्र।',
    procedureStepsHi: [
      {
        labelHi: 'आधार कार्ड और दिव्यांगता की स्पष्ट रंगीन तस्वीर तैयार करें',
        detailHi: 'पूर्व के मेडिकल पर्चे और अस्पताल के रिकॉर्ड साथ रखें।'
      },
      {
        labelHi: 'मीसेवा या ग्राम सचिवालय के माध्यम से मेडिकल बोर्ड स्लॉट बुक करें',
        detailHi: 'जिला सरकारी अस्पताल में उपस्थित होने का समय और तारीख चुनें।'
      },
      {
        labelHi: 'सरकारी डॉक्टरों के मेडिकल बोर्ड द्वारा जांच पूरी कराएं',
        detailHi: 'दिव्यांगता के प्रतिशत का वैज्ञानिक आकलन किया जाता है।'
      },
      {
        labelHi: 'स्वावलंबन पोर्टल से राष्ट्रीय यूडीआईडी स्मार्ट कार्ड डाउनलोड करें',
        detailHi: 'पेंशन और रेलवे/बस रियायतों के लिए मान्य।'
      }
    ]
  },
  'pm-kisan': {
    titleHi: 'पीएम-किसान सम्मान निधि (प्रति वर्ष ₹6,000 किसान सहायता)',
    departmentHi: 'कृषि एवं किसान कल्याण मंत्रालय, भारत सरकार',
    shortNameHi: 'पीएम किसान योजना',
    descriptionHi: 'भूमिधारक किसान परिवारों को प्रति वर्ष ₹6,000 की वित्तीय सहायता (₹2,000 की तीन समान किस्तों में)।',
    procedureStepsHi: [
      {
        labelHi: 'किसान आधार, वेबलैंड 2.0 खतियान (RoR 1B) और बैंक पासबुक जोड़ें',
        detailHi: 'कृषि योग्य भूमि का स्वामित्व प्रमाणित होना चाहिए।'
      },
      {
        labelHi: 'पीएम-किसान पोर्टल पर चेहरे अथवा ओटीपी से ई-केवाईसी पूरी करें',
        detailHi: 'बिना ई-केवाईसी के आगामी किस्तों का भुगतान रोक दिया जाता है।'
      },
      {
        labelHi: 'कृषि अधिकारी द्वारा भू-अभिलेखों (Land Seeding) का सत्यापन कराएं',
        detailHi: 'ग्राम कृषि सहायक (VAA) द्वारा रिपोर्ट सबमिट की जाती है।'
      },
      {
        labelHi: 'आधार से जुड़े बैंक खाते में किस्त सीधे प्राप्त करें',
        detailHi: 'pmkisan.gov.in पर लाभार्थी स्थिति जांचें।'
      }
    ]
  },
  'ayushman-bharat': {
    titleHi: 'आयुष्मान भारत — पीएमजेएवाई / वाईएसआर आरोग्यश्री स्वास्थ्य कार्ड',
    departmentHi: 'राष्ट्रीय स्वास्थ्य प्राधिकरण एवं डॉ वाईएसआर आरोग्यश्री हेल्थ केयर ट्रस्ट',
    shortNameHi: 'आयुष्मान आरोग्य कार्ड',
    descriptionHi: 'गरीब और कमजोर परिवारों के लिए प्रति वर्ष ₹5,00,000 तक का कैशलेस अस्पताल उपचार कवर।',
    procedureStepsHi: [
      {
        labelHi: 'परिवार का राइस कार्ड और सभी सदस्यों के आधार कार्ड तैयार करें',
        detailHi: 'सूचीबद्ध सरकारी एवं निजी अस्पतालों में भर्ती के समय आवश्यक।'
      },
      {
        labelHi: 'अस्पताल के आरोग्यमित्र अथवा सचिवालय में बायोमेट्रिक ई-केवाईसी कराएं',
        detailHi: 'त्वरित पात्रता सत्यापन और आयुष्मान कार्ड का सृजन।'
      },
      {
        labelHi: 'नेटवर्क अस्पताल में ₹5 लाख तक का कैशलेस इलाज प्राप्त करें',
        detailHi: 'सर्जरी, दवाएं और अस्पताल का खर्च योजना द्वारा वहन किया जाता है।'
      }
    ]
  },
  'aadhaar-enrolment-update': {
    titleHi: 'आधार नामांकन एवं जनसांख्यिकी/बायोमेट्रिक अपडेट',
    departmentHi: 'भारतीय विशिष्ट पहचान प्राधिकरण (UIDAI)',
    shortNameHi: 'आधार सेवा केंद्र',
    descriptionHi: 'आधार कार्ड में नाम, जन्म तिथि, पता सुधार और 10-वर्षीय अनिवार्य पहचान/पते का नवीनीकरण।',
    procedureStepsHi: [
      {
        labelHi: 'मान्य पहचान प्रमाण (POI) और पता प्रमाण (POA) दस्तावेज जोड़ें',
        detailHi: 'यूआईडीएआई की आधिकारिक 2026 स्वीकृत सूची के अनुसार दस्तावेज।'
      },
      {
        labelHi: 'myaadhaar.uidai.gov.in पर ऑनलाइन या आधार सेवा केंद्र पर स्लॉट बुक करें',
        detailHi: 'बायोमेट्रिक (उंगलियों के निशान और आईरिस) अपडेट कराएं।'
      },
      {
        labelHi: 'URN नंबर से अपडेट स्थिति ट्रैक करें और ई-आधार डाउनलोड करें',
        detailHi: 'अद्यतन आधार डिजिटल रूप से तुरंत मान्य हो जाता है।'
      }
    ]
  },
  'eshram-card': {
    titleHi: 'ई-श्रम कार्ड (असंगठित कामगार राष्ट्रीय डेटाबेस)',
    departmentHi: 'श्रम एवं रोजगार मंत्रालय, भारत सरकार',
    shortNameHi: 'ई-श्रम कार्ड (UAN)',
    descriptionHi: 'असंगठित क्षेत्र के श्रमिकों (कृषि, निर्माण, गिग वर्कर्स) के लिए ₹2,00,000 के दुर्घटना बीमा युक्त 12-अंकीय पहचान कार्ड।',
    procedureStepsHi: [
      {
        labelHi: 'सक्रिय मोबाइल लिंक आधार और बैंक पासबुक संकलित करें',
        detailHi: 'पोर्टल पर प्रत्यक्ष पंजीकरण हेतु आवश्यक।'
      },
      {
        labelHi: 'व्यवसाय कोड (NCO Code) चुनें और ओटीपी से स्व-पंजीकरण करें',
        detailHi: 'eshram.gov.in पर 100% नि:शुल्क पंजीकरण।'
      },
      {
        labelHi: '12-अंकीय यूएएन स्मार्ट कार्ड तुरंत डाउनलोड करें',
        detailHi: 'प्रधानमंत्री सुरक्षा बीमा योजना (PMSBY) दुर्घटना कवर सक्रिय होता है।'
      }
    ]
  },
  'ap-spandana-grievance': {
    titleHi: 'स्पंदना लोक शिकायत निवारण प्रणाली (कलेक्टर जनसुनवाई)',
    departmentHi: 'सार्वजनिक शिकायत एवं मुख्यमंत्री कार्यालय (CMO AP)',
    shortNameHi: 'स्पंदना शिकायत निवारण',
    descriptionHi: 'प्रशासनिक देरी, राशन कार्ड, भूमि विवाद या प्रमाण पत्र अस्वीकृति के खिलाफ समयबद्ध आधिकारिक शिकायत दर्ज करें।',
    procedureStepsHi: [
      {
      }
    ]
  },
  'ap-ssc-duplicate-memo': {
    titleHi: 'आंध्र प्रदेश एसएससी (10वीं) डुप्लीकेट अंकतालिका / माइग्रेशन',
    departmentHi: 'सरकारी परीक्षा निदेशालय (DGE AP), आंध्र प्रदेश',
    shortNameHi: 'एसएससी 10वीं डुप्लीकेट मेमो',
    descriptionHi: 'खोई या क्षतिग्रस्त कक्षा 10 (एसएससी) बोर्ड परीक्षा की मूल अंकतालिका के स्थान पर आधिकारिक डुप्लीकेट प्रमाण पत्र जारी करने की सेवा।',
    procedureStepsHi: [
      {
        labelHi: 'पुलिस गैर-अनुरेखणीय (Non-Traceable) प्रमाण पत्र और स्कूल हलफनामा संलग्न करें',
        detailHi: 'थाने की गैर-प्राप्ति रिपोर्ट और हेडमास्टर का हस्ताक्षरित पत्र आवश्यक है।'
      },
      {
        labelHi: 'सीएफएमएस ट्रेजरी चालान (₹250) ऑनलाइन भुगतान रसीद जोड़ें',
        detailHi: 'आधिकारिक ट्रेजरी हेड पर निर्धारित बोर्ड शुल्क का चालान।'
      },
      {
        labelHi: 'डीजीई आंध्र प्रदेश पोर्टल पर ऑनलाइन आवेदन या हेडमास्टर प्रतिहस्ताक्षर कराएं',
        detailHi: 'विद्यालय रिकॉर्ड से मूल हॉल टिकट नंबर और उत्तीर्ण वर्ष की पुष्टि।'
      },
      {
        labelHi: 'पंजीकृत डाक द्वारा या डीजीई कार्यालय से सीधे डुप्लीकेट अंकतालिका प्राप्त करें',
        detailHi: 'सरकारी और उच्च शिक्षा के सत्यापन के लिए 100% मान्य।'
      }
    ]
  },
  'ap-inter-memo-migration': {
    titleHi: 'एपी इंटरमीडिएट डुप्लीकेट मार्क्स मेमो एवं माइग्रेशन प्रमाण पत्र',
    departmentHi: 'इंटरमीडिएट शिक्षा बोर्ड (BIEAP), आंध्र प्रदेश',
    shortNameHi: 'इंटरमीडिएट मेमो / माइग्रेशन',
    descriptionHi: 'उच्च शिक्षा और विदेशी विश्वविद्यालय प्रवेश के लिए 12वीं (इंटरमीडिएट) बोर्ड परीक्षा की डुप्लीकेट मार्कशीट या माइग्रेशन प्रमाण पत्र।',
    procedureStepsHi: [
      {
        labelHi: 'इंटर हॉल टिकट नंबर, कॉलेज प्राचार्य अनापत्ति (NOC) और पुलिस शिकायत संलग्न करें',
        detailHi: 'मूल प्रमाण पत्र खोने या फटने के प्रमाण पत्र प्रस्तुत करें।'
      },
      {
        labelHi: 'बीआईईएपी सेवा पोर्टल (bie.ap.gov.in) पर निर्धारित यूजर शुल्क का भुगतान करें',
        detailHi: 'ऑनलाइन चालान जनरेट कर नेट बैंकिंग या यूपीआई से भुगतान करें।'
      },
      {
        labelHi: 'कॉलेज रिकॉर्ड से नाम और जन्म तिथि का सत्यापन कराएं',
        detailHi: 'प्राचार्य द्वारा बोर्ड को ऑनलाइन संस्तुति भेजी जाती है।'
      },
      {
        labelHi: 'डिजिटल रूप से हस्ताक्षरित माइग्रेशन प्रमाण पत्र और डुप्लीकेट मेमो प्राप्त करें',
        detailHi: 'बोर्ड से अधिकृत डिजिटल बारकोड युक्त प्रमाण पत्र जारी होता है।'
      }
    ]
  },
  'voter-id-epic': {
    titleHi: 'मतदाता पहचान पत्र (Voter ID / EPIC) नया पंजीकरण एवं संशोधन',
    departmentHi: 'भारत निर्वाचन आयोग (ECI)',
    shortNameHi: 'वोटर आईडी कार्ड (EPIC)',
    descriptionHi: '18 वर्ष पूर्ण होने पर नया मतदाता पहचान पत्र (फॉर्म 6), पता परिवर्तन (फॉर्म 8) या ई-एपिक डाउनलोड।',
    procedureStepsHi: [
      {
        labelHi: 'रंगीन पासपोर्ट फोटो, आयु प्रमाण (10वीं/आधार) और निवास प्रमाण जोड़ें',
        detailHi: 'निर्वाचक रजिस्ट्रीकरण अधिकारी (ERO) के परीक्षण हेतु दस्तावेज।'
      },
      {
        labelHi: 'voters.eci.gov.in पर फॉर्म 6 (नया) अथवा फॉर्म 8 (सुधार) ऑनलाइन भरें',
        detailHi: 'विधानसभा क्षेत्र और मतदान केंद्र का सही चयन करें।'
      },
      {
        labelHi: 'बूथ स्तर के अधिकारी (BLO) द्वारा घर पर भौतिक सत्यापन कराएं',
        detailHi: 'बीएलओ द्वारा स्थानीय निवास और पारिवारिक सदस्यों की जांच की जाती है।'
      },
      {
        labelHi: 'डिजिटल ई-एपिक (e-EPIC) डाउनलोड करें और स्पीड पोस्ट से प्लास्टिक कार्ड प्राप्त करें',
        detailHi: 'राष्ट्रीय मतदाता दिवस या आगामी चुनाव में मतदान हेतु पूर्ण मान्य।'
      }
    ]
  },
  'pan-card-services': {
    titleHi: 'पैन कार्ड सेवा (नया 49A / सुधार / आधार-पैन लिंकिंग)',
    departmentHi: 'आयकर विभाग, वित्त मंत्रालय, भारत सरकार',
    shortNameHi: 'पैन कार्ड (PAN 49A)',
    descriptionHi: 'बैंकिंग, आयकर रिटर्न और वित्तीय लेनदेन के लिए 10-अंकीय स्थायी खाता संख्या (PAN) कार्ड सेवा।',
    procedureStepsHi: [
      {
        labelHi: 'आधार कार्ड, हालिया पासपोर्ट फोटो और डिजिटल हस्ताक्षर तैयार रखें',
        detailHi: 'पहचान, जन्म तिथि और पते के एकमात्र प्रमाण के रूप में आधार मान्य।'
      },
      {
        labelHi: 'प्रोटीन (NSDL) या यूटीआईआईटीएसएल (UTIITSL) पोर्टल पर फॉर्म 49A भरें',
        detailHi: 'पिता का नाम और जन्म तिथि आधार के अनुसार ही भरें।'
      },
      {
        labelHi: 'आधार ओटीपी द्वारा पेपरलेस ई-केवाईसी और ई-साइन पूर्ण करें',
        detailHi: 'बिना किसी भौतिक दस्तावेज को डाक से भेजे तत्काल प्रक्रिया पूरी करें।'
      },
      {
        labelHi: '48 घंटे में डिजिटल ई-पैन और 10 दिनों में भौतिक प्लास्टिक कार्ड प्राप्त करें',
        detailHi: 'आयकर विभाग द्वारा क्यूआर कोड युक्त आधिकारिक कार्ड जारी होता है।'
      }
    ]
  },
  'driving-licence-llr': {
    titleHi: 'लर्निंग लाइसेंस (LLR) एवं ड्राइविंग लाइसेंस सेवा',
    departmentHi: 'परिवहन विभाग, आंध्र प्रदेश सरकार (AP e-Pragathi / Sarathi)',
    shortNameHi: 'ड्राइविंग लाइसेंस / एलएलआर',
    descriptionHi: 'दुपहिया और चार पहिया वाहनों के लिए शिक्षार्थी (LLR) और स्थायी ड्राइविंग लाइसेंस।',
    procedureStepsHi: [
      {
        labelHi: 'आधार कार्ड, आयु प्रमाण और स्व-घोषणा मेडिकल फॉर्म 1 संलग्न करें',
        detailHi: '40 वर्ष से अधिक होने पर एमबीबीएस डॉक्टर का फॉर्म 1A अनिवार्य है।'
      },
      {
        labelHi: 'parivahan.gov.in पर ऑनलाइन शुल्क भुगतान कर स्लॉट बुक करें',
        detailHi: 'सार्थी परिवहन पोर्टल पर आधार प्रमाणित ऑनलाइन आवेदन भरें।'
      },
      {
        labelHi: 'ऑनलाइन यातायात संकेत कंप्यूटर परीक्षा (LLR Test) उत्तीर्ण करें',
        detailHi: 'घर बैठे या आरटीओ कार्यालय में ऑनलाइन बहुविकल्पीय परीक्षा दें।'
      },
      {
        labelHi: 'शिक्षार्थी लाइसेंस तुरंत डाउनलोड करें और 30 दिन बाद स्थायी ड्राइविंग टेस्ट दें',
        detailHi: 'एलएलआर जारी होने के 6 माह तक स्थायी लाइसेंस के लिए पात्र।'
      }
    ]
  }
};

export const DOC_HINDI_NAMES: Record<string, string> = {
  'doc-aadhaar': 'आधार कार्ड (पहचान व पता प्रमाण)',
  'doc-tc-memo': 'स्कूल टीसी / 10वीं मार्कशीट (DOB प्रमाण)',
  'doc-parent-caste': 'माता-पिता का जाति प्रमाण पत्र / 1-B भू-अभिलेख',
  'doc-address': 'स्थानीय निवास प्रमाण / बिजली बिल',
  'doc-photo': 'पासपोर्ट साइज रंगीन फोटो',
  'doc-income-proof': 'आय प्रमाण पत्र / वेतन पर्ची / स्व-घोषणा',
  'doc-rice-card': 'राइस कार्ड / सफेद राशन कार्ड',
  'doc-residence': 'निवास प्रमाण पत्र / मतदाता पहचान पत्र',
  'doc-all-aadhaar': 'परिवार के सभी सदस्यों के आधार कार्ड',
  'doc-female-bank': 'महिला मुखिया की बैंक पासबुक',
  'doc-residence-proof': 'निवास प्रमाण पत्र / गैस कनेक्शन बिल',
  'doc-land-decl': 'कृषि/शहरी भूमि घोषणा पत्र (वीआरओ रिपोर्ट)',
  'doc-hospital-discharge': 'अस्पताल जन्म डिस्चार्ज पर्ची / फॉर्म 1',
  'doc-parents-id': 'माता-पिता के आधार कार्ड एवं विवाह प्रमाण',
  'doc-school-tc': 'स्कूल बोनाफाइड / टीसी (जन्म तिथि अंकित)',
  'doc-nac-affidavit': 'नॉन-अवेलेबिलिटी सर्टिफिकेट (NAC) एवं नोटरी हलफनामा',
  'doc-applicant-aadhaar': 'आवेदक का आधार कार्ड',
  'doc-land-records': 'वेबलैंड 1-B खतियान एवं पट्टादार पासबुक',
  'doc-residential-deed': 'आवासीय संपत्ति दस्तावेज / नगर निगम मूल्यांकन',
  'doc-residence-bills': 'निवास प्रमाण पत्र / नगर निगम रसीद',
  'doc-study-certs': 'अध्ययन प्रमाण पत्र (कक्षा 4 से 10 तक लगातार)',
  'doc-student-aadhaar': 'छात्र का आधार कार्ड',
  'doc-income-cert': 'सक्षम प्राधिकारी द्वारा जारी आय प्रमाण पत्र',
  'doc-caste-cert': 'सक्षम प्राधिकारी द्वारा जारी जाति प्रमाण पत्र',
  'doc-mother-bank': 'माता का सक्रिय बचत बैंक खाता पासबुक (एनपीसीआई सीडेड)',
  'doc-admission-allotment': 'कॉलेज प्रवेश आवंटन आदेश (Allotment Order)',
  'doc-class7-marks': 'कक्षा 7 की अंकतालिका (न्यूनतम 55% अंक)',
  'doc-tahsildar-income': 'तहसीलदार द्वारा जारी आय प्रमाण पत्र (< ₹3.5 लाख)',
  'doc-student-bank': 'छात्र का एकल बैंक खाता पासबुक (आधार सीडेड)',
  'doc-study-cert': 'सरकारी/सहायता प्राप्त स्कूल का अध्ययन प्रमाण पत्र',
  'doc-bonafide-cert': 'कॉलेज बोनाफाइड छात्र प्रमाण पत्र',
  'doc-previous-memo': 'पिछली परीक्षा की मूल अंकतालिका',
  'doc-npci-bank': 'एनपीसीआई मैप आधार-सीडेड बैंक पासबुक',
  'doc-disability-photo': 'दिव्यांगता की स्पष्ट पूर्ण शारीरिक तस्वीर',
  'doc-medical-records': 'अस्पताल के पुराने इलाज के पर्चे व जांच रिपोर्ट',
  'doc-police-missing': 'पुलिस गुमशुदगी / ट्रेस-न-होने का प्रमाण पत्र',
  'doc-headmaster-affidavit': 'संबंधित स्कूल हेडमास्टर का शपथ-पत्र',
  'doc-challan-receipt': 'सीएफएमएस ट्रेजरी चालान भुगतान रसीद',
  'doc-candidate-aadhaar': 'परीक्षार्थी का आधार कार्ड',
  'doc-hall-ticket': 'इंटरमीडिएट परीक्षा हॉल टिकट या पुरानी मार्कशीट प्रति',
  'doc-student-id': 'कॉलेज पहचान पत्र / आधार कार्ड',
  'doc-police-cert': 'थाना शिकायत रसीद या नोटरी हलफनामा',
  'doc-farmer-aadhaar': 'किसान का आधार कार्ड (मोबाइल लिंक)',
  'doc-land-ror': 'वेबलैंड 2.0 रिकॉर्ड ऑफ राइट्स (RoR 1B खतियान)',
  'doc-bank-passbook': 'आधार-सीडेड बैंक पासबुक प्रति',
  'doc-patient-aadhaar': 'रोगी का आधार कार्ड',
  'doc-proof-identity': 'पहचान प्रमाण (POI - पासपोर्ट/पैन/वोटर आईडी)',
  'doc-proof-address': 'पता प्रमाण (POA - बिजली बिल/पानी बिल/बैंक स्टेटमेंट)',
  'doc-proof-dob': 'जन्म तिथि प्रमाण (जन्म प्रमाण पत्र/10वीं टीसी)',
  'doc-voter-photo': 'पासपोर्ट साइज रंगीन फोटो',
  'doc-age-proof': 'आयु प्रमाण (10वीं मार्कशीट या जन्म प्रमाण पत्र)',
  'doc-photo-sign': 'हस्ताक्षर एवं सफेद बैकग्राउंड फोटो',
  'doc-medical-form': 'मेडिकल फिटनेस स्व-घोषणा (फॉर्म 1/1A)',
  'doc-blood-group': 'रक्त समूह जांच रिपोर्ट (Blood Group Report)',
  'doc-bank-account': 'आधार से जुड़ा बैंक बचत खाता',
  'doc-petitioner-aadhaar': 'शिकायतकर्ता का आधार कार्ड',
  'doc-grievance-petition': 'लिखित शिकायत पत्र / अभ्यावेदन',
  'doc-previous-receipts': 'पूर्व में किए गए आवेदन की पावती रसीदें'
};

/**
 * Returns localized scheme title, department, description, and procedure steps
 */
export function getLocalizedService(service: any, lang: 'en' | 'te' | 'hi') {
  if (lang === 'hi') {
    const hi = SERVICES_HINDI_DATA[service.id];
    return {
      title: hi?.titleHi || service.title,
      department: hi?.departmentHi || service.department,
      description: hi?.descriptionHi || service.description,
      shortName: hi?.shortNameHi || service.shortName,
      procedureSteps: service.portalProcedureSteps.map((step: any, idx: number) => ({
        ...step,
        label: hi?.procedureStepsHi?.[idx]?.labelHi || step.label,
        detail: hi?.procedureStepsHi?.[idx]?.detailHi || step.detail,
      }))
    };
  }
  if (lang === 'te') {
    return {
      title: service.titleTe || service.title,
      department: service.departmentTe || service.department,
      description: service.descriptionTe || service.description,
      shortName: service.shortName,
      procedureSteps: service.portalProcedureSteps.map((step: any) => ({
        ...step,
        label: step.labelTe || step.label,
        detail: step.detailTe || step.detail,
      }))
    };
  }
  return {
    title: service.title,
    department: service.department,
    description: service.description,
    shortName: service.shortName,
    procedureSteps: service.portalProcedureSteps
  };
}

export function getLocalizedDocName(doc: any, lang: 'en' | 'te' | 'hi') {
  if (lang === 'hi') {
    return DOC_HINDI_NAMES[doc.id] || DOC_HINDI_NAMES[doc.name] || doc.name;
  }
  if (lang === 'te') {
    return doc.nameTe || doc.name;
  }
  return doc.name;
}

export function getLocalizedServiceTitle(service: any, lang: 'en' | 'te' | 'hi') {
  if (lang === 'hi') {
    return SERVICES_HINDI_DATA[service.id]?.titleHi || service.title;
  }
  if (lang === 'te') {
    return service.titleTe || service.title;
  }
  return service.title;
}

export function getLocalizedServiceDepartment(service: any, lang: 'en' | 'te' | 'hi') {
  if (lang === 'hi') {
    return SERVICES_HINDI_DATA[service.id]?.departmentHi || service.department;
  }
  if (lang === 'te') {
    return service.departmentTe || service.department;
  }
  return service.department;
}

