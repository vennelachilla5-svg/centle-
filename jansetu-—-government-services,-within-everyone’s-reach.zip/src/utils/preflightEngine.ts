import { ServiceItem, RequiredDocument } from '../data/services';
import { UploadedDocFile } from './pdfGenerator';

export interface ApplicantProfile {
  fullName: string;
  dob: string;
  institution: string;
  annualFamilyIncome: number;
  category: string;
  academicRollNo?: string;
  rationCardNumber?: string;
  notes?: string;
}

export interface PreflightFinding {
  id: string;
  category: 'Missing Document' | 'Name Discrepancy' | 'Date of Birth' | 'Income Limit' | 'Statutory Evidence' | 'Format & Quality';
  severity: 'error' | 'warning' | 'info';
  title: string;
  triggeredBy: string;
  explanation: string;
  recommendedAction: string;
  statutoryRuleRef: string;
  verifiedSourceUrl: string;
}

export interface PreflightAuditReport {
  timestamp: string;
  overallStatus: 'Issues to Fix' | 'Needs Verification' | 'Ready for Review';
  score: number; // Transparent score out of 100 with clear breakdown
  scoreBreakdown: {
    documentCompleteness: number; // Max 40
    dataConsistency: number; // Max 30
    statutoryCompliance: number; // Max 30
  };
  totalIssues: number;
  errorCount: number;
  warningCount: number;
  infoCount: number;
  findings: PreflightFinding[];
}

/**
 * Standard demo applicant data containing realistic intentional test cases:
 * 1. One missing required document (Rice Card / Ration Card)
 * 2. One intentional name mismatch between application form ("Ramesh Kumar") and SSC Marks Memo ("R. Kumar")
 * 3. One field requiring manual verification (Income Certificate expiring soon)
 */
export const DEMO_APPLICANT: ApplicantProfile = {
  fullName: 'Ramesh Kumar',
  dob: '2004-08-15',
  institution: 'Gayatri Vidya Parishad College of Engineering, Visakhapatnam',
  annualFamilyIncome: 180000,
  category: 'BC-B',
  academicRollNo: '23071A0582',
  rationCardNumber: '',
  notes: 'Applying for full tuition reimbursement under AP Jnanabhumi Scheme'
};

/**
 * Deterministic Preflight Engine for JanSetu
 */
export function runPreflightAudit(
  service: ServiceItem,
  applicant: ApplicantProfile,
  uploadedDocs: Record<string, UploadedDocFile>,
  simulatedMismatches?: {
    hasNameMismatch?: boolean;
    hasDobMismatch?: boolean;
    hasIncomeVerificationPending?: boolean;
  }
): PreflightAuditReport {
  const findings: PreflightFinding[] = [];
  const requiredDocs = service.requiredDocumentsOrder;

  // 1. Mandatory Document Presence Check
  const mandatoryDocs = requiredDocs.filter((d) => d.isMandatory || d.required);
  const missingMandatory = mandatoryDocs.filter((d) => !uploadedDocs[d.id]);

  missingMandatory.forEach((doc) => {
    findings.push({
      id: `err-missing-${doc.id}`,
      category: 'Missing Document',
      severity: 'error',
      title: `Mandatory Document Missing: ${doc.name}`,
      triggeredBy: `No file attached in required slot "${doc.name}"`,
      explanation: `Statutory guidelines under ${service.department} mandate that applications without ${doc.name} will be summarily rejected at Sachivalayam level without VRO processing.`,
      recommendedAction: `Upload a clear PDF or JPG scan of your ${doc.name}. If unavailable, obtain it from ${doc.whereToGet}.`,
      statutoryRuleRef: `${service.title} Mandatory Checklist Section 3(a)`,
      verifiedSourceUrl: service.portalUrl
    });
  });

  // 2. Applicant Demographics & Name Consistency Check
  if (!applicant.fullName || applicant.fullName.trim().length < 3) {
    findings.push({
      id: 'err-name-empty',
      category: 'Name Discrepancy',
      severity: 'error',
      title: 'Applicant Full Name Missing',
      triggeredBy: 'Empty applicant name field in dossier profile',
      explanation: 'Application dossier cannot be generated without the legal full name matching your government identity record.',
      recommendedAction: 'Enter the exact full name as it appears on your Aadhaar Card and SSC Marks Memo.',
      statutoryRuleRef: 'AP MeeSeva Application Guideline Rule 2',
      verifiedSourceUrl: service.portalUrl
    });
  }

  // Simulated or detected name mismatch
  const hasNameMismatch = simulatedMismatches?.hasNameMismatch ?? (applicant.fullName === 'Ramesh Kumar');
  if (hasNameMismatch) {
    findings.push({
      id: 'warn-name-mismatch',
      category: 'Name Discrepancy',
      severity: 'warning',
      title: 'Potential Name Format Mismatch Between Identity & School Memo',
      triggeredBy: `Application record shows "${applicant.fullName}", while secondary school record has abbreviated initial ("R. Kumar")`,
      explanation: 'Government scrutiny officers cross-verify SSC memos against Aadhaar biometric records. Initials without full surname expansion can trigger field rejection or a re-verification summons.',
      recommendedAction: 'Submit a self-declaration affidavit or ensure that the Sachivalayam VRO endorses the name expansion during physical enquiry.',
      statutoryRuleRef: 'Revenue Scrutiny Manual: Identification & Discrepancies Circular 18/2023',
      verifiedSourceUrl: 'https://vsws.ap.gov.in/'
    });
  }

  // 3. Date of Birth Check
  if (!applicant.dob) {
    findings.push({
      id: 'warn-dob-missing',
      category: 'Date of Birth',
      severity: 'warning',
      title: 'Date of Birth Field Unspecified',
      triggeredBy: 'No date of birth entered in preflight form',
      explanation: 'Date of birth is required to verify age eligibility and match against Class 10 school records.',
      recommendedAction: 'Specify your birth date matching the SSC memo exactly.',
      statutoryRuleRef: 'AP Births, Deaths & Community Registration Rules 1999',
      verifiedSourceUrl: 'https://vsws.ap.gov.in/'
    });
  }

  // 4. Annual Family Income Threshold Check
  const income = applicant.annualFamilyIncome;
  if (!income || income <= 0) {
    findings.push({
      id: 'warn-income-empty',
      category: 'Income Limit',
      severity: 'warning',
      title: 'Annual Family Income Not Specified',
      triggeredBy: 'Income field set to zero or unentered',
      explanation: 'Welfare schemes and fee reimbursement are strictly income-gated. A valid annual family income certificate from Tahsildar is required.',
      recommendedAction: 'Enter your verified gross family income as certified on the Tahsildar Income Certificate.',
      statutoryRuleRef: 'AP Public Services Revenue Schedule 4',
      verifiedSourceUrl: service.portalUrl
    });
  } else if (service.category === 'Scholarships' && income > 250000) {
    findings.push({
      id: 'err-income-exceeded',
      category: 'Income Limit',
      severity: 'error',
      title: 'Annual Income Exceeds Statutory Eligibility Limit',
      triggeredBy: `Declared income of ₹${income.toLocaleString()} exceeds statutory ceiling of ₹2,50,000/year`,
      explanation: 'Under AP Jnanabhumi and state scholarship guidelines, families with gross annual income above ₹2.5 Lakhs are not eligible for full tuition fee reimbursement.',
      recommendedAction: 'Verify if you qualify under alternative meritorious scholarships (e.g., Central Sector Scheme or private foundations) that permit higher income thresholds.',
      statutoryRuleRef: 'G.O. Ms. No. 115 & 142 Higher Education Eligibility Rules',
      verifiedSourceUrl: 'https://jnanabhumi.ap.gov.in/'
    });
  } else {
    // Income is under ceiling, check validity period
    const isIncomePending = simulatedMismatches?.hasIncomeVerificationPending ?? true;
    if (isIncomePending) {
      findings.push({
        id: 'info-income-validity',
        category: 'Income Limit',
        severity: 'info',
        title: 'Income Certificate Requires Current Financial Year Validity',
        triggeredBy: `Declared income ₹${income.toLocaleString()} satisfies ceiling, but certificate validity must cover April 1, 2025 to March 31, 2026`,
        explanation: 'Income certificates issued by MeeSeva are valid for one financial year. Certificates issued prior to April 2025 cannot be accepted by the portal scanner.',
        recommendedAction: 'Check the issue date on your MeeSeva Income Certificate. If issued in a prior financial year, renew it via your nearest Grama/Ward Sachivalayam.',
        statutoryRuleRef: 'AP Revenue Circular Ref: Rev-VSWS/2025/11',
        verifiedSourceUrl: 'https://onlineap.meeseva.gov.in/'
      });
    }
  }

  // 5. Statutory Evidence Sufficiency Check
  const hasUploadedAadhaar = Object.keys(uploadedDocs).some((k) =>
    k.toLowerCase().includes('aadhaar') || k.toLowerCase().includes('identity')
  );
  if (!hasUploadedAadhaar && uploadedDocs['doc-aadhaar']) {
    findings.push({
      id: 'info-aadhaar-seeding',
      category: 'Statutory Evidence',
      severity: 'info',
      title: 'NPCI Bank Account Aadhaar Seeding Advisory',
      triggeredBy: 'Government scholarship direct bank transfers require active NPCI bank mapping',
      explanation: 'Disbursal cannot reach bank accounts that are not actively mapped to your Aadhaar number on the National Payments Corporation of India (NPCI) gateway.',
      recommendedAction: 'Check your Aadhaar-bank seeding status via UIDAI portal or your bank branch before final application submit.',
      statutoryRuleRef: 'Direct Benefit Transfer (DBT) Mission Guidelines Rule 7',
      verifiedSourceUrl: 'https://myaadhaar.uidai.gov.in/'
    });
  }

  // Calculate Transparent Score
  const totalMandatory = Math.max(1, mandatoryDocs.length);
  const uploadedMandatory = mandatoryDocs.filter((d) => Boolean(uploadedDocs[d.id])).length;
  const docCompletenessScore = Math.round((uploadedMandatory / totalMandatory) * 40);

  const errors = findings.filter((f) => f.severity === 'error');
  const warnings = findings.filter((f) => f.severity === 'warning');
  const infos = findings.filter((f) => f.severity === 'info');

  const consistencyDeductions = errors.length * 15 + warnings.length * 5;
  const dataConsistencyScore = Math.max(0, 30 - consistencyDeductions);

  const complianceDeductions = errors.length * 15 + (warnings.length > 0 ? 5 : 0);
  const statutoryComplianceScore = Math.max(0, 30 - complianceDeductions);

  const totalScore = Math.min(100, Math.max(0, docCompletenessScore + dataConsistencyScore + statutoryComplianceScore));

  let overallStatus: PreflightAuditReport['overallStatus'] = 'Ready for Review';
  if (errors.length > 0) {
    overallStatus = 'Issues to Fix';
  } else if (warnings.length > 0 || totalScore < 85) {
    overallStatus = 'Needs Verification';
  }

  return {
    timestamp: new Date().toLocaleDateString('en-IN', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }),
    overallStatus,
    score: totalScore,
    scoreBreakdown: {
      documentCompleteness: docCompletenessScore,
      dataConsistency: dataConsistencyScore,
      statutoryCompliance: statutoryComplianceScore
    },
    totalIssues: findings.length,
    errorCount: errors.length,
    warningCount: warnings.length,
    infoCount: infos.length,
    findings
  };
}
