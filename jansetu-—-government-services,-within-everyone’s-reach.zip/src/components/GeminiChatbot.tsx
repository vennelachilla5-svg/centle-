import React, { useState, useEffect, useRef } from 'react';
import {
  MessageSquare,
  Send,
  X,
  ExternalLink,
  Sparkles,
  Bot,
  User,
  RotateCcw,
  Mic,
  Maximize2,
  Minimize2,
  Layers,
  ArrowRight,
  ShieldCheck,
  ChevronDown,
  Zap,
  Cpu
} from 'lucide-react';
import { SERVICES_DATA, ServiceItem } from '../data/services';

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
  latencyMs?: number;
  model?: string;
  provider?: string;
  detectedPortals?: { name: string; url: string; serviceId?: string }[];
}

interface GeminiChatbotProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenVoiceModal: () => void;
  onSelectService: (serviceId: string) => void;
  activeServiceTitle: string;
  citizenName: string;
  lang: 'en' | 'te' | 'hi';
}

export default function GeminiChatbot({
  isOpen,
  onClose,
  onOpenVoiceModal,
  onSelectService,
  activeServiceTitle,
  citizenName,
  lang,
}: GeminiChatbotProps) {
  const [selectedModel, setSelectedModel] = useState<
    'openai/gpt-oss-120b' | 'openai/gpt-oss-20b' | 'qwen/qwen3.8-27b'
  >('openai/gpt-oss-120b');

  const [messages, setMessages] = useState<ChatMessage[]>(() => {
    try {
      const saved = localStorage.getItem('jansetu_chat_history_v1');
      if (saved) return JSON.parse(saved);
    } catch {
      // fallback
    }
    return [
      {
        id: 'welcome-1',
        role: 'assistant',
        content: `Namaste${citizenName ? ` ${citizenName}` : ''}! I am your **JanSetu AI Official Portal Counselor**, running at lightning speed on Groq LPU inference.

I can help you:
1. 🏛️ **Discover the best government schemes & applications** across state and central departments for your family.
2. 🚀 **Direct you into official portals online** (AP Seva, MeeSeva, Jnanabhumi, BSE AP, NSP, PM-KISAN, Ayushman Aarogyasri, Parivahan, and more).
3. 📋 **Get all your document requirements ready** so your application is never rejected.

Ask me anything or select a topic below to get started!`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        latencyMs: 185,
        provider: 'Groq LPU',
        model: 'openai/gpt-oss-120b',
        detectedPortals: [
          { name: 'AP Seva Portal (VSWS)', url: 'https://vsws.ap.gov.in/', serviceId: 'ap-caste-integrated' },
          { name: 'AP MeeSeva Citizen Portal', url: 'https://onlineap.meeseva.gov.in/', serviceId: 'ap-income-certificate' },
          { name: 'AP Jnanabhumi Scholarships', url: 'https://jnanabhumi.ap.gov.in/', serviceId: 'ap-vidya-deevena' }
        ]
      }
    ];
  });

  const [inputPrompt, setInputPrompt] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [isExpanded, setIsExpanded] = useState<boolean>(false);
  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    try {
      localStorage.setItem('jansetu_chat_history_v1', JSON.stringify(messages));
    } catch (e) {
      console.warn('Storage save error:', e);
    }
  }, [messages]);

  useEffect(() => {
    if (isOpen) {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, isOpen]);

  // Extract government portals from assistant text
  const extractPortalsFromText = (text: string) => {
    const list: { name: string; url: string; serviceId?: string }[] = [];
    const urlMatches = text.match(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g);

    if (urlMatches) {
      urlMatches.forEach((m) => {
        const parts = m.match(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/);
        if (parts && parts[1] && parts[2]) {
          const matchedService = SERVICES_DATA.find(
            (s) =>
              s.portalUrl.toLowerCase().includes(parts[2].toLowerCase()) ||
              parts[1].toLowerCase().includes(s.shortName.toLowerCase())
          );

          if (!list.some((item) => item.url === parts[2])) {
            list.push({
              name: parts[1],
              url: parts[2],
              serviceId: matchedService?.id
            });
          }
        }
      });
    }

    // Match keywords against known portals if not found in markdown links
    SERVICES_DATA.forEach((s) => {
      if (
        (text.toLowerCase().includes(s.shortName.toLowerCase()) ||
          text.toLowerCase().includes(s.portalName.toLowerCase())) &&
        !list.some((item) => item.url === s.portalUrl)
      ) {
        list.push({
          name: s.portalName,
          url: s.portalUrl,
          serviceId: s.id
        });
      }
    });

    return list.slice(0, 4);
  };

  const handleSendMessage = async (textToSend?: string) => {
    const messageContent = (textToSend || inputPrompt).trim();
    if (!messageContent || isLoading) return;

    const userMsg: ChatMessage = {
      id: `msg-${Date.now()}`,
      role: 'user',
      content: messageContent,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    const newMessages = [...messages, userMsg];
    setMessages(newMessages);
    setInputPrompt('');
    setIsLoading(true);

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          model: selectedModel,
          messages: newMessages.map((m) => ({
            role: m.role,
            content: m.content
          }))
        })
      });

      if (!response.ok) {
        throw new Error('Server returned an error status: ' + response.status);
      }

      const data = await response.json();
      const replyText = data.reply || 'No response returned from counselor.';
      const detectedPortals = extractPortalsFromText(replyText);

      const assistantMsg: ChatMessage = {
        id: `msg-${Date.now() + 1}`,
        role: 'assistant',
        content: replyText,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        latencyMs: data.latencyMs,
        model: data.model || selectedModel,
        provider: data.provider || 'Groq LPU',
        detectedPortals
      };

      setMessages((prev) => [...prev, assistantMsg]);
    } catch (err: any) {
      console.error('Chat error:', err);
      const errorMsg: ChatMessage = {
        id: `msg-err-${Date.now()}`,
        role: 'assistant',
        content: `I could not connect to the government portals engine. (${err.message || 'Network error'}). Please verify the server connection.`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setMessages((prev) => [...prev, errorMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleClearHistory = () => {
    if (confirm('Clear counselor conversation history?')) {
      const resetMsg: ChatMessage = {
        id: 'welcome-reset',
        role: 'assistant',
        content: `History cleared. How can I help you find and apply for government schemes or official portals today?`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setMessages([resetMsg]);
      localStorage.removeItem('jansetu_chat_history_v1');
    }
  };

  const promptChips = [
    '🎓 College student looking for fee reimbursement & scholarship options',
    '🌾 Farmer looking for PM-KISAN, Rythu Bharosa and e-Crop booking',
    '📜 Need Caste & Income certificate. What other schemes can I apply for with them?',
    '🏥 How to apply for Ayushman Bharat Aarogyasri free hospital health cover?',
    '🚗 Need to apply for Driving License (LLR) online from home',
    '📑 Duplicate SSC 10th Marks Memo from BSE AP'
  ];

  if (!isOpen) return null;

  return (
    <div
      className={`fixed bottom-4 right-4 z-50 bg-white border border-slate-200 rounded-lg shadow-2xl flex flex-col transition-all duration-200 ${
        isExpanded
          ? 'w-[94vw] sm:w-[680px] h-[88vh] max-h-[850px]'
          : 'w-[92vw] sm:w-[440px] h-[580px] max-h-[82vh]'
      }`}
    >
      {/* Header */}
      <div className="bg-slate-950 text-white px-3.5 py-2.5 rounded-t-lg flex items-center justify-between border-b border-slate-800">
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 rounded bg-slate-800 border border-slate-700 flex items-center justify-center text-white">
            <Zap className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
          </div>
          <div>
            <h3 className="text-xs font-bold flex items-center gap-1.5">
              <span>JanSetu AI Official Counselor</span>
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
            </h3>
            <p className="text-[10px] text-slate-400 font-mono">
              Groq LPU Engine · ~250-800 tok/s
            </p>
          </div>
        </div>

        <div className="flex items-center gap-1">
          {/* Voice Conversation trigger */}
          <button
            onClick={() => {
              onClose();
              onOpenVoiceModal();
            }}
            className="p-1.5 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800 transition-colors"
            title="Start Real-time Voice Conversation"
          >
            <Mic className="w-4 h-4 text-emerald-400" />
          </button>

          {/* Reset History */}
          <button
            onClick={handleClearHistory}
            className="p-1.5 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800 transition-colors"
            title="Clear Chat History"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>

          {/* Expand/Minimize */}
          <button
            onClick={() => setIsExpanded(!isExpanded)}
            className="p-1.5 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800 transition-colors hidden sm:block"
            title={isExpanded ? 'Minimize' : 'Expand'}
          >
            {isExpanded ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
          </button>

          {/* Close */}
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800 transition-colors"
            title="Close Assistant"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Groq LPU Engine & Model Switcher Sub-Bar */}
      <div className="bg-slate-800 px-3 py-1.5 border-b border-slate-700 flex items-center justify-between text-[10px] text-slate-300">
        <div className="flex items-center gap-1.5 font-medium">
          <Zap className="w-3 h-3 text-amber-400 fill-amber-400" />
          <span className="text-white font-bold">Groq LPU:</span>
          <span className="text-emerald-400 font-mono font-semibold">~250-800 tok/s</span>
        </div>

        <div className="flex items-center gap-1">
          <button
            type="button"
            onClick={() => setSelectedModel('openai/gpt-oss-120b')}
            className={`px-2 py-0.5 rounded transition-all font-semibold ${
              selectedModel === 'openai/gpt-oss-120b'
                ? 'bg-blue-600 text-white shadow-2xs'
                : 'text-slate-400 hover:text-white'
            }`}
            title="Deep 120B parameter reasoning with multi-scheme cross recommendations"
          >
            🧠 120B Deep
          </button>
          <button
            type="button"
            onClick={() => setSelectedModel('openai/gpt-oss-20b')}
            className={`px-2 py-0.5 rounded transition-all font-semibold ${
              selectedModel === 'openai/gpt-oss-20b'
                ? 'bg-blue-600 text-white shadow-2xs'
                : 'text-slate-400 hover:text-white'
            }`}
            title="Ultra-fast 20B instant model (< 200ms)"
          >
            ⚡ 20B Fast
          </button>
          <button
            type="button"
            onClick={() => setSelectedModel('qwen/qwen3.8-27b')}
            className={`px-2 py-0.5 rounded transition-all font-semibold ${
              selectedModel === 'qwen/qwen3.8-27b'
                ? 'bg-blue-600 text-white shadow-2xs'
                : 'text-slate-400 hover:text-white'
            }`}
            title="Multilingual optimized for Telugu and Hindi"
          >
            🌐 Qwen 27B
          </button>
        </div>
      </div>

      {/* Messages Scroll Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-slate-50/50 text-xs">
        {messages.map((msg) => {
          const isUser = msg.role === 'user';

          return (
            <div
              key={msg.id}
              className={`flex gap-2.5 ${isUser ? 'justify-end' : 'justify-start'}`}
            >
              {!isUser && (
                <div className="w-6 h-6 rounded-lg bg-blue-600 text-white flex items-center justify-center shrink-0 mt-0.5">
                  <Bot className="w-3.5 h-3.5" />
                </div>
              )}

              <div
                className={`max-w-[85%] rounded-2xl p-3.5 shadow-2xs leading-relaxed ${
                  isUser
                    ? 'bg-blue-600 text-white rounded-tr-xs'
                    : 'bg-white text-slate-900 border border-slate-200 rounded-tl-xs'
                }`}
              >
                <div className="whitespace-pre-wrap font-sans text-xs">
                  {msg.content}
                </div>

                {/* Interactive Portal Action Cards */}
                {msg.detectedPortals && msg.detectedPortals.length > 0 && (
                  <div className="mt-3 pt-2.5 border-t border-slate-100 flex flex-col gap-2">
                    <span className="text-[10px] font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1">
                      <ShieldCheck className="w-3 h-3 text-blue-600" />
                      Direct Official Government Portals:
                    </span>
                    <div className="grid grid-cols-1 gap-1.5">
                      {msg.detectedPortals.map((portal, idx) => (
                        <div
                          key={idx}
                          className="p-2 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between gap-2 text-[11px]"
                        >
                          <div className="truncate">
                            <strong className="block text-slate-900 truncate font-semibold">
                              {portal.name}
                            </strong>
                            <span className="text-[9px] text-slate-500 font-mono truncate block">
                              {portal.url}
                            </span>
                          </div>

                          <div className="flex items-center gap-1 shrink-0">
                            {portal.serviceId && (
                              <button
                                onClick={() => {
                                  onSelectService(portal.serviceId!);
                                  onClose();
                                }}
                                className="px-2 py-1 bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 rounded-lg text-[10px] font-semibold flex items-center gap-1 shadow-2xs"
                                title="Open in Application Studio to compile dossier"
                              >
                                <Layers className="w-3 h-3 text-blue-600" />
                                <span>Prepare in Studio</span>
                              </button>
                            )}
                            <a
                              href={portal.url}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="px-2 py-1 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-[10px] font-bold flex items-center gap-1 shadow-2xs"
                              title="Launch Real Portal in New Tab"
                            >
                              <span>Launch Portal</span>
                              <ExternalLink className="w-2.5 h-2.5" />
                            </a>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                <div
                  className={`mt-1.5 flex items-center justify-between text-[9px] ${
                    isUser ? 'text-blue-100' : 'text-slate-400'
                  }`}
                >
                  {!isUser && msg.latencyMs ? (
                    <span className="flex items-center gap-1 font-mono text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-100">
                      <Zap className="w-2.5 h-2.5 text-amber-500 fill-amber-500" />
                      <span>{msg.latencyMs}ms</span>
                      <span>•</span>
                      <span>{msg.model?.includes('20b') ? '20B Instant' : msg.model?.includes('qwen') ? 'Qwen 27B' : '120B Deep'}</span>
                    </span>
                  ) : (
                    <span />
                  )}
                  <span>{msg.timestamp}</span>
                </div>
              </div>

              {isUser && (
                <div className="w-6 h-6 rounded-lg bg-slate-900 text-white flex items-center justify-center shrink-0 mt-0.5">
                  <User className="w-3.5 h-3.5" />
                </div>
              )}
            </div>
          );
        })}

        {isLoading && (
          <div className="flex gap-2.5 items-center text-xs text-slate-500">
            <div className="w-6 h-6 rounded-lg bg-blue-600 text-white flex items-center justify-center shrink-0">
              <Bot className="w-3.5 h-3.5" />
            </div>
            <div className="p-3 bg-white border border-slate-200 rounded-2xl flex items-center gap-1.5 shadow-2xs">
              <span className="w-2 h-2 rounded-full bg-blue-600 animate-pulse"></span>
              <span className="w-2 h-2 rounded-full bg-blue-600 animate-pulse delay-100"></span>
              <span className="w-2 h-2 rounded-full bg-blue-600 animate-pulse delay-200"></span>
              <span className="text-[11px] font-medium text-slate-600 ml-1">
                Searching state &amp; central portals for the best options...
              </span>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Suggested Prompt Chips */}
      {messages.length <= 2 && (
        <div className="px-3 py-2 bg-slate-100/60 border-t border-slate-200 overflow-x-auto flex gap-1.5 shrink-0">
          {promptChips.map((chip, idx) => (
            <button
              key={idx}
              onClick={() => handleSendMessage(chip)}
              className="text-[10px] bg-white border border-slate-200 hover:border-blue-400 hover:bg-blue-50 text-slate-700 px-2.5 py-1 rounded-full whitespace-nowrap transition-colors shrink-0 shadow-2xs font-medium"
            >
              {chip}
            </button>
          ))}
        </div>
      )}

      {/* Footer Input Bar */}
      <div className="p-2.5 bg-white border-t border-slate-200 rounded-b-lg">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSendMessage();
          }}
          className="flex items-center gap-2"
        >
          <input
            type="text"
            value={inputPrompt}
            onChange={(e) => setInputPrompt(e.target.value)}
            placeholder="Ask about schemes, portals, or preflight rules..."
            className="flex-1 bg-slate-50 border border-slate-200 rounded-md px-3 py-1.5 text-xs text-slate-900 placeholder-slate-400 focus:outline-none focus:border-slate-900 focus:bg-white transition-colors"
          />

          <button
            type="button"
            onClick={() => {
              onClose();
              onOpenVoiceModal();
            }}
            className="p-1.5 rounded-md border border-slate-200 bg-white hover:bg-slate-50 text-slate-600 transition-colors"
            title="Start Voice Conversation"
          >
            <Mic className="w-4 h-4 text-emerald-600" />
          </button>

          <button
            type="submit"
            disabled={!inputPrompt.trim() || isLoading}
            className="btn-gov-primary p-1.5 rounded-md disabled:opacity-40 disabled:cursor-not-allowed shadow-2xs"
            title="Send Message"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
}
