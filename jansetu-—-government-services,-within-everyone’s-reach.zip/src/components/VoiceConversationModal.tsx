import React, { useState, useEffect, useRef } from 'react';
import {
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  X,
  Sparkles,
  ExternalLink,
  Layers,
  ArrowRight,
  ShieldCheck,
  RotateCcw,
  Radio,
  Zap
} from 'lucide-react';
import { SERVICES_DATA } from '../data/services';

interface VoiceConversationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectService: (serviceId: string) => void;
  lang: 'en' | 'te' | 'hi';
}

export default function VoiceConversationModal({
  isOpen,
  onClose,
  onSelectService,
  lang: initialLang,
}: VoiceConversationModalProps) {
  const [selectedLang, setSelectedLang] = useState<'en' | 'te' | 'hi'>(initialLang || 'en');
  const [isListening, setIsListening] = useState<boolean>(false);
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [isSpeaking, setIsSpeaking] = useState<boolean>(false);
  const [latencyMs, setLatencyMs] = useState<number | null>(190);

  const [transcriptText, setTranscriptText] = useState<string>('');
  const [assistantReply, setAssistantReply] = useState<string>(
    'Tap the microphone below and speak. Ask about scholarships, certificates, farmer assistance, or which portal is best for your situation.'
  );

  const [recommendedPortals, setRecommendedPortals] = useState<
    { name: string; url: string; serviceId?: string }[]
  >([
    { name: 'AP Seva Portal (VSWS)', url: 'https://vsws.ap.gov.in/', serviceId: 'ap-caste-integrated' },
    { name: 'AP MeeSeva Citizen Portal', url: 'https://onlineap.meeseva.gov.in/', serviceId: 'ap-income-certificate' },
    { name: 'National Scholarship Portal', url: 'https://scholarships.gov.in/', serviceId: 'central-nsp-scholarship' }
  ]);

  const recognitionRef = useRef<any>(null);
  const currentAudioRef = useRef<HTMLAudioElement | null>(null);

  // Initialize Speech Recognition
  useEffect(() => {
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (SpeechRecognition) {
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = true;
      recognition.lang =
        selectedLang === 'te' ? 'te-IN' : selectedLang === 'hi' ? 'hi-IN' : 'en-IN';

      recognition.onstart = () => {
        setIsListening(true);
        setTranscriptText('');
      };

      recognition.onresult = (event: any) => {
        let currentTranscript = '';
        for (let i = event.resultIndex; i < event.results.length; i++) {
          currentTranscript += event.results[i][0].transcript;
        }
        setTranscriptText(currentTranscript);
      };

      recognition.onerror = (event: any) => {
        console.warn('Speech recognition error:', event.error);
        setIsListening(false);
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognitionRef.current = recognition;
    }
  }, [selectedLang]);

  // Handle Voice Search / Question
  const handleProcessVoiceInput = async (spokenText: string) => {
    if (!spokenText.trim() || isProcessing) return;

    setIsProcessing(true);
    stopCurrentAudio();

    try {
      const response = await fetch('/api/voice-chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: spokenText,
          lang: selectedLang,
        }),
      });

      if (!response.ok) {
        throw new Error('Server returned an error status: ' + response.status);
      }

      const data = await response.json();
      const reply = data.reply || 'Here are the best official government options matching your profile.';
      setAssistantReply(reply);
      if (data.latencyMs) {
        setLatencyMs(data.latencyMs);
      }

      // Match portals in reply
      const extracted: { name: string; url: string; serviceId?: string }[] = [];
      SERVICES_DATA.forEach((s) => {
        if (
          (reply.toLowerCase().includes(s.shortName.toLowerCase()) ||
            reply.toLowerCase().includes(s.title.toLowerCase()) ||
            reply.toLowerCase().includes(s.portalName.toLowerCase())) &&
          !extracted.some((item) => item.url === s.portalUrl)
        ) {
          extracted.push({
            name: s.portalName,
            url: s.portalUrl,
            serviceId: s.id,
          });
        }
      });

      if (extracted.length > 0) {
        setRecommendedPortals(extracted.slice(0, 4));
      }

      // Play audio response:
      if (data.audioBase64) {
        playBase64Audio(data.audioBase64);
      } else {
        // Fallback to browser TTS
        speakWithBrowserTTS(reply);
      }
    } catch (err: any) {
      console.error('Voice processing error:', err);
      setAssistantReply(`Could not reach the government counsel engine (${err.message}). Please try again.`);
    } finally {
      setIsProcessing(false);
    }
  };

  const playBase64Audio = (base64Audio: string) => {
    try {
      const audio = new Audio(`data:audio/wav;base64,${base64Audio}`);
      currentAudioRef.current = audio;
      setIsSpeaking(true);
      audio.onended = () => setIsSpeaking(false);
      audio.onerror = () => {
        setIsSpeaking(false);
        speakWithBrowserTTS(assistantReply);
      };
      audio.play().catch(() => {
        speakWithBrowserTTS(assistantReply);
      });
    } catch {
      speakWithBrowserTTS(assistantReply);
    }
  };

  const speakWithBrowserTTS = (text: string) => {
    if (!('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 1.0;
    utterance.lang = selectedLang === 'te' ? 'te-IN' : selectedLang === 'hi' ? 'hi-IN' : 'en-IN';
    utterance.onstart = () => setIsSpeaking(true);
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);
    window.speechSynthesis.speak(utterance);
  };

  const stopCurrentAudio = () => {
    if (currentAudioRef.current) {
      currentAudioRef.current.pause();
      currentAudioRef.current = null;
    }
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    setIsSpeaking(false);
  };

  const toggleListening = () => {
    stopCurrentAudio();

    if (isListening) {
      recognitionRef.current?.stop();
      setIsListening(false);
      if (transcriptText.trim()) {
        handleProcessVoiceInput(transcriptText);
      }
    } else {
      setTranscriptText('');
      try {
        recognitionRef.current?.start();
        setIsListening(true);
      } catch (e) {
        console.warn('Recognition start error:', e);
      }
    }
  };

  // Auto trigger process when user stops speaking and has text
  useEffect(() => {
    if (!isListening && transcriptText.trim() && !isProcessing) {
      handleProcessVoiceInput(transcriptText);
    }
  }, [isListening]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white border border-slate-200 rounded-3xl max-w-xl w-full p-6 flex flex-col gap-5 shadow-2xl animate-fade-in">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-blue-600 flex items-center justify-center text-white shadow-xs">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2 flex-wrap">
                <span>JanSetu Real-Time Voice Counselor</span>
                <span className="flex items-center gap-1 text-[10px] text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200 font-semibold font-mono">
                  <Zap className="w-2.5 h-2.5 text-amber-500 fill-amber-500" />
                  <span>{latencyMs ? `${latencyMs}ms` : '< 200ms'} Groq LPU</span>
                </span>
                <span className="flex items-center gap-1 text-[10px] text-blue-700 bg-blue-50 px-2 py-0.5 rounded-full border border-blue-200 font-semibold">
                  <Radio className="w-2.5 h-2.5 text-blue-600 animate-pulse" /> Live Speech
                </span>
              </h3>
              <p className="text-[11px] text-slate-500">
                Speak naturally to discover government portals, schemes &amp; application steps
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              stopCurrentAudio();
              onClose();
            }}
            className="p-1.5 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Language selector */}
        <div className="flex items-center justify-between bg-slate-50 p-2 rounded-xl border border-slate-200 text-xs">
          <span className="text-slate-600 font-medium text-[11px]">Conversation Language:</span>
          <div className="flex gap-1">
            <button
              onClick={() => setSelectedLang('en')}
              className={`px-3 py-1 rounded-lg font-bold text-xs transition-colors ${
                selectedLang === 'en'
                  ? 'bg-blue-600 text-white shadow-2xs'
                  : 'bg-white text-slate-600 hover:text-slate-900 border border-slate-200'
              }`}
            >
              English
            </button>
            <button
              onClick={() => setSelectedLang('te')}
              className={`px-3 py-1 rounded-lg font-bold text-xs transition-colors ${
                selectedLang === 'te'
                  ? 'bg-blue-600 text-white shadow-2xs'
                  : 'bg-white text-slate-600 hover:text-slate-900 border border-slate-200'
              }`}
            >
              తెలుగు (Telugu)
            </button>
            <button
              onClick={() => setSelectedLang('hi')}
              className={`px-3 py-1 rounded-lg font-bold text-xs transition-colors ${
                selectedLang === 'hi'
                  ? 'bg-blue-600 text-white shadow-2xs'
                  : 'bg-white text-slate-600 hover:text-slate-900 border border-slate-200'
              }`}
            >
              हिन्दी (Hindi)
            </button>
          </div>
        </div>

        {/* Central Audio Waveform & Mic Circle */}
        <div className="flex flex-col items-center justify-center py-4 gap-3">
          <div className="relative">
            {/* Animated Pulses */}
            {(isListening || isSpeaking) && (
              <div
                className={`absolute inset-0 rounded-full animate-ping opacity-25 ${
                  isListening ? 'bg-rose-500' : 'bg-blue-500'
                }`}
              />
            )}

            <button
              onClick={toggleListening}
              className={`w-20 h-20 rounded-full flex items-center justify-center text-white shadow-lg transition-transform active:scale-95 z-10 relative ${
                isListening
                  ? 'bg-rose-600 ring-4 ring-rose-200 animate-pulse'
                  : isSpeaking
                  ? 'bg-emerald-600 ring-4 ring-emerald-200'
                  : isProcessing
                  ? 'bg-amber-500 ring-4 ring-amber-200 animate-pulse'
                  : 'bg-blue-600 hover:bg-blue-700 ring-4 ring-blue-100'
              }`}
              title={isListening ? 'Stop Listening' : 'Tap to Speak'}
            >
              {isListening ? (
                <Mic className="w-8 h-8 animate-bounce" />
              ) : isSpeaking ? (
                <Volume2 className="w-8 h-8" />
              ) : isProcessing ? (
                <Sparkles className="w-8 h-8 animate-spin" />
              ) : (
                <Mic className="w-8 h-8" />
              )}
            </button>
          </div>

          <div className="text-center">
            <span className="text-xs font-bold text-slate-800 block">
              {isListening
                ? 'Listening to you... Speak now'
                : isProcessing
                ? 'Matching government portals & options...'
                : isSpeaking
                ? 'JanSetu Voice Counselor Speaking...'
                : 'Tap Microphone to Speak'}
            </span>
            <span className="text-[10px] text-slate-400">
              {isListening ? 'Tap again when finished' : 'Ask about scholarships, fee reimbursement, or certificates'}
            </span>
          </div>
        </div>

        {/* Live Speech Transcript Box */}
        {transcriptText && (
          <div className="p-3 bg-blue-50/70 border border-blue-200 rounded-xl text-xs text-blue-950">
            <span className="text-[10px] text-blue-700 font-bold block mb-0.5 uppercase tracking-wider">
              You Said:
            </span>
            <p className="font-medium italic leading-relaxed">&ldquo;{transcriptText}&rdquo;</p>
          </div>
        )}

        {/* Assistant Spoken Response Box */}
        <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl text-xs flex flex-col gap-2">
          <div className="flex items-center justify-between text-[10px] text-slate-500">
            <span className="font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1">
              <Sparkles className="w-3 h-3 text-blue-600" />
              Counselor Spoken Counsel:
            </span>
            {isSpeaking && (
              <button
                onClick={stopCurrentAudio}
                className="text-red-600 hover:underline flex items-center gap-1 font-semibold"
              >
                <VolumeX className="w-3 h-3" /> Stop Voice
              </button>
            )}
          </div>
          <p className="text-slate-800 leading-relaxed font-sans">{assistantReply}</p>
        </div>

        {/* Matching Official Portal Action Cards */}
        {recommendedPortals.length > 0 && (
          <div className="flex flex-col gap-2">
            <span className="text-[10px] font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5 text-blue-600" />
              Suggested Official Portals Ready for You:
            </span>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {recommendedPortals.map((portal, idx) => (
                <div
                  key={idx}
                  className="p-2.5 bg-white border border-slate-200 rounded-xl shadow-2xs flex flex-col justify-between gap-2"
                >
                  <div>
                    <h4 className="text-xs font-bold text-slate-900 leading-tight">
                      {portal.name}
                    </h4>
                    <span className="text-[9px] text-slate-500 font-mono truncate block mt-0.5">
                      {portal.url}
                    </span>
                  </div>

                  <div className="flex items-center gap-1.5 pt-1 border-t border-slate-100">
                    {portal.serviceId && (
                      <button
                        onClick={() => {
                          onSelectService(portal.serviceId!);
                          stopCurrentAudio();
                          onClose();
                        }}
                        className="flex-1 py-1 px-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-[10px] font-semibold flex items-center justify-center gap-1"
                      >
                        <Layers className="w-3 h-3 text-blue-600" />
                        <span>In Studio</span>
                      </button>
                    )}
                    <a
                      href={portal.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex-1 py-1 px-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-[10px] font-bold flex items-center justify-center gap-1"
                    >
                      <span>Launch</span>
                      <ExternalLink className="w-2.5 h-2.5" />
                    </a>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
