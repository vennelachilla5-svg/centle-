export interface RequiredDocument {
  id: string;
  name: string;
  nameTe?: string;
  type: string;
  required: boolean;
  isMandatory: boolean;
  format: string;
  instructions: string;
  whereToGet: string;
  whyNeeded: string;
}

export interface PortalProcedureStep {
  id: string;
  label: string;
  labelTe?: string;
  detail: string;
  detailTe?: string;
  autoCheckOnAllDocs?: boolean;
}

export interface ServiceItem {
  id: string;
  title: string;
  titleTe?: string;
  shortName: string;
  category: 'AP Certificates' | 'Scholarships' | 'Social Security' | 'Agriculture' | 'Identity & Utility';
  state: 'Andhra Pradesh' | 'Central / All India';
  portalName: string;
  portalUrl: string;
  department: string;
  departmentTe?: string;
  fee: string;
  processingDays: string;
  description: string;
  descriptionTe?: string;
  eligibilitySummary: string[];
  precautions: string[];
  requiredDocumentsOrder: RequiredDocument[];
  portalProcedureSteps: PortalProcedureStep[];
}

export const SERVICES_DATA: ServiceItem[] = [
  {
    id: 'ap-caste-integrated',
    title: 'AP Integrated Certificate (Caste, Nativity & Date of Birth)',
    titleTe: 'ఏపీ ఇంటిగ్రేటెడ్ సర్టిఫికేట్ (కుల, స్థానికత & పుట్టిన తేదీ ధ్రువీకరణ)',
    shortName: 'Caste / Integrated',
    category: 'AP Certificates',
    state: 'Andhra Pradesh',
    portalName: 'AP Seva Portal (VSWS) / MeeSeva',
    portalUrl: 'https://vsws.ap.gov.in/',
    department: 'Revenue Department, Govt of Andhra Pradesh',
    departmentTe: 'రెవెన్యూ విభాగం, ఆంధ్రప్రదేశ్ ప్రభుత్వం',
    fee: '₹35 (MeeSeva User Charge)',
    processingDays: '15 Working Days',
    description: 'Single unified certificate covering community/caste, nativity, and date of birth for educational admissions, AP Jnanabhumi scholarships, and government recruitments.',
    descriptionTe: 'విద్యా ప్రవేశాలు, జ్ఞానభూమి స్కాలర్‌షిప్‌లు మరియు ప్రభుత్వ ఉద్యోగాల కోసం కులం, స్థానికత మరియు పుట్టిన తేదీని ధ్రువీకరించే ఉమ్మడి సర్టిఫికేట్.',
    eligibilitySummary: [
      'Resident of Andhra Pradesh belonging to a recognized SC/ST/BC community',
      'School or college records (SSC memo/TC) confirming caste or nativity',
      'Parents or family member having previously issued caste documentation'
    ],
    precautions: [
      'Use the exact caste category supported by school and family records.',
      'Carry original transfer certificate and parents certificate for field verification.',
      'Check spellings against your Aadhaar card before submitting.'
    ],
    requiredDocumentsOrder: [
      {
        id: 'doc-aadhaar',
        name: 'Applicant Aadhaar Card',
        nameTe: 'దరఖాస్తుదారు ఆధార్ కార్డు',
        type: 'Identity & Address Proof',
        required: true,
        isMandatory: true,
        format: 'JPG / PNG / PDF',
        instructions: 'Clear scan or photo of original Aadhaar card showing full name, DOB, and QR code.',
        whereToGet: 'UIDAI Portal / Authorized Aadhaar Kendra',
        whyNeeded: 'Primary national proof of identity, age, and address link.'
      },
      {
        id: 'doc-tc-memo',
        name: 'SSC Marks Memo or School Transfer Certificate (TC)',
        nameTe: 'ఎస్సెస్సీ మార్కుల మెమో లేదా పాఠశాల టిసి (TC)',
        type: 'Recorded Caste Proof',
        required: true,
        isMandatory: true,
        format: 'JPG / PNG / PDF',
        instructions: 'Document from school headmaster containing recorded caste/community and date of birth.',
        whereToGet: 'School Headmaster / Board of Secondary Education',
        whyNeeded: 'Official historical record of caste/community and date of birth in school register.'
      },
      {
        id: 'doc-parent-caste',
        name: 'Father / Family Previous Caste Certificate',
        nameTe: 'తండ్రి / కుటుంబ సభ్యుల మునుపటి కుల ధ్రువీకరణ పత్రం',
        type: 'Community Lineage Proof',
        required: true,
        isMandatory: true,
        format: 'JPG / PNG / PDF',
        instructions: 'Previously issued revenue caste certificate of applicant, father, or direct sibling.',
        whereToGet: 'Tahsildar Office / AP MeeSeva Archive',
        whyNeeded: 'Establishes recognized family lineage and community status.'
      },
      {
        id: 'doc-address',
        name: 'Rice Card / Electricity Bill / House Tax Receipt',
        nameTe: 'బియ్యం కార్డు / విద్యుత్ బిల్లు / ఇంటి పన్ను రశీదు',
        type: 'Nativity Proof',
        required: true,
        isMandatory: true,
        format: 'JPG / PNG / PDF',
        instructions: 'Current residential proof establishing residence within Andhra Pradesh.',
        whereToGet: 'Electricity Board / Gram Panchayat / Municipality',
        whyNeeded: 'Validates ordinary continuous residence within the local revenue jurisdiction.'
      },
      {
        id: 'doc-photo',
        name: 'Applicant Passport Size Photograph',
        nameTe: 'దరఖాస్తుదారు పాస్‌పోర్ట్ సైజు ఫోటో',
        type: 'Specimen Photo',
        required: true,
        isMandatory: true,
        format: 'JPG / PNG',
        instructions: 'Recent color passport photo with white or plain background.',
        whereToGet: 'Photo Studio / Mobile Camera Capture',
        whyNeeded: 'Printed digitally onto the final revenue certificate.'
      }
    ],
    portalProcedureSteps: [
      {
        id: 'step-doc-dossier',
        label: 'Upload mandatory documents and arrange sequence into PDF Dossier',
        labelTe: 'తప్పనిసరి పత్రాలను అప్‌లోడ్ చేసి వరుస క్రమంలో PDF ప్యాక్‌గా రూపొందించండి',
        detail: 'Must be organized in the official order required for Tahsildar / VRO scrutiny.',
        detailTe: 'రెవెన్యూ అధికారుల పరిశీలన క్రమంలో అమర్చాలి.',
        autoCheckOnAllDocs: true
      },
      {
        id: 'step-review-missing',
        label: 'Audit document completeness and review pending items',
        labelTe: 'పత్రాల సమగ్రతను తనిఖీ చేసి పెండింగ్ పత్రాలను పరిశీలించండి',
        detail: 'Ensure no mandatory legal records are missing before portal entry.',
        detailTe: 'పోర్టల్‌లో సమర్పించే ముందు ఎలాంటి ముఖ్యమైన పత్రాలు లోపించకుండా చూసుకోండి.'
      },
      {
        id: 'step-spellings',
        label: 'Verify Name, Parents Names & DOB spelling against Aadhaar',
        labelTe: 'ఆధార్ మరియు ఎస్సెస్సీ రికార్డులతో పేరు, తల్లిదండ్రుల పేర్ల స్పెల్లింగ్ సరిచూసుకోండి',
        detail: 'Must match Aadhaar and SSC marks memo character-for-character.',
        detailTe: 'అక్షరాల తేడా లేకుండా ఖచ్చితంగా సరిపోవాలి.'
      },
      {
        id: 'step-mobile-otp',
        label: 'Active mobile number ready for Aadhaar OTP e-KYC',
        labelTe: 'ఆధార్ ఓటీపీ ధ్రువీకరణ కోసం క్రియాశీల మొబైల్ సిద్ధం చేసుకోండి',
        detail: 'Required for electronic signing and biometric verification on AP Seva.',
        detailTe: 'ఎలక్ట్రానిక్ సంతకం మరియు బయోమెట్రిక్ ప్రక్రియ కోసం తప్పనిసరి.'
      },
      {
        id: 'step-launch-portal',
        label: 'Submit on Official AP Seva Portal & Record Token in Tracker',
        labelTe: 'అధికారిక ఏపీ సేవ పోర్టల్‌లో దరఖాస్తు చేసి టోకెన్ నంబర్‌ను భద్రపరచండి',
        detail: 'Launch official portal, upload dossier, and track status with token number.',
        detailTe: 'అధికారిక పోర్టల్ తెరిచి పత్రాలు సమర్పించి లైవ్ స్టేటస్ ట్రాక్ చేయండి.'
      }
    ]
  },
  {
    id: 'ap-income-certificate',
    title: 'Andhra Pradesh Income Certificate',
    titleTe: 'ఆంధ్రప్రదేశ్ ఆదాయ ధ్రువీకరణ పత్రం',
    shortName: 'Income Certificate',
    category: 'AP Certificates',
    state: 'Andhra Pradesh',
    portalName: 'AP MeeSeva Citizen Portal',
    portalUrl: 'https://onlineap.meeseva.gov.in/',
    department: 'Revenue Department, Govt of Andhra Pradesh',
    departmentTe: 'రెవెన్యూ విభాగం, ఆంధ్రప్రదేశ్ ప్రభుత్వం',
    fee: '₹35 (MeeSeva User Charge)',
    processingDays: '7 Working Days',
    description: 'Revenue authority certification of annual household income, mandatory for scholarships, college fee reimbursement, and government welfare benefits.',
    descriptionTe: 'స్కాలర్‌షిప్‌లు, ఫీజు రీయింబర్స్‌మెంట్ మరియు ప్రభుత్వ పథకాల కోసం వార్షిక కుటుంబ ఆదాయ ధ్రువీకరణ పత్రం.',
    eligibilitySummary: [
      'Resident of Andhra Pradesh',
      'Verifiable household income from agriculture, employment, business, or wage labor',
      'Typically valid for 1 financial year from the date of issue'
    ],
    precautions: [
      'Scholarship schemes require an Income Certificate issued within the current financial year.',
      'Carry salary slips, Form 16, or income affidavit to avoid rejection during VRO enquiry.'
    ],
    requiredDocumentsOrder: [
      {
        id: 'doc-aadhaar',
        name: 'Applicant & Household Head Aadhaar Cards',
        nameTe: 'దరఖాస్తుదారు & కుటుంబ పెద్ద ఆధార్ కార్డులు',
        type: 'Identity Proof',
        required: true,
        isMandatory: true,
        format: 'JPG / PNG / PDF',
        instructions: 'Aadhaar of applicant and family breadwinner.',
        whereToGet: 'UIDAI Portal / Enrolment Centre',
        whyNeeded: 'Verifies family demographic and resident linkage.'
      },
      {
        id: 'doc-income-proof',
        name: 'Salary Slip / Form 16 / Income Affidavit',
        nameTe: 'జీతం స్లిప్ / ఫారం 16 / ఆదాయ అఫిడవిట్',
        type: 'Income Evidence',
        required: true,
        isMandatory: true,
        format: 'JPG / PNG / PDF',
        instructions: 'Salary certificate for employed or notarized self-declaration for non-salaried.',
        whereToGet: 'Employer / Notary Advocate / Grama Sachivalayam',
        whyNeeded: 'Establishes factual annual earnings from all economic sources.'
      },
      {
        id: 'doc-rice-card',
        name: 'Rice Card / Ration Card Copy',
        nameTe: 'బియ్యం కార్డు / రేషన్ కార్డు కాపీ',
        type: 'Household Card',
        required: true,
        isMandatory: true,
        format: 'JPG / PNG / PDF',
        instructions: 'Card copy showing all family members and residential address.',
        whereToGet: 'Civil Supplies Dept / Grama Sachivalayam',
        whyNeeded: 'Cross-verifies family composition and economic class.'
      },
      {
        id: 'doc-residence',
        name: 'Electricity Bill or Property Tax Receipt',
        nameTe: 'కరెంట్ బిల్లు లేదా ఆస్తి పన్ను రశీదు',
        type: 'Address Verification',
        required: true,
        isMandatory: true,
        format: 'JPG / PNG / PDF',
        instructions: 'Recent domestic electricity bill showing consumer number.',
        whereToGet: 'Discom Office / Municipal Office',
        whyNeeded: 'Validates residential address and power consumption metrics.'
      }
    ],
    portalProcedureSteps: [
      {
        id: 'step-doc-dossier',
        label: 'Upload mandatory income and family proofs into PDF Dossier',
        labelTe: 'ఆదాయ మరియు కుటుంబ ఆధారాలను PDF ప్యాక్‌గా రూపొందించండి',
        detail: 'Formatted for Revenue Inspector & Tahsildar desk review.',
        detailTe: 'రెవెన్యూ ఇన్స్పెక్టర్ పరిశీలన కోసం సిద్ధం చేయండి.',
        autoCheckOnAllDocs: true
      },
      {
        id: 'step-review-missing',
        label: 'Check annual income figure matches submitted proofs',
        labelTe: 'సమర్పించిన పత్రాలతో ఆదాయ అంకెలు సరిపోలడాన్ని తనిఖీ చేయండి',
        detail: 'Verify exact amount entered in portal matches salary slip or affidavit.',
        detailTe: 'పోర్టల్‌లో నమోదు చేసిన మొత్తం అఫిడవిట్‌తో సమానంగా ఉండాలి.'
      },
      {
        id: 'step-spellings',
        label: 'Spell check against Aadhaar and electricity bill consumer name',
        labelTe: 'ఆధార్ మరియు కరెంట్ బిల్లు పేర్లను సరిచూసుకోండి',
        detail: 'Prevents discrepancies in VRO verification report.',
        detailTe: 'ఫీల్డ్ వెరిఫికేషన్‌లో ఇబ్బందులు లేకుండా చూసుకోండి.'
      },
      {
        id: 'step-mobile-otp',
        label: 'Pay ₹35 government service fee and keep receipt',
        labelTe: 'రూ.35 అధికారిక రుసుము చెల్లించి రశీదు తీసుకోండి',
        detail: 'Digital payment through MeeSeva portal payment gateway.',
        detailTe: 'మీసేవ పేమెంట్ గేట్‌వే ద్వారా చెల్లింపు.'
      },
      {
        id: 'step-launch-portal',
        label: 'Submit on AP MeeSeva & Save Application Token',
        labelTe: 'మీసేవలో దరఖాస్తు చేసి అప్లికేషన్ టోకెన్ భద్రపరచండి',
        detail: 'Tahsildar digital signature will be monitored using the token.',
        detailTe: 'డిజిటల్ సంతకం స్థితిని ట్రాక్ చేయడానికి టోకెన్ ఉపయోగపడుతుంది.'
      }
    ]
  },
  {
    id: 'ap-rice-card',
    title: 'Andhra Pradesh Rice Card / Ration Card',
    titleTe: 'ఆంధ్రప్రదేశ్ బియ్యం కార్డు / రేషన్ కార్డు',
    shortName: 'Rice Card / Ration',
    category: 'AP Certificates',
    state: 'Andhra Pradesh',
    portalName: 'AP Grama-Ward Sachivalayam (VSWS)',
    portalUrl: 'https://vsws.ap.gov.in/',
    department: 'Consumer Affairs, Food & Civil Supplies Dept, AP',
    departmentTe: 'పౌర సరఫరాల శాఖ, ఆంధ్రప్రదేశ్ ప్రభుత్వం',
    fee: 'Free of Cost (Govt Service)',
    processingDays: '21 Working Days',
    description: 'Household food security card issued by AP Government for subsidized rice, essential commodities, and qualifying for state health schemes (Aarogyasri).',
    descriptionTe: 'సబ్సిడీ బియ్యం, నిత్యావసర సరుకులు మరియు ఆరోగ్యశ్రీ సేవల కోసం ప్రభుత్వం అందించే కుటుంబ ఆహార భద్రతా కార్డు.',
    eligibilitySummary: [
      'Total family income below ₹10,000/month (Rural) or ₹12,000/month (Urban)',
      'Wetland holding below 3 acres or dryland below 10 acres',
      'Electricity consumption below 300 units/month',
      'No family member should own a four-wheeler (autos, tractors, taxis exempted)'
    ],
    precautions: [
      'Ration cards are household-based. Accurately report all family members to avoid duplicates.',
      'Provide bank account of female head of the household for DBT linkages.'
    ],
    requiredDocumentsOrder: [
      {
        id: 'doc-all-aadhaar',
        name: 'Aadhaar Cards of All Family Members',
        nameTe: 'కుటుంబ సభ్యులందరి ఆధార్ కార్డులు',
        type: 'Family Identity Proof',
        required: true,
        isMandatory: true,
        format: 'JPG / PNG / PDF',
        instructions: 'Copies of Aadhaar cards for every family member to be listed on the card.',
        whereToGet: 'UIDAI Portal / Enrolment Centers',
        whyNeeded: 'Validates biometric uniqueness and household composition.'
      },
      {
        id: 'doc-female-bank',
        name: 'Bank Passbook of Female Head of Family',
        nameTe: 'కుటుంబ మహిళా యజమాని బ్యాంక్ పాస్‌బుక్',
        type: 'DBT Bank Proof',
        required: true,
        isMandatory: true,
        format: 'JPG / PNG / PDF',
        instructions: 'Passbook front page showing Account No, IFSC, and photo of female head.',
        whereToGet: 'Bank Branch / Online Passbook',
        whyNeeded: 'Enables direct benefit transfer and state welfare linking.'
      },
      {
        id: 'doc-residence-proof',
        name: 'Address Proof (Electricity Bill / Rent Agreement)',
        nameTe: 'నివాస ధ్రువీకరణ (కరెంట్ బిల్లు / అద్దె ఒప్పందం)',
        type: 'Habitat Proof',
        required: true,
        isMandatory: true,
        format: 'JPG / PNG / PDF',
        instructions: 'Showing current residence in the respective village or ward secretariat area.',
        whereToGet: 'Electricity Provider / House Owner',
        whyNeeded: 'Assigns the family to their specific Grama/Ward Sachivalayam.'
      },
      {
        id: 'doc-land-decl',
        name: 'Land Declaration or Pattadar Copy (if cultivator)',
        nameTe: 'భూమి వివరాల పత్రం / పట్టాదారు కాపీ',
        type: 'Asset Verification',
        required: true,
        isMandatory: true,
        format: 'JPG / PNG / PDF',
        instructions: 'Proof of landholding below 3 acres wetland / 10 acres dryland.',
        whereToGet: 'Revenue Dept / Webland 1B Record',
        whyNeeded: 'Confirms land ceiling compliance under food security rules.'
      }
    ],
    portalProcedureSteps: [
      {
        id: 'step-doc-dossier',
        label: 'Upload family Aadhaar & bank records into PDF Dossier',
        labelTe: 'కుటుంబ ఆధార్ మరియు బ్యాంక్ వివరాలను PDF ప్యాక్‌గా రూపొందించండి',
        detail: 'Prepared for Grama/Ward volunteer physical inspection.',
        detailTe: 'వాలంటీర్ పరిశీలన కోసం సిద్ధం చేసుకోండి.',
        autoCheckOnAllDocs: true
      },
      {
        id: 'step-review-missing',
        label: 'Confirm all family members are covered with valid Aadhaar',
        labelTe: 'కుటుంబ సభ్యులందరికీ ఆధార్ వివరాలు సరిగా ఉన్నాయని నిర్ధారించుకోండి',
        detail: 'Prevents card generation failures due to missing demographic keys.',
        detailTe: 'కార్డు జారీలో ఎలాంటి ఇబ్బందులు రాకుండా చూసుకోండి.'
      },
      {
        id: 'step-spellings',
        label: 'Check electricity units consumption history (< 300 units)',
        labelTe: 'విద్యుత్ వినియోగం 300 యూనిట్ల లోపు ఉన్నట్లు నిర్ధారించుకోండి',
        detail: 'Monthly consumption above 300 units disqualifies the household.',
        detailTe: '300 యూనిట్లకు మించితే దరఖాస్తు తిరస్కరించబడుతుంది.'
      },
      {
        id: 'step-mobile-otp',
        label: 'Village/Ward Volunteer and Welfare Assistant verification',
        labelTe: 'గ్రామ/వార్డు వాలంటీర్ మరియు సంక్షేమ కార్యదర్శి పరిశీలన',
        detail: 'Field officer visits home for demographic checks.',
        detailTe: 'అధికారులు క్షేత్రస్థాయిలో పరిశీలన చేస్తారు.'
      },
      {
        id: 'step-launch-portal',
        label: 'Submit application on AP Seva & collect QR Rice Card',
        labelTe: 'ఏపీ సేవలో సమర్పించి క్యూఆర్ కోడ్ బియ్యం కార్డు పొందండి',
        detail: 'Approved by Tahsildar / Municipal Commissioner.',
        detailTe: 'అధికారుల ఆమోదం తర్వాత కార్డు డౌన్‌లోడ్ చేసుకోండి.'
      }
    ]
  },
  {
    id: 'ap-birth-certificate',
    title: 'Birth Certificate & Delayed Registration (AP MeeSeva)',
    titleTe: 'జనన ధ్రువీకరణ పత్రం & ఆలస్య నమోదు (మీసేవ)',
    shortName: 'Birth Certificate',
    category: 'Identity & Utility',
    state: 'Andhra Pradesh',
    portalName: 'AP MeeSeva / CDMA Portal',
    portalUrl: 'https://onlineap.meeseva.gov.in/',
    department: 'Directorate of Municipal Administration, AP',
    departmentTe: 'పురపాలక పరిపాలన డైరెక్టరేట్, ఆంధ్రప్రదేశ్',
    fee: '₹35 (MeeSeva User Charge)',
    processingDays: '7 to 30 Working Days',
    description: 'Official vital record certifying date and place of birth, issued by Municipal Commissioners or Panchayat Secretaries under the Registration of Births and Deaths Act.',
    descriptionTe: 'మున్సిపాలిటీ లేదా గ్రామ పంచాయతీ ద్వారా పుట్టిన తేదీ మరియు స్థలాన్ని ధ్రువీకరించే అధికారిక జనన ధ్రువీకరణ పత్రం.',
    eligibilitySummary: [
      'Birth occurred within the jurisdiction of Andhra Pradesh municipality or gram panchayat',
      'For delayed registrations (after 1 year): Requires Non-Availability Certificate and Magistrate order'
    ],
    precautions: [
      'Do not apply for new registration without first searching the existing birth register.',
      'If not found, obtain Non-Availability Certificate (NAC) before seeking delayed approval.'
    ],
    requiredDocumentsOrder: [
      {
        id: 'doc-hospital-discharge',
        name: 'Hospital Birth / Discharge Summary or Form 1',
        nameTe: 'ఆసుపత్రి డిశ్చార్జ్ సమ్మరీ లేదా ఫారం 1',
        type: 'Institutional Record',
        required: true,
        isMandatory: true,
        format: 'JPG / PNG / PDF',
        instructions: 'Issued by hospital/nursing home showing date, time, child gender, and parent names.',
        whereToGet: 'Hospital / Primary Health Centre (PHC)',
        whyNeeded: 'Clinical institutional verification of delivery timestamp and parent identity.'
      },
      {
        id: 'doc-parents-id',
        name: 'Parents Aadhaar Cards & Marriage Proof',
        nameTe: 'తల్లిదండ్రుల ఆధార్ కార్డులు & వివాహ రుజువు',
        type: 'Parental Identity',
        required: true,
        isMandatory: true,
        format: 'JPG / PNG / PDF',
        instructions: 'Clear copies of both parents Aadhaar cards.',
        whereToGet: 'UIDAI / Sub-Registrar Office',
        whyNeeded: 'Verifies parental names to be inscribed on the birth register.'
      },
      {
        id: 'doc-school-tc',
        name: 'School Leaving Certificate / SSC Memo (for delayed)',
        nameTe: 'పాఠశాల టిసి / ఎస్సెస్సీ మార్కుల మెమో (ఆలస్య నమోదుకు)',
        type: 'Age Corroboration',
        required: true,
        isMandatory: true,
        format: 'JPG / PNG / PDF',
        instructions: 'Showing recorded date of birth and parent names in educational register.',
        whereToGet: 'School Headmaster / Educational Board',
        whyNeeded: 'Corroborating secondary proof of recorded age for delayed registrations.'
      },
      {
        id: 'doc-nac-affidavit',
        name: 'Non-Availability Certificate (NAC) & Magistrate Affidavit',
        nameTe: 'నాన్-అవైలబిలిటీ సర్టిఫికేట్ (NAC) & మేజిస్ట్రేట్ అఫిడవిట్',
        type: 'Delayed Registration Sanction',
        required: true,
        isMandatory: true,
        format: 'JPG / PNG / PDF',
        instructions: 'Mandatory if birth was not registered within 1 year.',
        whereToGet: 'Municipal Commissioner / Revenue Divisional Officer (RDO)',
        whyNeeded: 'Legal prerequisite under RBD Act 1969 to order delayed entry into register.'
      }
    ],
    portalProcedureSteps: [
      {
        id: 'step-doc-dossier',
        label: 'Upload hospital proofs, parental IDs & affidavits into PDF Dossier',
        labelTe: 'ఆసుపత్రి పత్రాలు, ఆధార్ మరియు అఫిడవిట్‌లను PDF ప్యాక్‌గా రూపొందించండి',
        detail: 'Structured for Municipal Registrar / Panchayat Secretary.',
        detailTe: 'మున్సిపల్ రిజిస్ట్రార్ పరిశీలన కోసం సిద్ధం చేయండి.',
        autoCheckOnAllDocs: true
      },
      {
        id: 'step-review-missing',
        label: 'Search municipal birth register to prevent duplicate registration',
        labelTe: 'మున్సిపల్ రిజిస్టర్‌లో పేరు ఉందో లేదో వెతికి సరిచూసుకోండి',
        detail: 'Verify whether birth was already registered previously.',
        detailTe: 'గతంలో నమోదు అయి ఉంటే నేరుగా కాపీ కోసం దరఖాస్తు చేసుకోవచ్చు.'
      },
      {
        id: 'step-spellings',
        label: 'Confirm spelling of child name and parents names against Aadhaar',
        labelTe: 'పిల్లల పేరు మరియు తల్లిదండ్రుల పేర్ల స్పెల్లింగ్ ఆధార్‌తో సరిచూసుకోండి',
        detail: 'Corrections after certificate printing require gazette publications.',
        detailTe: 'సర్టిఫికేట్ జారీ అయ్యాక మార్పులు చేయడం కష్టం కాబట్టి ముందే సరిచూసుకోండి.'
      },
      {
        id: 'step-mobile-otp',
        label: 'Pay official fee at MeeSeva & keep registration token',
        labelTe: 'మీసేవలో అధికారిక రుసుము చెల్లించి టోకెన్ తీసుకోండి',
        detail: 'Revenue enquiry conducted by Municipal Health Officer / Panchayat Secretary.',
        detailTe: 'అధికారులు విచారణ జరిపి నమోదు చేస్తారు.'
      },
      {
        id: 'step-launch-portal',
        label: 'Launch AP MeeSeva & Download Digitally Signed Certificate',
        labelTe: 'మీసేవ పోర్టల్ తెరిచి డిజిటల్ సర్టిఫికేట్ డౌన్‌లోడ్ చేసుకోండి',
        detail: 'Collect authorized digitally signed certified vital record.',
        detailTe: 'అధికారిక జనన ధ్రువీకరణ పత్రం పొందండి.'
      }
    ]
  },
  {
    id: 'ap-ews-certificate',
    title: 'AP Economically Weaker Section (EWS) Certificate',
    titleTe: 'ఈడబ్ల్యూఎస్ (EWS) ఆదాయ మరియు ఆస్తుల ధ్రువీకరణ పత్రం',
    shortName: 'EWS Certificate',
    category: 'AP Certificates',
    state: 'Andhra Pradesh',
    portalName: 'AP MeeSeva Citizen Portal',
    portalUrl: 'https://onlineap.meeseva.gov.in/',
    department: 'Revenue Department, Govt of Andhra Pradesh',
    departmentTe: 'రెవెన్యూ విభాగం, ఆంధ్రప్రదేశ్ ప్రభుత్వం',
    fee: '₹35 (MeeSeva User Charge)',
    processingDays: '15 Working Days',
    description: 'Income and Asset Certificate for General category applicants not covered under SC/ST/OBC reservation, providing 10% reservation in admissions and employment.',
    descriptionTe: 'రిజర్వేషన్లు లేని జనరల్ కేటగిరీ అభ్యర్థులకు 10% రిజర్వేషన్ పొందేందుకు అవసరమైన ఆదాయ మరియు ఆస్తుల ధ్రువీకరణ పత్రం.',
    eligibilitySummary: [
      'Applicant must belong to General Category (not covered under SC, ST, or BC lists)',
      'Gross annual family income must be below ₹8,00,000 (Rupees Eight Lakhs)',
      'Family must not own 5 acres or more of agricultural land',
      'Residential flat size must be below 1000 sq. ft.'
    ],
    precautions: [
      'EWS is distinct from a basic Income Certificate; asset limits apply strictly.',
      'Central EWS format may have specific non-creamy requirements; verify receiving agency rules.'
    ],
    requiredDocumentsOrder: [
      {
        id: 'doc-applicant-aadhaar',
        name: 'Applicant & Parents Aadhaar Cards',
        nameTe: 'దరఖాస్తుదారు & తల్లిదండ్రుల ఆధార్ కార్డులు',
        type: 'Identity Proof',
        required: true,
        isMandatory: true,
        format: 'JPG / PNG / PDF',
        instructions: 'Aadhaar cards of applicant and parents.',
        whereToGet: 'UIDAI Portal / Enrolment Centers',
        whyNeeded: 'Verifies applicant age, identity, and family tree.'
      },
      {
        id: 'doc-income-proof',
        name: 'Income Proof (Form 16 / ITR / Salary Slip)',
        nameTe: 'ఆదాయ ధ్రువీకరణ (ఫారం 16 / ఐటీ రిటర్న్స్ / జీతం స్లిప్)',
        type: 'Income Verification',
        required: true,
        isMandatory: true,
        format: 'JPG / PNG / PDF',
        instructions: 'Verifying gross family income below 8 Lakhs.',
        whereToGet: 'Employer / Income Tax Portal / Chartered Accountant',
        whyNeeded: 'Confirms gross parental income does not exceed 8 Lakh ceiling.'
      },
      {
        id: 'doc-land-records',
        name: 'Agricultural Land Records / Pattadar Passbook',
        nameTe: 'వ్యవసాయ భూమి రికార్డులు / పట్టాదారు పాస్‌బుక్',
        type: 'Asset Verification',
        required: true,
        isMandatory: true,
        format: 'JPG / PNG / PDF',
        instructions: 'Verifying agricultural landholding is below 5 acres.',
        whereToGet: 'Tahsildar / Webland RoR Portal',
        whyNeeded: 'Ensures family does not own 5 acres or more of farmland.'
      },
      {
        id: 'doc-residential-deed',
        name: 'Residential Property Title Deed / Tax Receipt',
        nameTe: 'నివాస ఆస్తి దస్త్రాలు / పన్ను రశీదు',
        type: 'Property Asset Check',
        required: true,
        isMandatory: true,
        format: 'JPG / PNG / PDF',
        instructions: 'Showing plot/flat dimensions within prescribed limits.',
        whereToGet: 'Registration Dept / Municipal Office',
        whyNeeded: 'Confirms residential flat is under 1,000 sq ft or notified plot size.'
      }
    ],
    portalProcedureSteps: [
      {
        id: 'step-doc-dossier',
        label: 'Upload asset, land, and income records into PDF Dossier',
        labelTe: 'ఆస్తులు, భూమి మరియు ఆదాయ వివరాలను PDF ప్యాక్‌గా సిద్ధం చేయండి',
        detail: 'Ordered for Tahsildar revenue scrutiny.',
        detailTe: 'తహశీల్దార్ పరిశీలన క్రమంలో అమర్చండి.',
        autoCheckOnAllDocs: true
      },
      {
        id: 'step-review-missing',
        label: 'Confirm General category status (no SC/ST/BC certificate exists)',
        labelTe: 'జనరల్ కేటగిరీ స్థితిని నిర్ధారించుకోండి (SC/ST/BC సర్టిఫికేట్లు ఉండరాదు)',
        detail: 'EWS is strictly exclusive to non-reserved categories.',
        detailTe: 'రిజర్వేషన్ లేని వారికి మాత్రమే ఇది వర్తిస్తుంది.'
      },
      {
        id: 'step-spellings',
        label: 'Verify property dimensions and village survey numbers',
        labelTe: 'ఆస్తి కొలతలు మరియు సర్వే నంబర్లను సరిచూసుకోండి',
        detail: 'Ensures revenue inspector report matches field findings.',
        detailTe: 'రికార్డులకు, క్షేత్రస్థాయి పరిశీలనకు సరిపోవాలి.'
      },
      {
        id: 'step-mobile-otp',
        label: 'Pay ₹35 MeeSeva charge and complete mobile OTP e-KYC',
        labelTe: 'రూ.35 రుసుము చెల్లించి మొబైల్ ఓటీపీ ఈ-కేవైసీ పూర్తి చేయండి',
        detail: 'Save acknowledgement receipt for tracking.',
        detailTe: 'రశీదు మరియు టోకెన్ భద్రపరచుకోండి.'
      },
      {
        id: 'step-launch-portal',
        label: 'Launch AP MeeSeva & Track Tahsildar Digital Approval',
        labelTe: 'మీసేవలో దరఖాస్తు సమర్పించి తహశీల్దార్ డిజిటల్ సంతకం కోసం ట్రాక్ చేయండి',
        detail: 'Download digitally signed certificate upon approval.',
        detailTe: 'ఆమోదం తర్వాత డిజిటల్ సర్టిఫికేట్ పొందండి.'
      }
    ]
  },
  {
    id: 'ap-residence-certificate',
    title: 'Andhra Pradesh Residence / Nativity Certificate',
    titleTe: 'ఆంధ్రప్రదేశ్ నివాస ధ్రువీకరణ పత్రం (రెసిడెన్స్ సర్టిఫికేట్)',
    shortName: 'Residence Certificate',
    category: 'AP Certificates',
    state: 'Andhra Pradesh',
    portalName: 'AP MeeSeva Citizen Portal',
    portalUrl: 'https://onlineap.meeseva.gov.in/',
    department: 'Revenue Department, Govt of Andhra Pradesh',
    departmentTe: 'రెవెన్యూ విభాగం, ఆంధ్రప్రదేశ్ ప్రభుత్వం',
    fee: '₹35 (MeeSeva User Charge)',
    processingDays: '7 Working Days',
    description: 'Certifies continuous physical residence in an Andhra Pradesh revenue mandal for competitive examinations, quota admissions, and government recruitment.',
    descriptionTe: 'కాంపిటీటివ్ పరీక్షలు, కోటా ప్రవేశాలు మరియు ఉద్యోగాల కోసం నిర్దిష్ట మండలంలో నివాసం ఉంటున్నట్లు నిరూపించే పత్రం.',
    eligibilitySummary: [
      'Continuous residence in the specified Mandal/Municipality in Andhra Pradesh',
      'Local study proof or 7-year residential utility documentation'
    ],
    precautions: [
      'Institutions usually request study certificates for the last 7 years; verify if study certificates substitute residence proof.',
      'Check applicant name spelling matches voter list and electricity bills.'
    ],
    requiredDocumentsOrder: [
      {
        id: 'doc-aadhaar',
        name: 'Applicant Aadhaar Card',
        nameTe: 'దరఖాస్తుదారు ఆధార్ కార్డు',
        type: 'Identity Proof',
        required: true,
        isMandatory: true,
        format: 'JPG / PNG / PDF',
        instructions: 'Showing full residential address.',
        whereToGet: 'UIDAI',
        whyNeeded: 'Establishes primary identity and listed residence.'
      },
      {
        id: 'doc-residence-bills',
        name: 'Electricity Bills / House Tax Receipts (Consecutive Years)',
        nameTe: 'కరెంట్ బిల్లులు / ఇంటి పన్ను రశీదులు',
        type: 'Habitat Evidence',
        required: true,
        isMandatory: true,
        format: 'JPG / PNG / PDF',
        instructions: 'Showing uninterrupted residence in the same locality.',
        whereToGet: 'Discom / Gram Panchayat / Municipal Office',
        whyNeeded: 'Physical evidence of continuous residence over time.'
      },
      {
        id: 'doc-study-certs',
        name: 'Study / Bonafide Certificates (for Students)',
        nameTe: 'స్టడీ / బోనఫైడ్ సర్టిఫికేట్లు',
        type: 'Institutional Attendance',
        required: true,
        isMandatory: true,
        format: 'JPG / PNG / PDF',
        instructions: 'Certifying continuous study in local schools/colleges.',
        whereToGet: 'Schools / Colleges attended',
        whyNeeded: 'Determines local candidate status under Presidential Order.'
      }
    ],
    portalProcedureSteps: [
      {
        id: 'step-doc-dossier',
        label: 'Upload bills, study proofs & Aadhaar into PDF Dossier',
        labelTe: 'బిల్లులు, స్టడీ పత్రాలు మరియు ఆధార్‌ను PDF ప్యాక్‌గా మార్చండి',
        detail: 'Formatted for Tahsildar / VRO residential inspection.',
        detailTe: 'రెవెన్యూ అధికారుల పరిశీలన కోసం సిద్ధం చేయండి.',
        autoCheckOnAllDocs: true
      },
      {
        id: 'step-review-missing',
        label: 'Verify uninterrupted local residence duration',
        labelTe: 'నివాస కాలాన్ని రికార్డులతో సరిచూసుకోండి',
        detail: 'Confirm documentation covers the full span requested by recruiting agency.',
        detailTe: 'నోటిఫికేషన్‌లో పేర్కొన్న కాల వ్యవధికి సరిపోవాలి.'
      },
      {
        id: 'step-spellings',
        label: 'Check door number, ward, and mandal details',
        labelTe: 'ఇంటి నంబరు, వార్డు మరియు మండల వివరాలను సరిచూసుకోండి',
        detail: 'Ensures no errors in certificate address schedule.',
        detailTe: 'చిరునామాలో తప్పులు లేకుండా చూసుకోండి.'
      },
      {
        id: 'step-mobile-otp',
        label: 'Pay ₹35 fee at MeeSeva & complete verification',
        labelTe: 'మీసేవలో రూ.35 చెల్లించి పరిశీలన పూర్తి చేసుకోండి',
        detail: 'VRO enquiry and report submitted to Tahsildar.',
        detailTe: 'విఆర్వో నివేదిక ఆధారంగా తహశీల్దార్ ఆమోదిస్తారు.'
      },
      {
        id: 'step-launch-portal',
        label: 'Launch AP MeeSeva & Download Residence Certificate',
        labelTe: 'మీసేవ పోర్టల్ తెరిచి సర్టిఫికేట్ డౌన్‌లోడ్ చేసుకోండి',
        detail: 'Download digitally authenticated certificate.',
        detailTe: 'డిజిటల్ సంతకంతో కూడిన సర్టిఫికేట్ పొందండి.'
      }
    ]
  },
  {
    id: 'ap-vidya-deevena',
    title: 'Jagananna Vidya Deevena & Vasathi Deevena (Fee Reimbursement)',
    titleTe: 'జగనన్న విద్యా దీవెన & వసతి దీవెన (ఫీజు రీయింబర్స్‌మెంట్)',
    shortName: 'Vidya Deevena',
    category: 'Scholarships',
    state: 'Andhra Pradesh',
    portalName: 'AP Jnanabhumi Portal',
    portalUrl: 'https://jnanabhumi.ap.gov.in/',
    department: 'Social Welfare & Higher Education Department, AP',
    departmentTe: 'సాంఘిక సంక్షేమం & ఉన్నత విద్యా శాఖ, ఆంధ్రప్రదేశ్',
    fee: 'Free of Cost (State Welfare Scheme)',
    processingDays: 'Quarterly Academic Tranches',
    description: 'Complete college tuition fee reimbursement (Vidya Deevena) and boarding/mess assistance of up to ₹20,000/year (Vasathi Deevena) credited directly to student mother bank accounts.',
    descriptionTe: 'ఐటీఐ, పాలిటెక్నిక్, డిగ్రీ, ఇంజనీరింగ్ విద్యార్థులకు పూర్తి కాలేజ్ ఫీజు రీయింబర్స్‌మెంట్ మరియు హాస్టల్ ఖర్చుల సహాయం.',
    eligibilitySummary: [
      'Students pursuing ITI, Polytechnic, Degree, Engineering, Medicine, and PG courses',
      'Total annual family income must be below ₹2,50,000 per annum',
      'Landholding below 10 acres wetland or 25 acres dryland',
      'Must maintain at least 75% biometric attendance in college'
    ],
    precautions: [
      'Bank account must belong to the biological mother of the student and be Aadhaar-seeded.',
      'Maintain 75% biometric attendance; attendance shortages stop scholarship tranches.'
    ],
    requiredDocumentsOrder: [
      {
        id: 'doc-student-aadhaar',
        name: 'Student & Mother Aadhaar Cards',
        nameTe: 'విద్యార్థి & తల్లి ఆధార్ కార్డులు',
        type: 'Beneficiary & Payee Identity',
        required: true,
        isMandatory: true,
        format: 'JPG / PNG / PDF',
        instructions: 'Clear copies of student and biological mother Aadhaar cards.',
        whereToGet: 'UIDAI Portal',
        whyNeeded: 'Direct Benefit Transfer (DBT) is credited into the mother account.'
      },
      {
        id: 'doc-income-cert',
        name: 'Valid Tahsildar Income Certificate (< ₹2,50,000)',
        nameTe: 'తహశీల్దార్ ఆదాయ ధ్రువీకరణ పత్రం (< రూ.2,50,000)',
        type: 'Economic Proof',
        required: true,
        isMandatory: true,
        format: 'JPG / PNG / PDF',
        instructions: 'Current financial year revenue income certificate.',
        whereToGet: 'AP MeeSeva / AP Seva',
        whyNeeded: 'Verifies family income is under 2.5 Lakhs.'
      },
      {
        id: 'doc-caste-cert',
        name: 'Integrated Caste Certificate (SC/ST/BC/EBC/Kapu/Minority)',
        nameTe: 'కుల ధ్రువీకరణ పత్రం',
        type: 'Category Verification',
        required: true,
        isMandatory: true,
        format: 'JPG / PNG / PDF',
        instructions: 'Official revenue integrated certificate.',
        whereToGet: 'AP Seva Portal',
        whyNeeded: 'Determines welfare department funding head.'
      },
      {
        id: 'doc-mother-bank',
        name: 'Mother Aadhaar-Linked Bank Passbook',
        nameTe: 'తల్లి ఆధార్ లింక్డ్ బ్యాంక్ పాస్‌బుక్',
        type: 'DBT Bank Account',
        required: true,
        isMandatory: true,
        format: 'JPG / PNG / PDF',
        instructions: 'Showing Account number, IFSC, and mother name.',
        whereToGet: 'Bank Branch / Passbook',
        whyNeeded: 'Mandatory recipient account for college tuition reimbursement.'
      },
      {
        id: 'doc-admission-allotment',
        name: 'Convenor Quota College Allotment Order',
        nameTe: 'కన్వీనర్ కోటా కాలేజ్ అలాట్‌మెంట్ ఆర్డర్',
        type: 'Academic Admission Proof',
        required: true,
        isMandatory: true,
        format: 'JPG / PNG / PDF',
        instructions: 'Issued during EAPCET/ICET/ECET/PGCET counselling.',
        whereToGet: 'AP Higher Education Admission Portal',
        whyNeeded: 'Mandatory proof of admission through merit convenor quota.'
      }
    ],
    portalProcedureSteps: [
      {
        id: 'step-doc-dossier',
        label: 'Upload mother bank, income, caste & allotment order into PDF Dossier',
        labelTe: 'తల్లి బ్యాంక్ పాస్‌బుక్, ఆదాయం, కులం మరియు అలాట్‌మెంట్ ఆర్డర్‌ను PDF ప్యాక్‌గా రూపొందించండి',
        detail: 'Structured for College Principal & Welfare Officer e-KYC.',
        detailTe: 'కాలేజ్ ప్రిన్సిపాల్ మరియు సంక్షేమ అధికారి పరిశీలన కోసం సిద్ధం చేయండి.',
        autoCheckOnAllDocs: true
      },
      {
        id: 'step-review-missing',
        label: 'Check NPCI Aadhaar bank mapping status of mother account',
        labelTe: 'తల్లి బ్యాంక్ ఖాతాకు ఎన్‌పీసీఐ ఆధార్ మ్యాపింగ్ అయిందో లేదో చూడండి',
        detail: 'Unlinked bank accounts reject DBT payments from state treasury.',
        detailTe: 'లింక్ కాకపోతే ట్రెజరీ నుంచి డబ్బులు రావు.'
      },
      {
        id: 'step-spellings',
        label: 'Ensure 75% college biometric attendance is registered',
        labelTe: 'కాలేజీలో 75% బయోమెట్రిక్ హాజరు నమోదయ్యేలా చూసుకోండి',
        detail: 'Tranches are automatically held back if monthly attendance drops below 75%.',
        detailTe: 'హాజరు తగ్గితే ఫీజు విడుదల నిలిపివేయబడుతుంది.'
      },
      {
        id: 'step-mobile-otp',
        label: 'Complete Student & Mother Biometric e-KYC at College',
        labelTe: 'కాలేజీలో విద్యార్థి & తల్లి బయోమెట్రిక్ ఈ-కేవైసీ పూర్తి చేయండి',
        detail: 'Dual biometric authentication confirms admission continuation.',
        detailTe: 'ఇద్దరూ బయోమెట్రిక్ వేయడం తప్పనిసరి.'
      },
      {
        id: 'step-launch-portal',
        label: 'Launch Jnanabhumi Portal & Track Release Tranches',
        labelTe: 'జ్ఞానభూమి పోర్టల్ తెరిచి ఫీజు జమ వివరాలు ట్రాక్ చేయండి',
        detail: 'Monitor instalment credit directly into mother bank account.',
        detailTe: 'డబ్బులు జమయ్యే వివరాలను లైవ్‌లో చూడండి.'
      }
    ]
  },
  {
    id: 'ap-nmms-scholarship',
    title: 'AP National Means-cum-Merit Scholarship (NMMS)',
    titleTe: 'ఏపీ నేషనల్ మీన్స్-కమ్-మెరిట్ స్కాలర్‌షిప్ (NMMS)',
    shortName: 'NMMS Scholarship',
    category: 'Scholarships',
    state: 'Andhra Pradesh',
    portalName: 'BSE AP & National Scholarship Portal (NSP)',
    portalUrl: 'https://bse.ap.gov.in/',
    department: 'Directorate of Government Examinations, AP',
    departmentTe: 'ప్రభుత్వ పరీక్షల డైరెక్టరేట్, ఆంధ్రప్రదేశ్',
    fee: '₹100 (Exam Fee for General/BC) / ₹50 (SC/ST)',
    processingDays: 'Annual Academic Cycle',
    description: 'Centrally sponsored scholarship for meritorious Class VIII students in Government, Local Body, and Aided schools. Selected students receive ₹12,000/year from Class IX to XII.',
    descriptionTe: 'ప్రభుత్వ పాఠశాలల్లో 8వ తరగతి చదువుతున్న ప్రతిభావంతులైన పేద విద్యార్థులకు ఏటా రూ.12,000 అందించే జాతీయ స్కాలర్‌షిప్.',
    eligibilitySummary: [
      'Currently studying in Class VIII in AP Government, ZP, Municipal, or Aided school',
      'Minimum 55% marks (50% for SC/ST) in Class VII examination',
      'Parental annual income from all sources must not exceed ₹3,50,000 per annum',
      'Must appear and qualify in the state NMMS exam conducted by BSE AP'
    ],
    precautions: [
      'Dates and notifications change by academic year. Check official BSE AP notifications.',
      'Students in private unaided schools or Navodaya schools are not eligible.'
    ],
    requiredDocumentsOrder: [
      {
        id: 'doc-class7-marks',
        name: 'Class VII Marks Memo / Promotion Certificate',
        nameTe: '7వ తరగతి మార్కుల మెమో / ప్రమోషన్ సర్టిఫికేట్',
        type: 'Academic Eligibility',
        required: true,
        isMandatory: true,
        format: 'JPG / PNG / PDF',
        instructions: 'Signed by school Headmaster certifying minimum 55% marks.',
        whereToGet: 'School Headmaster / Principal',
        whyNeeded: 'Verifies qualifying academic score requirement.'
      },
      {
        id: 'doc-tahsildar-income',
        name: 'Tahsildar Income Certificate (< ₹3,50,000)',
        nameTe: 'తహశీల్దార్ ఆదాయ ధ్రువీకరణ పత్రం (< రూ.3,50,000)',
        type: 'Economic Eligibility',
        required: true,
        isMandatory: true,
        format: 'JPG / PNG / PDF',
        instructions: 'Issued in the current financial year showing total parental income.',
        whereToGet: 'MeeSeva / Tahsildar Office',
        whyNeeded: 'Mandatory proof of family income below 3.5 Lakhs.'
      },
      {
        id: 'doc-caste-cert',
        name: 'Integrated Caste Certificate (for SC/ST/BC students)',
        nameTe: 'కుల ధ్రువీకరణ పత్రం (SC/ST/BC విద్యార్థులకు)',
        type: 'Reservation Category',
        required: true,
        isMandatory: true,
        format: 'JPG / PNG / PDF',
        instructions: 'Valid revenue caste certificate issued by Tahsildar.',
        whereToGet: 'MeeSeva / AP Seva',
        whyNeeded: 'Determines quota cutoff and relaxation eligibility.'
      },
      {
        id: 'doc-student-bank',
        name: 'Student Aadhaar-Seeded Bank Passbook',
        nameTe: 'విద్యార్థి ఆధార్ లింక్డ్ బ్యాంక్ పాస్‌బుక్',
        type: 'DBT Payment Account',
        required: true,
        isMandatory: true,
        format: 'JPG / PNG / PDF',
        instructions: 'Bank account in the name of the student, seeded with Aadhaar.',
        whereToGet: 'Bank Branch / India Post Payments Bank',
        whyNeeded: 'Mandatory for direct annual deposit of ₹12,000 scholarship via DBT.'
      },
      {
        id: 'doc-study-cert',
        name: 'Bonafide / Study Certificate from School Headmaster',
        nameTe: 'బోనఫైడ్ / స్టడీ సర్టిఫికేట్ (పాఠశాల ప్రధానోపాధ్యాయుల నుండి)',
        type: 'School Verification',
        required: true,
        isMandatory: true,
        format: 'JPG / PNG / PDF',
        instructions: 'Certifying student is studying in Class VIII in Govt/ZP/Municipal/Aided school.',
        whereToGet: 'School Headmaster',
        whyNeeded: 'Proves current study in eligible recognized government school.'
      }
    ],
    portalProcedureSteps: [
      {
        id: 'step-doc-dossier',
        label: 'Upload marks memo, income & bank proofs into PDF Dossier',
        labelTe: 'మార్కుల మెమో, ఆదాయ మరియు బ్యాంక్ పత్రాలను PDF ప్యాక్‌గా సిద్ధం చేయండి',
        detail: 'Structured in exact sequence for Headmaster & BSE AP verification.',
        detailTe: 'పాఠశాల హెచ్‌ఎం మరియు పరీక్షల బోర్డు పరిశీలన కోసం సిద్ధం చేయండి.',
        autoCheckOnAllDocs: true
      },
      {
        id: 'step-review-missing',
        label: 'Confirm bank account is in student name and seeded with Aadhaar',
        labelTe: 'బ్యాంక్ ఖాతా విద్యార్థి పేరు మీద ఉండి ఆధార్‌తో లింక్ అయిందో లేదో చూడండి',
        detail: 'Parent accounts will result in DBT payment rejections on NSP.',
        detailTe: 'తల్లిదండ్రుల ఖాతా ఇస్తే డీబీటీ పేమెంట్ రద్దు కావచ్చు.'
      },
      {
        id: 'step-spellings',
        label: 'Submit examination application via School Headmaster on BSE AP',
        labelTe: 'హెచ్‌ఎం ద్వారా బీఎస్ఈ ఏపీ పోర్టల్‌లో పరీక్షకు దరఖాస్తు చేయండి',
        detail: 'Download hall ticket and appear for MAT and SAT examination.',
        detailTe: 'హాల్ టికెట్ డౌన్‌లోడ్ చేసుకుని మ్యాట్ మరియు సాట్ పరీక్షలు రాయండి.'
      },
      {
        id: 'step-mobile-otp',
        label: 'Qualify in State Merit List published by BSE AP',
        labelTe: 'బీఎస్ఈ ఏపీ ప్రకటించే రాష్ట్ర మెరిట్ జాబితాలో ఎంపికవ్వండి',
        detail: 'District quota cutoffs released after evaluation.',
        detailTe: 'జిల్లాల వారీగా ఎంపికైన వారి వివరాలు ప్రకటిస్తారు.'
      },
      {
        id: 'step-launch-portal',
        label: 'Complete One-Time Registration (OTR) on National Scholarship Portal',
        labelTe: 'నేషనల్ స్కాలర్‌షిప్ పోర్టల్ (NSP) లో వన్-టైమ్ రిజిస్ట్రేషన్ పూర్తి చేయండి',
        detail: 'Annual disbursement of ₹12,000 credited to student account.',
        detailTe: 'ఏటా రూ.12,000 విద్యార్థి ఖాతాలో జమ చేయబడుతుంది.'
      }
    ]
  },
  {
    id: 'central-nsp-scholarship',
    title: 'National Scholarship Portal (NSP Post-Matric & Pre-Matric)',
    titleTe: 'నేషనల్ స్కాలర్‌షిప్ పోర్టల్ (ఎన్‌ఎస్‌పీ పోస్ట్-మెట్రిక్ & ప్రీ-మెట్రిక్)',
    shortName: 'NSP Scholarships',
    category: 'Scholarships',
    state: 'Central / All India',
    portalName: 'National Scholarship Portal (NSP)',
    portalUrl: 'https://scholarships.gov.in/',
    department: 'Ministry of Electronics & Information Technology, Govt of India',
    departmentTe: 'ఎలక్ట్రానిక్స్ & ఐటీ మంత్రిత్వ శాఖ, భారత ప్రభుత్వం',
    fee: 'Free of Cost (Govt Portal)',
    processingDays: 'Annual Disbursement Cycle',
    description: 'Central portal facilitating state and central scholarships (Post-Matric for SC/ST/OBC/Minorities, Central Sector Scheme for College/University Students, CSIS, etc.).',
    descriptionTe: 'కేంద్ర మరియు రాష్ట్ర ప్రభుత్వాల వివిధ రకాల స్కాలర్‌షిప్‌ల కోసం ఏకీకృత జాతీయ పోర్టల్.',
    eligibilitySummary: [
      'Students enrolled in recognized schools, ITIs, colleges, or universities',
      'Meeting scheme-specific income ceilings (typically ₹1.5L to ₹2.5L)',
      'Minimum qualifying marks in prior exam (e.g. 50% or 80th percentile for CSSS)'
    ],
    precautions: [
      'NSP now mandates One-Time Registration (OTR) with face authentication or mobile OTP.',
      'Bank account must be in the student own name and NPCI-mapped.'
    ],
    requiredDocumentsOrder: [
      {
        id: 'doc-student-aadhaar',
        name: 'Student Aadhaar Card (with Linked Mobile)',
        nameTe: 'విద్యార్థి ఆధార్ కార్డు (మొబైల్ లింక్డ్)',
        type: 'Identity Proof',
        required: true,
        isMandatory: true,
        format: 'JPG / PNG / PDF',
        instructions: 'Active mobile linked for NSP OTR e-KYC.',
        whereToGet: 'UIDAI',
        whyNeeded: 'Prerequisite for NSP One-Time Registration (OTR).'
      },
      {
        id: 'doc-bonafide-cert',
        name: 'Institution Bonafide / Enrolment Certificate',
        nameTe: 'కాలేజ్ బోనఫైడ్ / ఎన్‌రోల్‌మెంట్ సర్టిఫికేట్',
        type: 'Academic Verification',
        required: true,
        isMandatory: true,
        format: 'JPG / PNG / PDF',
        instructions: 'Signed by Principal/Registrar with AISHE institute code.',
        whereToGet: 'College/University Office',
        whyNeeded: 'Verifies active enrollment in an authorized educational institution.'
      },
      {
        id: 'doc-previous-memo',
        name: 'Previous Qualifying Exam Marks Sheet',
        nameTe: 'మునుపటి పరీక్ష మార్కుల మెమో',
        type: 'Academic Merit',
        required: true,
        isMandatory: true,
        format: 'JPG / PNG / PDF',
        instructions: 'Showing percentage/grades achieved in the last academic year.',
        whereToGet: 'School / University Board',
        whyNeeded: 'Confirms qualifying percentage score.'
      },
      {
        id: 'doc-income-proof',
        name: 'Competent Authority Income Certificate',
        nameTe: 'తహశీల్దార్ ఆదాయ ధ్రువీకరణ పత్రం',
        type: 'Economic Eligibility',
        required: true,
        isMandatory: true,
        format: 'JPG / PNG / PDF',
        instructions: 'Issued by Tahsildar/Revenue Authority.',
        whereToGet: 'MeeSeva / Revenue Office',
        whyNeeded: 'Validates family income falls within ceiling.'
      },
      {
        id: 'doc-npci-bank',
        name: 'Aadhaar Seeded Bank Account Passbook Copy',
        nameTe: 'ఆధార్ లింక్డ్ బ్యాంక్ పాస్‌బుక్ కాపీ',
        type: 'DBT Bank Account',
        required: true,
        isMandatory: true,
        format: 'JPG / PNG / PDF',
        instructions: 'Showing IFSC, account number, and student name.',
        whereToGet: 'Bank Branch',
        whyNeeded: 'Destination for DBT scholarship fund credits.'
      }
    ],
    portalProcedureSteps: [
      {
        id: 'step-doc-dossier',
        label: 'Upload academic memos, bonafide & income proofs into PDF Dossier',
        labelTe: 'మార్కులు, బోనఫైడ్ మరియు ఆదాయ ఆధారాలను PDF ప్యాక్‌గా రూపొందించండి',
        detail: 'Formatted for Institute Nodal Officer (INO) and District verification.',
        detailTe: 'కాలేజీ నోడల్ అధికారి పరిశీలన కోసం సిద్ధం చేయండి.',
        autoCheckOnAllDocs: true
      },
      {
        id: 'step-review-missing',
        label: 'Check AISHE / DISE code of your school or college',
        labelTe: 'మీ విద్యాసంస్థ కోడ్ సరిగా ఉందో లేదో సరిచూసుకోండి',
        detail: 'Unlisted institutions cannot authenticate applications on NSP.',
        detailTe: 'గుర్తింపు లేని సంస్థల దరఖాస్తులు ఆమోదించబడవు.'
      },
      {
        id: 'step-spellings',
        label: 'Complete One-Time Registration (OTR) on NSP portal',
        labelTe: 'ఎన్‌ఎస్‌పీ పోర్టల్‌లో వన్-టైమ్ రిజిస్ట్రేషన్ (OTR) పూర్తి చేయండి',
        detail: 'Generate 14-digit OTR number via Aadhaar biometric or OTP.',
        detailTe: '14 అంకెల ఓటీఆర్ నంబర్ పొందండి.'
      },
      {
        id: 'step-mobile-otp',
        label: 'Apply for eligible Central/State scheme under student login',
        labelTe: 'విద్యార్థి లాగిన్ ద్వారా అర్హత గల పథకానికి దరఖాస్తు చేయండి',
        detail: 'Save application number for institute nodal officer tracking.',
        detailTe: 'దరఖాస్తు నంబర్ భద్రపరచుకోండి.'
      },
      {
        id: 'step-launch-portal',
        label: 'Launch NSP scholarships.gov.in & Submit Application',
        labelTe: 'ఎన్‌ఎస్‌పీ పోర్టల్ తెరిచి దరఖాస్తు సమర్పించండి',
        detail: 'Track multi-level verification (INO -> DNO -> SNO -> PFMS).',
        detailTe: 'వెరిఫికేషన్ స్థితిని ఆన్‌లైన్‌లో ట్రాక్ చేయండి.'
      }
    ]
  },
  {
    id: 'ap-sadarem-udid',
    title: 'AP SADAREM & Unique Disability ID (UDID) Card',
    titleTe: 'సదరం (SADAREM) & ప్రత్యేక దివ్యాంగుల గుర్తింపు కార్డు (UDID)',
    shortName: 'Disability / UDID',
    category: 'Social Security',
    state: 'Andhra Pradesh',
    portalName: 'Swavlamban UDID Portal / AP SADAREM',
    portalUrl: 'https://www.swavlambancard.gov.in/',
    department: 'Department of Empowerment of Persons with Disabilities, GoI / AP',
    departmentTe: 'దివ్యాంగుల సంక్షేమ శాఖ',
    fee: 'Free of Cost (Govt Welfare)',
    processingDays: 'Medical Board Assessment Cycle',
    description: 'Standardized national disability certificate and smart card issued following medical assessment by Government Medical Board, providing welfare pensions, transport concessions, and reservations.',
    descriptionTe: 'ప్రభుత్వ మెడికల్ బోర్డు పరీక్ష ద్వారా దివ్యాంగులకు అందించే జాతీయ గుర్తింపు కార్డు, పెన్షన్లు మరియు రిజర్వేషన్లకు ఆధారం.',
    eligibilitySummary: [
      'Person having 40% or more specified disability (locomotor, visual, hearing, mental, intellectual, etc.)',
      'Assessed and certified by government specialist medical authority'
    ],
    precautions: [
      'Slot booking is mandatory for hospital assessment camp at District Hospital.',
      'Carry past clinical treatment records, surgical notes, and therapy cards.'
    ],
    requiredDocumentsOrder: [
      {
        id: 'doc-aadhaar',
        name: 'Applicant Aadhaar Card',
        nameTe: 'దరఖాస్తుదారు ఆధార్ కార్డు',
        type: 'Identity Proof',
        required: true,
        isMandatory: true,
        format: 'JPG / PNG / PDF',
        instructions: 'Clear copy showing full name and address.',
        whereToGet: 'UIDAI',
        whyNeeded: 'Core national identity key for UDID database.'
      },
      {
        id: 'doc-disability-photo',
        name: 'Full Length / Disability Photograph',
        nameTe: 'దివ్యాంగత్వాన్ని చూపే పూర్తి ఫోటో',
        type: 'Clinical Photographic Evidence',
        required: true,
        isMandatory: true,
        format: 'JPG / PNG',
        instructions: 'Showing the physical nature of disability clearly.',
        whereToGet: 'Photo Studio',
        whyNeeded: 'Printed on the UDID Smart Card.'
      },
      {
        id: 'doc-medical-records',
        name: 'Medical History / Hospital Treatment Records',
        nameTe: 'చికిత్స రికార్డులు / ఆసుపత్రి రిపోర్టులు',
        type: 'Clinical Diagnostics',
        required: true,
        isMandatory: true,
        format: 'JPG / PNG / PDF',
        instructions: 'Doctor prescription, surgery discharge summary, audiogram, or clinical psychometric test.',
        whereToGet: 'Government Hospital / Specialist Physician',
        whyNeeded: 'Assists Medical Board specialists during percentage determination.'
      }
    ],
    portalProcedureSteps: [
      {
        id: 'step-doc-dossier',
        label: 'Upload medical history, photos & Aadhaar into PDF Dossier',
        labelTe: 'వైద్య రికార్డులు, ఫోటోలు మరియు ఆధార్‌ను PDF ప్యాక్‌గా సిద్ధం చేయండి',
        detail: 'Formatted for Medical Board clinical assessment.',
        detailTe: 'మెడికల్ బోర్డు పరిశీలన కోసం సిద్ధం చేయండి.',
        autoCheckOnAllDocs: true
      },
      {
        id: 'step-review-missing',
        label: 'Book Medical Board assessment camp slot at District Hospital',
        labelTe: 'జిల్లా ఆసుపత్రి మెడికల్ క్యాంప్ స్లాట్ బుక్ చేసుకోండి',
        detail: 'Choose nearest Government Headquarters Hospital on portal.',
        detailTe: 'సమీప ప్రభుత్వ ఆసుపత్రిని ఎంచుకోండి.'
      },
      {
        id: 'step-spellings',
        label: 'Attend physical medical board assessment with original files',
        labelTe: 'అసలు పత్రాలతో మెడికల్ బోర్డు పరీక్షకు హాజరవండి',
        detail: 'Specialists examine and calculate permanent disability percentage.',
        detailTe: 'వైద్యులు పరీక్షించి వైకల్యం శాతాన్ని నిర్ణయిస్తారు.'
      },
      {
        id: 'step-mobile-otp',
        label: 'Medical authority uploads assessment score to Swavlamban',
        labelTe: 'వైద్యాధికారులు పోర్టల్‌లో పరీక్ష వివరాలు నమోదు చేస్తారు',
        detail: 'SADAREM / UDID certificate generated with QR code.',
        detailTe: 'క్యూఆర్ కోడ్‌తో సర్టిఫికేట్ తయారవుతుంది.'
      },
      {
        id: 'step-launch-portal',
        label: 'Download UDID E-Card from swavlambancard.gov.in',
        labelTe: 'పోర్టల్ నుండి యూడీఐడీ ఈ-కార్డు డౌన్‌లోడ్ చేసుకోండి',
        detail: 'Avail NTR/YSR Bharosa pension, rail concessions, and schemes.',
        detailTe: 'పెన్షన్ మరియు రాయితీలను పొందండి.'
      }
    ]
  },
  {
    id: 'ap-ssc-duplicate-memo',
    title: 'Duplicate SSC Marks Memo / Migration Certificate',
    titleTe: 'డూప్లికేట్ ఎస్సెస్సీ మార్కుల మెమో / మైగ్రేషన్ సర్టిఫికేట్',
    shortName: 'SSC Duplicate Memo',
    category: 'Identity & Utility',
    state: 'Andhra Pradesh',
    portalName: 'BSE Andhra Pradesh Portal',
    portalUrl: 'https://bse.ap.gov.in/',
    department: 'Directorate of Government Examinations, Andhra Pradesh',
    departmentTe: 'ప్రభుత్వ పరీక్షల డైరెక్టరేట్, ఆంధ్రప్రదేశ్',
    fee: '₹250 (Govt Challan Fee for Duplicate)',
    processingDays: '15 to 30 Working Days',
    description: 'Issued by the Board of Secondary Education AP if the original SSC (10th Class) marks memo is lost, damaged, destroyed, or when an official migration certificate is needed.',
    descriptionTe: 'ఒరిజినల్ 10వ తరగతి మార్కుల మెమో పోయినా లేదా పాడైనా బోర్డు నుండి డూప్లికేట్ కాపీ పొందే సేవ.',
    eligibilitySummary: [
      'Candidate who appeared and passed AP SSC examination',
      'If lost: Police Missing Certificate / Non-Traceable Certificate is mandatory'
    ],
    precautions: [
      'Obtain an official police non-traceable certificate or endorsement before applying.',
      'Keep your SSC Roll number, month and year of passing ready.'
    ],
    requiredDocumentsOrder: [
      {
        id: 'doc-police-missing',
        name: 'Police Non-Traceable Certificate (if lost)',
        nameTe: 'పోలీస్ నాన్-ట్రేసబుల్ సర్టిఫికేట్ (పోయినట్లయితే)',
        type: 'Loss Substantiation',
        required: true,
        isMandatory: true,
        format: 'JPG / PNG / PDF',
        instructions: 'Issued by local police station certifying original memo cannot be traced.',
        whereToGet: 'Local Police Station / AP Police Citizen Portal',
        whyNeeded: 'Legal prerequisite certifying the original certificate was irretrievably lost.'
      },
      {
        id: 'doc-headmaster-affidavit',
        name: 'School Headmaster Identification Certificate & Affidavit',
        nameTe: 'పాఠశాల హెచ్‌ఎం ధ్రువీకరణ & అఫిడవిట్',
        type: 'School Endorsement',
        required: true,
        isMandatory: true,
        format: 'JPG / PNG / PDF',
        instructions: 'Certified by Headmaster where candidate studied Class X.',
        whereToGet: 'School Headmaster / Notary Advocate',
        whyNeeded: 'Validates candidate identity against school counter-foil register.'
      },
      {
        id: 'doc-challan-receipt',
        name: 'Treasury Challan Receipt (CFMS AP)',
        nameTe: 'ట్రెజరీ చలానా రశీదు (CFMS AP)',
        type: 'Fee Payment Proof',
        required: true,
        isMandatory: true,
        format: 'JPG / PNG / PDF',
        instructions: 'Government treasury challan paid under BSE AP head of account.',
        whereToGet: 'CFMS AP Citizen Portal / SBI Branch',
        whyNeeded: 'Proof of prescribed government fee payment.'
      },
      {
        id: 'doc-candidate-aadhaar',
        name: 'Candidate Aadhaar Card Copy',
        nameTe: 'అభ్యర్థి ఆధార్ కార్డు కాపీ',
        type: 'Identity Proof',
        required: true,
        isMandatory: true,
        format: 'JPG / PNG / PDF',
        instructions: 'Clear copy showing candidate photo and name.',
        whereToGet: 'UIDAI',
        whyNeeded: 'Verifies candidate identity before issuing duplicate legal credential.'
      }
    ],
    portalProcedureSteps: [
      {
        id: 'step-doc-dossier',
        label: 'Upload police certificate, challan & headmaster affidavit into PDF Dossier',
        labelTe: 'పోలీస్ సర్టిఫికేట్, చలానా మరియు హెచ్‌ఎం అఫిడవిట్‌లను PDF ప్యాక్‌గా సిద్ధం చేయండి',
        detail: 'Formatted for BSE AP Assistant Commissioner review.',
        detailTe: 'పరీక్షల బోర్డు అధికారుల పరిశీలన కోసం సిద్ధం చేయండి.',
        autoCheckOnAllDocs: true
      },
      {
        id: 'step-review-missing',
        label: 'Pay CFMS government challan under BSE AP Head of Account',
        labelTe: 'సీఎఫ్‌ఎంఎస్ పోర్టల్‌లో బోర్డు నిర్దేశిత చలానా చెల్లించండి',
        detail: 'Save CFMS transaction ID and printable receipt.',
        detailTe: 'చలానా నంబర్ మరియు రశీదు భద్రపరచుకోండి.'
      },
      {
        id: 'step-spellings',
        label: 'Double-check Hall Ticket Number, Year & Month of Exam',
        labelTe: 'హాల్ టికెట్ నంబర్, పరీక్ష సంవత్సరం మరియు నెలను సరిచూసుకోండి',
        detail: 'Prevents matching failures against archived tabulation registers.',
        detailTe: 'బోర్డు పాత రికార్డులతో సరిపోలడానికి ఖచ్చితమైన వివరాలు ఇవ్వాలి.'
      },
      {
        id: 'step-mobile-otp',
        label: 'Submit online form on bse.ap.gov.in or via DEO Office',
        labelTe: 'బీఎస్ఈ ఏపీ పోర్టల్ లేదా డీఈవో కార్యాలయం ద్వారా సమర్పించండి',
        detail: 'Application dispatched to DGE office in Gollapudi, Vijayawada.',
        detailTe: 'విజయవాడలోని పరీక్షల బోర్డు కార్యాలయానికి వెళ్తుంది.'
      },
      {
        id: 'step-launch-portal',
        label: 'Track Dispatch & Receive Duplicate Marks Memo by Speed Post',
        labelTe: 'స్పీడ్ పోస్ట్ ద్వారా డూప్లికేట్ మెమో పొందండి',
        detail: 'Collect officially sealed duplicate credential.',
        detailTe: 'అధికారిక డూప్లికేట్ మెమోను స్పీడ్ పోస్ట్‌లో అందుకోండి.'
      }
    ]
  },
  {
    id: 'ap-inter-memo-migration',
    title: 'AP Intermediate Marks Memo, Duplicate & Migration',
    titleTe: 'ఏపీ ఇంటర్మీడియట్ మార్కుల మెమో & మైగ్రేషన్ సర్టిఫికేట్',
    shortName: 'Inter Marks & Migration',
    category: 'Identity & Utility',
    state: 'Andhra Pradesh',
    portalName: 'Board of Intermediate Education AP (BIE AP)',
    portalUrl: 'https://bie.ap.gov.in/',
    department: 'Board of Intermediate Education, Andhra Pradesh',
    departmentTe: 'ఇంటర్మీడియట్ విద్యా మండలి, ఆంధ్రప్రదేశ్',
    fee: '₹100 - ₹500 (Depending on Service)',
    processingDays: '3 to 10 Working Days',
    description: 'Online certificates issuance portal for Intermediate Pass Certificates, Duplicate Marks Memos, Migration Certificates, and Name Corrections.',
    descriptionTe: 'ఇంటర్మీడియట్ విద్యార్థుల కోసం మైగ్రేషన్ సర్టిఫికేట్, డూప్లికేట్ మార్కుల మెమో పొందే అధికారిక పోర్టల్.',
    eligibilitySummary: [
      'Student completed Intermediate 1st or 2nd year examinations in Andhra Pradesh',
      'Requires Inter Hall Ticket Number and college details'
    ],
    precautions: [
      'Migration certificate is required for university admissions outside Andhra Pradesh.',
      'Digital certificates downloaded with QR code are legally valid under IT Act.'
    ],
    requiredDocumentsOrder: [
      {
        id: 'doc-hall-ticket',
        name: 'Inter Hall Ticket or College Admission Receipt',
        nameTe: 'ఇంటర్ హాల్ టికెట్ లేదా కాలేజ్ రశీదు',
        type: 'Exam Reference',
        required: true,
        isMandatory: true,
        format: 'JPG / PNG / PDF',
        instructions: 'Showing 10-digit Intermediate Hall Ticket number.',
        whereToGet: 'Junior College Principal / BIE AP Records',
        whyNeeded: 'Locates candidate digital records on BIE server.'
      },
      {
        id: 'doc-student-id',
        name: 'Student Aadhaar Card',
        nameTe: 'విద్యార్థి ఆధార్ కార్డు',
        type: 'Identity Proof',
        required: true,
        isMandatory: true,
        format: 'JPG / PNG / PDF',
        instructions: 'Matching student name and parent details.',
        whereToGet: 'UIDAI',
        whyNeeded: 'Validates student identity.'
      },
      {
        id: 'doc-police-cert',
        name: 'Police Certificate (Only if applying for Duplicate memo)',
        nameTe: 'పోలీస్ సర్టిఫికేట్ (డూప్లికేట్ కోసం మాత్రమే)',
        type: 'Loss Substantiation',
        required: false,
        isMandatory: false,
        format: 'JPG / PNG / PDF',
        instructions: 'Mandatory only for duplicate memo if original was lost.',
        whereToGet: 'Police Station',
        whyNeeded: 'Not required for regular Migration certificate.'
      }
    ],
    portalProcedureSteps: [
      {
        id: 'step-doc-dossier',
        label: 'Upload Hall Ticket copy and Aadhaar into PDF Dossier',
        labelTe: 'హాల్ టికెట్ మరియు ఆధార్‌ను PDF ప్యాక్‌గా రూపొందించండి',
        detail: 'Ready for BIE AP digital certificate generation.',
        detailTe: 'ఇంటర్ బోర్డు పోర్టల్ కోసం సిద్ధం చేయండి.',
        autoCheckOnAllDocs: true
      },
      {
        id: 'step-review-missing',
        label: 'Select service: Migration Certificate / Duplicate Memo',
        labelTe: 'మైగ్రేషన్ సర్టిఫికేట్ లేదా డూప్లికేట్ మెమో సేవను ఎంచుకోండి',
        detail: 'Verify exact fee payment on BIE AP payment gateway.',
        detailTe: 'సరైన సేవను మరియు రుసుమును ఎంచుకోండి.'
      },
      {
        id: 'step-spellings',
        label: 'Confirm student name and college center code',
        labelTe: 'విద్యార్థి పేరు మరియు కాలేజ్ కోడ్‌ను సరిచూసుకోండి',
        detail: 'Cross-checked against BIE AP electronic master database.',
        detailTe: 'బోర్డు రికార్డులతో సరిపోవాలి.'
      },
      {
        id: 'step-mobile-otp',
        label: 'Pay user fee online via UPI / Netbanking',
        labelTe: 'యూపీఐ లేదా నెట్‌బ్యాంకింగ్ ద్వారా రుసుము చెల్లించండి',
        detail: 'Instant generation of e-Challan receipt.',
        detailTe: 'చెల్లింపు రశీదు పొందండి.'
      },
      {
        id: 'step-launch-portal',
        label: 'Launch BIE AP & Instantly Download Digitally Signed Certificate',
        labelTe: 'బీఐఈ ఏపీ పోర్టల్ తెరిచి డిజిటల్ సర్టిఫికేట్ డౌన్‌లోడ్ చేసుకోండి',
        detail: 'Download verifiable PDF with security QR code.',
        detailTe: 'క్యూఆర్ కోడ్‌తో కూడిన అధికారిక పత్రం పొందండి.'
      }
    ]
  },
  {
    id: 'pm-kisan',
    title: 'PM-KISAN & AP Rythu Seva (Farmer Assistance & e-Crop)',
    titleTe: 'పీఎం-కిసాన్ & రైతు సేవ (రైతు భరోసా & ఈ-క్రాప్ నమోదు)',
    shortName: 'PM-KISAN & Farmer',
    category: 'Agriculture',
    state: 'Central / All India',
    portalName: 'PM-KISAN Official Portal & AP e-Panta',
    portalUrl: 'https://pmkisan.gov.in/',
    department: 'Ministry of Agriculture & Farmers Welfare / AP Agriculture Dept',
    departmentTe: 'వ్యవసాయ మరియు రైతు సంక్షేమ శాఖ',
    fee: 'Free of Cost (Govt DBT Scheme)',
    processingDays: 'Seasonal Tranches (₹6,000/yr)',
    description: 'Central sector scheme providing income support of ₹6,000/year via direct DBT in three equal instalments of ₹2,000 to landholding farmer families, synchronized with AP e-Crop booking.',
    descriptionTe: 'రైతు కుటుంబాలకు ఏటా రూ.6,000 ఆర్థిక సహాయాన్ని 3 విడతల్లో నేరుగా బ్యాంక్ ఖాతాలో జమ చేసే కేంద్ర ప్రభుత్వ పథకం.',
    eligibilitySummary: [
      'Farmer family possessing cultivable landholding in revenue records',
      'Must not be an institutional landholder, government employee, or income tax payee',
      'Must complete mandatory Aadhaar e-KYC and e-Crop registration'
    ],
    precautions: [
      'Ensure bank account is seeded with Aadhaar and NPCI mapper is active.',
      'In Andhra Pradesh, land survey numbers must match Webland and e-Crop booking.'
    ],
    requiredDocumentsOrder: [
      {
        id: 'doc-farmer-aadhaar',
        name: 'Farmer Aadhaar Card (Linked to Mobile)',
        nameTe: 'రైతు ఆధార్ కార్డు (మొబైల్ లింక్డ్)',
        type: 'Biometric & Identity Proof',
        required: true,
        isMandatory: true,
        format: 'JPG / PNG / PDF',
        instructions: 'Mobile number linked to Aadhaar is mandatory for portal e-KYC.',
        whereToGet: 'UIDAI Portal',
        whyNeeded: 'Enables Aadhaar OTP authentication and DBT PFMS linkage.'
      },
      {
        id: 'doc-land-ror',
        name: 'Pattadar Passbook / 1B Namoona / RoR Record',
        nameTe: 'పట్టాదారు పాస్‌బుక్ / 1B రికార్డు',
        type: 'Land Ownership Proof',
        required: true,
        isMandatory: true,
        format: 'JPG / PNG / PDF',
        instructions: 'Showing Khata number, survey number, and farmer ownership in revenue register.',
        whereToGet: 'Revenue Dept / MeeSeva Webland',
        whyNeeded: 'Verifies cultivable agricultural land title in applicant name.'
      },
      {
        id: 'doc-bank-passbook',
        name: 'Aadhaar-Seeded Bank Account Passbook Copy',
        nameTe: 'ఆధార్ లింక్డ్ బ్యాంక్ ఖాతా పాస్‌బుక్ కాపీ',
        type: 'DBT Bank Account',
        required: true,
        isMandatory: true,
        format: 'JPG / PNG / PDF',
        instructions: 'Bank account passbook showing IFSC code and active account status.',
        whereToGet: 'Bank Branch / Post Office Savings Bank',
        whyNeeded: 'Direct Benefit Transfer destination for the ₹2,000 instalments.'
      }
    ],
    portalProcedureSteps: [
      {
        id: 'step-doc-dossier',
        label: 'Upload Aadhaar, Land Record & Bank details into PDF Dossier',
        labelTe: 'ఆధార్, భూమి రికార్డులు మరియు బ్యాంక్ వివరాలను PDF ప్యాక్‌గా సిద్ధం చేయండి',
        detail: 'Organized for State Agriculture Officer approval.',
        detailTe: 'వ్యవసాయ శాఖ అధికారుల పరిశీలన కోసం సిద్ధం చేయండి.',
        autoCheckOnAllDocs: true
      },
      {
        id: 'step-review-missing',
        label: 'Check Aadhaar-Bank seeding status on NPCI mapper',
        labelTe: 'బ్యాంక్ ఖాతాకు ఎన్‌పీసీఐ ఆధార్ సీడింగ్ అయిందో లేదో తనిఖీ చేయండి',
        detail: 'Unlinked accounts will face payment bounce during DBT cycles.',
        detailTe: 'సీడింగ్ లేకపోతే డబ్బులు జమ కావు.'
      },
      {
        id: 'step-spellings',
        label: 'Match farmer name on passbook with Aadhaar and Webland records',
        labelTe: 'పట్టాదారు పాస్‌బుక్ మరియు ఆధార్‌లోని పేరును సరిపోల్చండి',
        detail: 'Name mismatch causes e-KYC validation rejections.',
        detailTe: 'పేర్లు సరిపోలకపోతే ఈ-కేవైసీ ఆగిపోతుంది.'
      },
      {
        id: 'step-mobile-otp',
        label: 'Complete OTP-based e-KYC on PM-KISAN portal',
        labelTe: 'పీఎం-కిసాన్ పోర్టల్‌లో ఓటీపీ ఈ-కేవైసీ పూర్తి చేయండి',
        detail: 'Mandatory verification to receive annual payment tranches.',
        detailTe: 'విడతల వారీ డబ్బులు రావడానికి ఈ-కేవైసీ తప్పనిసరి.'
      },
      {
        id: 'step-launch-portal',
        label: 'Launch pmkisan.gov.in & Track Beneficiary Status',
        labelTe: 'పీఎం కిసాన్ పోర్టల్ తెరిచి బెనిఫిషియరీ స్టేటస్ ట్రాక్ చేయండి',
        detail: 'Monitor instalment credit via DBT PFMS tracking.',
        detailTe: 'డబ్బులు జమయ్యే వివరాలను ఆన్‌లైన్‌లో ట్రాక్ చేయండి.'
      }
    ]
  },
  {
    id: 'ayushman-bharat',
    title: 'Ayushman Bharat PM-JAY & Dr. YSR Aarogyasri',
    titleTe: 'ఆయుష్మాన్ భారత్ పీఎం-జేవై & వైఎస్సార్ ఆరోగ్యశ్రీ',
    shortName: 'Ayushman PM-JAY',
    category: 'Social Security',
    state: 'Central / All India',
    portalName: 'National Health Authority (NHA) Beneficiary Portal',
    portalUrl: 'https://beneficiary.nha.gov.in/',
    department: 'National Health Authority & YSR Aarogyasri Trust',
    departmentTe: 'జాతీయ ఆరోగ్య అథారిటీ & ఆరోగ్యశ్రీ ట్రస్ట్',
    fee: 'Free of Cost (Full Cashless Cover)',
    processingDays: 'Instant Card Generation',
    description: 'Government health assurance scheme offering up to ₹5,00,000 per family per year for secondary and tertiary cashless hospitalization in empaneled hospitals.',
    descriptionTe: 'పేద కుటుంబాలకు నెట్‌వర్క్ ఆసుపత్రులలో ఏటా రూ.5 లక్షల వరకు ఉచిత నగదు రహిత వైద్య చికిత్స అందించే ఆరోగ్య బీమా పథకం.',
    eligibilitySummary: [
      'Families identified via SECC database or possessing an active State Rice Card',
      'In Andhra Pradesh, integrated with Dr. YSR Aarogyasri health coverage'
    ],
    precautions: [
      'Carry your Aadhaar card and Rice Card to hospital Aarogya Mitra desk for instant admission.',
      'Never pay hospital cash for covered procedures.'
    ],
    requiredDocumentsOrder: [
      {
        id: 'doc-patient-aadhaar',
        name: 'Patient & Family Aadhaar Cards',
        nameTe: 'రోగి మరియు కుటుంబ సభ్యుల ఆధార్ కార్డులు',
        type: 'Identity Proof',
        required: true,
        isMandatory: true,
        format: 'JPG / PNG / PDF',
        instructions: 'Aadhaar cards of all family members.',
        whereToGet: 'UIDAI Portal',
        whyNeeded: 'Verifies biometric identity for instant hospital admission.'
      },
      {
        id: 'doc-rice-card',
        name: 'Andhra Pradesh Rice Card / Ration Card',
        nameTe: 'ఆంధ్రప్రదేశ్ బియ్యం కార్డు / రేషన్ కార్డు',
        type: 'Health Eligibility Anchor',
        required: true,
        isMandatory: true,
        format: 'JPG / PNG / PDF',
        instructions: 'Active Rice Card showing beneficiary family details.',
        whereToGet: 'Grama Sachivalayam / Civil Supplies',
        whyNeeded: 'Primary eligibility key verifying household BPL status.'
      }
    ],
    portalProcedureSteps: [
      {
        id: 'step-doc-dossier',
        label: 'Bundle Aadhaar and Rice Card into PDF Dossier',
        labelTe: 'ఆధార్ మరియు బియ్యం కార్డును PDF ప్యాక్‌గా సిద్ధం చేయండి',
        detail: 'Prepared for hospital Aarogya Mitra kiosk.',
        detailTe: 'ఆసుపత్రి ఆరోగ్య మిత్ర డెస్క్ వద్ద చూపించడానికి సిద్ధం చేయండి.',
        autoCheckOnAllDocs: true
      },
      {
        id: 'step-review-missing',
        label: 'Verify family active status in Dr. YSR Aarogyasri beneficiary list',
        labelTe: 'ఆరోగ్యశ్రీ లబ్ధిదారుల జాబితాలో కుటుంబం క్రియాశీలంగా ఉందో లేదో చూడండి',
        detail: 'Search family by Aadhaar number or Ration Card number.',
        detailTe: 'ఆధార్ లేదా రేషన్ కార్డుతో స్టేటస్ చెక్ చేసుకోండి.'
      },
      {
        id: 'step-spellings',
        label: 'Confirm patient demographic spelling matches hospital diagnosis records',
        labelTe: 'రోగి పేరు ఆధార్ మరియు ఆసుపత్రి రికార్డులతో సరిపోలడాన్ని నిర్ధారించండి',
        detail: 'Ensures cashless pre-authorization is approved by Trust doctors.',
        detailTe: 'నగదు రహిత చికిత్స అనుమతి పొందడానికి పేర్లు సరిపోలాలి.'
      },
      {
        id: 'step-mobile-otp',
        label: 'Complete OTP or biometric e-KYC at hospital kiosk',
        labelTe: 'ఆసుపత్రి కియోస్క్ వద్ద బయోమెట్రిక్ ఈ-కేవైసీ పూర్తి చేయండి',
        detail: 'Instant generation of Ayushman golden health card.',
        detailTe: 'తక్షణమే ఆయుష్మాన్ గోల్డెన్ కార్డు పొందవచ్చు.'
      },
      {
        id: 'step-launch-portal',
        label: 'Launch NHA Beneficiary Portal & Access Cashless Treatment',
        labelTe: 'ఎన్హెచ్ఏ పోర్టల్ తెరిచి ఉచిత వైద్య సేవలను పొందండి',
        detail: 'Avail 100% cashless treatment at empaneled hospitals nationwide.',
        detailTe: 'దేశవ్యాప్తంగా గుర్తింపు పొందిన ఆసుపత్రులలో ఉచిత చికిత్స.'
      }
    ]
  },
  {
    id: 'aadhaar-enrolment-update',
    title: 'Aadhaar Enrolment & Mandatory Biometric / Demographic Update',
    titleTe: 'ఆధార్ కొత్త నమోదు & బయోమెట్రిక్ / చిరునామా అప్‌డేట్',
    shortName: 'Aadhaar Card',
    category: 'Identity & Utility',
    state: 'Central / All India',
    portalName: 'UIDAI — MyAadhaar Portal',
    portalUrl: 'https://myaadhaar.uidai.gov.in/',
    department: 'Unique Identification Authority of India (UIDAI)',
    departmentTe: 'యూఐడీఏఐ (UIDAI)',
    fee: 'Enrolment Free / Update ₹50',
    processingDays: '7 to 15 Working Days',
    description: '12-digit unique identity number issued to Indian residents. Online updates available for address; mandatory biometrics (MBU at age 5 and 15) done at authorized Aadhaar kendras.',
    descriptionTe: 'భారత పౌరులకు 12 అంకెల విశిష్ట గుర్తింపు సంఖ్య. చిరునామాను ఆన్‌లైన్‌లో మరియు బయోమెట్రిక్‌లను కేంద్రంలో అప్‌డేట్ చేసుకోవచ్చు.',
    eligibilitySummary: [
      'Any resident living in India for 182 days or more',
      'Mandatory biometric update for children reaching 5 years and 15 years of age'
    ],
    precautions: [
      'New Aadhaar enrolment is completely free. Do not pay any fee.',
      'Update mobile number first to enable online address and document update services.'
    ],
    requiredDocumentsOrder: [
      {
        id: 'doc-proof-identity',
        name: 'Accepted Proof of Identity (POI) (Passport, PAN, Voter ID, Ration Card)',
        nameTe: 'గుర్తింపు రుజువు (POI)',
        type: 'POI Document',
        required: true,
        isMandatory: true,
        format: 'JPG / PNG / PDF',
        instructions: 'Original document issued by authorized government department with photo.',
        whereToGet: 'Passport / Election Commission / Civil Supplies',
        whyNeeded: 'Verifies legal identity of the individual.'
      },
      {
        id: 'doc-proof-address',
        name: 'Accepted Proof of Address (POA) (Electricity Bill, Bank Passbook, Rice Card)',
        nameTe: 'చిరునామా రుజువు (POA)',
        type: 'POA Document',
        required: true,
        isMandatory: true,
        format: 'JPG / PNG / PDF',
        instructions: 'Showing full residential address not older than 3 months for utility bills.',
        whereToGet: 'Bank / Discom / Post Office',
        whyNeeded: 'Establishes verified geographic address.'
      },
      {
        id: 'doc-proof-dob',
        name: 'Accepted Proof of Date of Birth (DOB) (Birth Certificate, SSC Memo)',
        nameTe: 'పుట్టిన తేదీ రుజువు (DOB)',
        type: 'DOB Document',
        required: true,
        isMandatory: true,
        format: 'JPG / PNG / PDF',
        instructions: 'Official municipal birth certificate or secondary school certificate.',
        whereToGet: 'Municipal Registrar / SSC Board',
        whyNeeded: 'Ensures verified DOB status on Aadhaar database.'
      }
    ],
    portalProcedureSteps: [
      {
        id: 'step-doc-dossier',
        label: 'Upload POI, POA and DOB documents into PDF Dossier',
        labelTe: 'POI, POA మరియు DOB పత్రాలను PDF ప్యాక్‌గా రూపొందించండి',
        detail: 'Formatted to UIDAI valid document checklist guidelines.',
        detailTe: 'యూఐడీఏఐ నిబంధనల ప్రకారం సిద్ధం చేయండి.',
        autoCheckOnAllDocs: true
      },
      {
        id: 'step-review-missing',
        label: 'Verify name spelling matches character-for-character across all proofs',
        labelTe: 'అన్ని పత్రాలలో పేరు స్పెల్లింగ్ సరిగా ఉందో లేదో చూడండి',
        detail: 'Name discrepancy leads to immediate document rejection by UIDAI back-office.',
        detailTe: 'స్పెల్లింగ్ తేడాలు ఉంటే తిరస్కరిస్తారు.'
      },
      {
        id: 'step-spellings',
        label: 'Book appointment at nearest Aadhaar Seva Kendra on myaadhaar portal',
        labelTe: 'పోర్టల్‌లో సమీప ఆధార్ సేవా కేంద్రం అపాయింట్‌మెంట్ బుక్ చేసుకోండి',
        detail: 'Select date and time slot to avoid long queues.',
        detailTe: 'తేదీ మరియు సమయం ఎంచుకోండి.'
      },
      {
        id: 'step-mobile-otp',
        label: 'Carry compiled dossier to Kendra & Complete 10-Finger Biometric capture',
        labelTe: 'కేంద్రానికి వెళ్లి బయోమెట్రిక్ మరియు ఫోటో నమోదు పూర్తి చేయండి',
        detail: 'Collect acknowledgement slip with 28-digit Enrolment ID (EID).',
        detailTe: 'ఈఐడీ రశీదు తీసుకోండి.'
      },
      {
        id: 'step-launch-portal',
        label: 'Launch myaadhaar.uidai.gov.in & Track Enrolment / Download e-Aadhaar',
        labelTe: 'పోర్టల్ తెరిచి ఈ-ఆధార్ డౌన్‌లోడ్ చేసుకోండి',
        detail: 'Download password-protected electronic Aadhaar PDF.',
        detailTe: 'డిజిటల్ ఆధార్ కార్డు డౌన్‌లోడ్ చేసుకోండి.'
      }
    ]
  },
  {
    id: 'voter-id-epic',
    title: 'Voter ID (EPIC) New Enrolment & Correction (Form 6 & 8)',
    titleTe: 'ఓటరు గుర్తింపు కార్డు (కొత్త నమోదు & మార్పులు - ఫారం 6 & 8)',
    shortName: 'Voter ID (EPIC)',
    category: 'Identity & Utility',
    state: 'Central / All India',
    portalName: 'ECI Voters’ Services Portal',
    portalUrl: 'https://voters.eci.gov.in/',
    department: 'Election Commission of India & CEO Andhra Pradesh',
    departmentTe: 'కేంద్ర ఎన్నికల సంఘం & ప్రధాన ఎన్నికల అధికారి, ఆంధ్రప్రదేశ్',
    fee: 'Free of Cost (Constitutional Right)',
    processingDays: '15 to 30 Working Days',
    description: 'Electoral Photo Identity Card (EPIC) issued by Election Commission of India for all citizens aged 18 and above, conferring voting rights and official photo identity proof.',
    descriptionTe: '18 ఏళ్లు నిండిన భారత పౌరులందరికీ ఓటు హక్కు కల్పించే ఎన్నికల గుర్తింపు కార్డు.',
    eligibilitySummary: [
      'Indian citizen who has attained 18 years of age (or qualifying age on 1st of Jan/Apr/Jul/Oct)',
      'Ordinarily resident in the assembly constituency where enrolling'
    ],
    precautions: [
      'Enrol only once and in a single assembly constituency. Multi-constituency enrolment is an offense.',
      'Upload a clear color passport photo showing front face without sunglasses.'
    ],
    requiredDocumentsOrder: [
      {
        id: 'doc-voter-photo',
        name: 'Passport Size Color Photograph (Front Facing)',
        nameTe: 'పాస్‌పోర్ట్ సైజు రంగు ఫోటో',
        type: 'Specimen Photo',
        required: true,
        isMandatory: true,
        format: 'JPG / PNG',
        instructions: 'Clear passport photo with white background (under 2MB).',
        whereToGet: 'Photo Studio / Camera',
        whyNeeded: 'Printed onto the PVC EPIC Voter Card.'
      },
      {
        id: 'doc-age-proof',
        name: 'Age Proof (Birth Certificate / Aadhaar / SSC Memo / PAN)',
        nameTe: 'వయస్సు ధ్రువీకరణ పత్రం',
        type: 'Age Verification',
        required: true,
        isMandatory: true,
        format: 'JPG / PNG / PDF',
        instructions: 'Proving applicant has attained 18 years of age.',
        whereToGet: 'Municipal Registrar / School Board / UIDAI',
        whyNeeded: 'Validates constitutional eligibility for franchise.'
      },
      {
        id: 'doc-residence-proof',
        name: 'Residence Proof (Electricity Bill / Water Bill / Aadhaar / Rent Deed)',
        nameTe: 'నివాస ధ్రువీకరణ పత్రం',
        type: 'Address Verification',
        required: true,
        isMandatory: true,
        format: 'JPG / PNG / PDF',
        instructions: 'Showing residence in the specific polling station jurisdiction.',
        whereToGet: 'Discom / Municipal Office / Post Office',
        whyNeeded: 'Allocates the specific polling station and Booth Level Officer (BLO).'
      }
    ],
    portalProcedureSteps: [
      {
        id: 'step-doc-dossier',
        label: 'Upload photograph, age proof & residence proof into PDF Dossier',
        labelTe: 'ఫోటో, వయస్సు మరియు నివాస పత్రాలను PDF ప్యాక్‌గా సిద్ధం చేయండి',
        detail: 'Formatted for Electoral Registration Officer (ERO) verification.',
        detailTe: 'ఎన్నికల రిజిస్ట్రేషన్ అధికారి పరిశీలన కోసం సిద్ధం చేయండి.',
        autoCheckOnAllDocs: true
      },
      {
        id: 'step-review-missing',
        label: 'Identify correct Assembly Constituency & Polling Part Number',
        labelTe: 'సరైన అసెంబ్లీ నియోజకవర్గం మరియు పోలింగ్ బూత్ నంబర్ తెలుసుకోండి',
        detail: 'Can be checked from parents existing EPIC card details.',
        detailTe: 'తల్లిదండ్రుల ఓటరు కార్డుతో సరిచూసుకోవచ్చు.'
      },
      {
        id: 'step-spellings',
        label: 'Fill Form 6 (New Voter) or Form 8 (Correction / Shifting) on portal',
        labelTe: 'పోర్టల్‌లో ఫారం 6 లేదా ఫారం 8 నింపండి',
        detail: 'Ensure spelling matches Aadhaar card.',
        detailTe: 'ఆధార్ కార్డుతో పేర్లు సరిపోలాలి.'
      },
      {
        id: 'step-mobile-otp',
        label: 'Booth Level Officer (BLO) home physical inspection',
        labelTe: 'బూత్ లెవల్ అధికారి (బీఎల్వో) ఇంటి వద్దకు వచ్చి పరిశీలిస్తారు',
        detail: 'Show original documents to BLO during field inquiry.',
        detailTe: 'అసలు పత్రాలను బీఎల్వోకి చూపించండి.'
      },
      {
        id: 'step-launch-portal',
        label: 'Launch voters.eci.gov.in & Download Digital e-EPIC',
        labelTe: 'పోర్టల్ తెరిచి ఈ-ఎపిక్ కార్డు డౌన్‌లోడ్ చేసుకోండి',
        detail: 'Download digitally authenticated voter card with QR code.',
        detailTe: 'క్యూఆర్ కోడ్‌తో కూడిన ఓటరు కార్డు పొందండి.'
      }
    ]
  },
  {
    id: 'pan-card-services',
    title: 'Permanent Account Number (PAN Card) Enrolment & Correction',
    titleTe: 'పాన్ కార్డు (PAN Card) కొత్త నమోదు & దిద్దుబాట్లు',
    shortName: 'PAN Card',
    category: 'Identity & Utility',
    state: 'Central / All India',
    portalName: 'Protean (NSDL) / UTIITSL / Income Tax e-Filing',
    portalUrl: 'https://www.onlineservices.nsdl.com/paam/endUserRegisterContact.html',
    department: 'Income Tax Department, Ministry of Finance, Govt of India',
    departmentTe: 'ఆదాయపు పన్ను శాఖ, కేంద్ర ఆర్థిక మంత్రిత్వ శాఖ',
    fee: '₹107 (Physical PAN) / ₹72 (Instant e-PAN Free on ITD)',
    processingDays: 'Instant (e-PAN) to 10 Days (Physical)',
    description: '10-digit alphanumeric identifier issued by the Income Tax Department, mandatory for banking, salary, tax filing, property transactions, and investments.',
    descriptionTe: 'బ్యాంకింగ్, పన్ను చెల్లింపులు మరియు ఆర్థిక లావాదేవీల కోసం ఆదాయపు పన్ను శాఖ జారీ చేసే 10 అంకెల విశిష్ట కార్డు.',
    eligibilitySummary: [
      'Any individual, minor (via representative assessee), or business entity residing in India'
    ],
    precautions: [
      'Possessing more than one PAN is illegal under Section 272B of Income Tax Act.',
      'Name and Date of Birth must match Aadhaar card for instant paperless e-KYC.'
    ],
    requiredDocumentsOrder: [
      {
        id: 'doc-aadhaar',
        name: 'Applicant Aadhaar Card (Linked to Active Mobile)',
        nameTe: 'దరఖాస్తుదారు ఆధార్ కార్డు (మొబైల్ లింక్డ్)',
        type: 'Single Document Solution (POI, POA & POB)',
        required: true,
        isMandatory: true,
        format: 'JPG / PNG / PDF',
        instructions: 'Aadhaar alone suffices for identity, address, and date of birth proof.',
        whereToGet: 'UIDAI',
        whyNeeded: 'Enables paperless e-Sign and instant PAN allotment.'
      },
      {
        id: 'doc-photo-sign',
        name: 'Applicant Passport Photo & Signature Scan',
        nameTe: 'పాస్‌పోర్ట్ ఫోటో & సంతకం స్కాన్ కాపీ',
        type: 'Physical Specimen',
        required: true,
        isMandatory: true,
        format: 'JPG / PNG',
        instructions: 'Clear signature in black ink on white paper (under 50KB).',
        whereToGet: 'Camera / Scanner',
        whyNeeded: 'Printed permanently onto the PVC PAN card.'
      }
    ],
    portalProcedureSteps: [
      {
        id: 'step-doc-dossier',
        label: 'Upload Aadhaar, signature specimen & photograph into PDF Dossier',
        labelTe: 'ఆధార్, సంతకం మరియు ఫోటోను PDF ప్యాక్‌గా రూపొందించండి',
        detail: 'Ready for Protean / UTIITSL digital application.',
        detailTe: 'పాన్ పోర్టల్ కోసం సిద్ధం చేయండి.',
        autoCheckOnAllDocs: true
      },
      {
        id: 'step-review-missing',
        label: 'Select Form 49A (Indian Citizen) on Protean/UTIITSL portal',
        labelTe: 'ఫారం 49A ను పోర్టల్‌లో ఎంచుకోండి',
        detail: 'Choose "Physical PAN card + e-PAN" for home delivery.',
        detailTe: 'ఇంటికి కార్డు రావడానికి ఫిజికల్ పాన్ ఎంచుకోండి.'
      },
      {
        id: 'step-spellings',
        label: 'Confirm Father name and Date of Birth matching Aadhaar',
        labelTe: 'తండ్రి పేరు మరియు పుట్టిన తేదీ ఆధార్‌తో సరిపోలడాన్ని నిర్ధారించండి',
        detail: 'Father name is printed on PAN; must not have spelling errors.',
        detailTe: 'తండ్రి పేరు పాన్ కార్డుపై ముద్రించబడుతుంది.'
      },
      {
        id: 'step-mobile-otp',
        label: 'Authenticate using Aadhaar OTP paperless e-Sign',
        labelTe: 'ఆధార్ ఓటీపీ ద్వారా ఈ-సైన్ పూర్తి చేయండి',
        detail: 'No need to send physical paper forms to NSDL office.',
        detailTe: 'కాగితాలు పోస్టులో పంపాల్సిన అవసరం లేదు.'
      },
      {
        id: 'step-launch-portal',
        label: 'Launch Protean Portal, Pay ₹107 & Download e-PAN within 24 Hours',
        labelTe: 'పోర్టల్ తెరిచి ఫీజు చెల్లించి 24 గంటల్లో ఈ-పాన్ పొందండి',
        detail: 'Physical card delivered to Aadhaar residential address via India Post.',
        detailTe: 'పోస్టులో ప్లాస్టిక్ కార్డు ఇంటికి చేరుతుంది.'
      }
    ]
  },
  {
    id: 'driving-licence-llr',
    title: 'Learner’s Licence (LLR) & Driving Licence (DL)',
    titleTe: 'లెర్నర్స్ లైసెన్స్ (LLR) & డ్రైవింగ్ లైసెన్స్ (DL)',
    shortName: 'Driving Licence',
    category: 'Identity & Utility',
    state: 'Central / All India',
    portalName: 'MoRTH — Parivahan Sarathi Portal',
    portalUrl: 'https://sarathi.parivahan.gov.in/',
    department: 'Transport Department, Govt of Andhra Pradesh & MoRTH',
    departmentTe: 'రవాణా శాఖ, ఆంధ్రప్రదేశ్ ప్రభుత్వం',
    fee: '₹150 (LLR Test) + ₹200 (DL Driving Test)',
    processingDays: 'Instant (LLR) / 1 Day after Test (DL)',
    description: 'Official authorization to drive motor vehicles on public roads, administered under the Motor Vehicles Act. LLR can now be taken online from home via Aadhaar authentication.',
    descriptionTe: 'మోటారు వాహనాలను నడపడానికి రవాణా శాఖ అందించే అధికారిక అనుమతి పత్రం.',
    eligibilitySummary: [
      'Age 16+ for gearless 50cc two-wheelers (with parental consent)',
      'Age 18+ for light motor vehicles (cars/motorcycles with gear)',
      'Age 20+ for commercial transport vehicles'
    ],
    precautions: [
      'Take online LLR test from a laptop with working camera and stable internet.',
      'Permanent DL driving skill test requires booking a slot at your RTO driving track.'
    ],
    requiredDocumentsOrder: [
      {
        id: 'doc-aadhaar',
        name: 'Aadhaar Card (Linked to Mobile for Online e-KYC Test)',
        nameTe: 'ఆధార్ కార్డు (ఆన్‌లైన్ పరీక్ష కోసం మొబైల్ లింక్డ్)',
        type: 'Identity & Address Proof',
        required: true,
        isMandatory: true,
        format: 'JPG / PNG / PDF',
        instructions: 'Enables contactless Aadhaar-based online LLR test from home.',
        whereToGet: 'UIDAI',
        whyNeeded: 'Verifies applicant age, identity, and residential address.'
      },
      {
        id: 'doc-medical-form',
        name: 'Medical Fitness Form 1 & 1A (for Commercial or Age 40+)',
        nameTe: 'మెడికల్ ఫిట్‌నెస్ ఫారం 1 & 1A',
        type: 'Medical Fitness',
        required: false,
        isMandatory: false,
        format: 'JPG / PNG / PDF',
        instructions: 'Certified by registered MBBS doctor if age > 40 or commercial category.',
        whereToGet: 'Government Hospital / Registered Medical Practitioner',
        whyNeeded: 'Certifies physical vision and fitness to operate motor vehicles.'
      },
      {
        id: 'doc-blood-group',
        name: 'Blood Group Test Report',
        nameTe: 'రక్త గ్రూపు రిపోర్టు',
        type: 'Clinical Metric',
        required: true,
        isMandatory: true,
        format: 'JPG / PNG / PDF',
        instructions: 'Laboratory diagnostic report showing blood group.',
        whereToGet: 'Diagnostic Lab / Hospital',
        whyNeeded: 'Printed on driving licence for emergency trauma response.'
      }
    ],
    portalProcedureSteps: [
      {
        id: 'step-doc-dossier',
        label: 'Upload Aadhaar, photo specimen & blood group report into PDF Dossier',
        labelTe: 'ఆధార్, ఫోటో మరియు రక్త గ్రూపు వివరాలను PDF ప్యాక్‌గా సిద్ధం చేయండి',
        detail: 'Formatted for Parivahan Sarathi RTO upload.',
        detailTe: 'రవాణా శాఖ పోర్టల్ కోసం సిద్ధం చేయండి.',
        autoCheckOnAllDocs: true
      },
      {
        id: 'step-review-missing',
        label: 'Select vehicle class (MCWG: Motorcycle with Gear / LMV: Light Motor Vehicle)',
        labelTe: 'వాహన తరగతిని ఎంచుకోండి (బైక్ / కారు)',
        detail: 'Pay ₹150 per class of vehicle on Parivahan payment gateway.',
        detailTe: 'పోర్టల్‌లో ఫీజు చెల్లించండి.'
      },
      {
        id: 'step-spellings',
        label: 'Watch mandatory Road Safety Tutorial video on Parivahan portal',
        labelTe: 'పోర్టల్‌లో రోడ్డు భద్రతా వీడియోను వీక్షించండి',
        detail: 'Prerequisite before taking the online test.',
        detailTe: 'వీడియో చూసిన తర్వాతే పరీక్ష రాయగలరు.'
      },
      {
        id: 'step-mobile-otp',
        label: 'Take Online LLR Test from home via web camera',
        labelTe: 'ఇంటి వద్ద నుండే వెబ్ కెమెరా ద్వారా ఎల్‌ఎల్‌ఆర్ పరీక్ష రాయండి',
        detail: 'Score at least 12 out of 15 questions correctly.',
        detailTe: '15 ప్రశ్నల్లో 12 మార్కులు సాధించాలి.'
      },
      {
        id: 'step-launch-portal',
        label: 'Launch sarathi.parivahan.gov.in & Instantly Download Learner Licence (LLR)',
        labelTe: 'పోర్టల్ తెరిచి ఎల్‌ఎల్‌ఆర్ డౌన్‌లోడ్ చేసుకోండి',
        detail: 'Book permanent DL driving slot after 30 days of LLR.',
        detailTe: '30 రోజుల తర్వాత డ్రైవింగ్ టెస్ట్ స్లాట్ బుక్ చేసుకోండి.'
      }
    ]
  },
  {
    id: 'eshram-card',
    title: 'e-Shram Card (National Database of Unorganized Workers)',
    titleTe: 'ఈ-శ్రమ్ కార్డు (అసంఘటిత కార్మికుల జాతీయ డేటాబేస్)',
    shortName: 'e-Shram Card',
    category: 'Social Security',
    state: 'Central / All India',
    portalName: 'Ministry of Labour & Employment e-Shram Portal',
    portalUrl: 'https://eshram.gov.in/',
    department: 'Ministry of Labour & Employment, Govt of India',
    departmentTe: 'కార్మిక మరియు ఉపాధి మంత్రిత్వ శాఖ',
    fee: 'Free of Cost (Govt Portal)',
    processingDays: 'Instant UAN Card Generation',
    description: '12-digit Universal Account Number (UAN) card for unorganized workers (construction, domestic, gig workers, agricultural laborers, street vendors) with ₹2,00,000 accidental insurance.',
    descriptionTe: 'భవన నిర్మాణ, వ్యవసాయ, గిగ్ వర్కర్లు మరియు స్వయం ఉపాధి పొందే అసంఘటిత కార్మికులకు రూ.2 లక్షల ప్రమాద బీమాతో కూడిన గుర్తింపు కార్డు.',
    eligibilitySummary: [
      'Age between 16 and 59 years',
      'Working in unorganized sector (not an income tax payer)',
      'Not a member of EPFO or ESIC'
    ],
    precautions: [
      'Registration is 100% free of cost on eshram.gov.in.',
      'Active mobile linked to Aadhaar allows instant online self-registration.'
    ],
    requiredDocumentsOrder: [
      {
        id: 'doc-aadhaar',
        name: 'Aadhaar Card (Linked to Active Mobile)',
        nameTe: 'ఆధార్ కార్డు (మొబైల్ లింక్డ్)',
        type: 'Identity Proof',
        required: true,
        isMandatory: true,
        format: 'JPG / PNG / PDF',
        instructions: 'Used for Aadhaar OTP e-KYC authentication.',
        whereToGet: 'UIDAI',
        whyNeeded: 'Extracts demographic information and biometric uniqueness.'
      },
      {
        id: 'doc-bank-account',
        name: 'Active Bank Account Details (Passbook)',
        nameTe: 'క్రియాశీల బ్యాంక్ ఖాతా వివరాలు (పాస్‌బుక్)',
        type: 'DBT Bank Account',
        required: true,
        isMandatory: true,
        format: 'JPG / PNG / PDF',
        instructions: 'Showing Account number, IFSC code, and branch.',
        whereToGet: 'Bank Branch',
        whyNeeded: 'Direct Benefit Transfer account for welfare disbursements.'
      }
    ],
    portalProcedureSteps: [
      {
        id: 'step-doc-dossier',
        label: 'Upload Aadhaar and bank passbook into PDF Dossier',
        labelTe: 'ఆధార్ మరియు బ్యాంక్ పాస్‌బుక్‌ను PDF ప్యాక్‌గా సిద్ధం చేయండి',
        detail: 'Formatted for e-Shram portal worker verification.',
        detailTe: 'ఈ-శ్రమ్ పోర్టల్ కోసం సిద్ధం చేయండి.',
        autoCheckOnAllDocs: true
      },
      {
        id: 'step-review-missing',
        label: 'Select primary occupation code (NCO Code) matching your job',
        labelTe: 'మీ వృత్తికి సరిపోయే ఎన్‌సీవో కోడ్‌ను ఎంచుకోండి',
        detail: 'e.g., Agriculture, Construction, Driving, Domestic worker.',
        detailTe: 'వ్యవసాయం, భవన నిర్మాణం మొదలైన వృత్తిని ఎంచుకోండి.'
      },
      {
        id: 'step-spellings',
        label: 'Verify bank account is active and seeded with Aadhaar',
        labelTe: 'బ్యాంక్ ఖాతా క్రియాశీలంగా ఉందో లేదో సరిచూసుకోండి',
        detail: 'Ensures social security grants reach your account without bounce.',
        detailTe: 'ఖాతా వివరాలు తప్పులు లేకుండా ఉండాలి.'
      },
      {
        id: 'step-mobile-otp',
        label: 'Enter Aadhaar OTP on eshram.gov.in self-registration page',
        labelTe: 'పోర్టల్‌లో ఆధార్ ఓటీపీ నమోదు చేయండి',
        detail: 'Instant automated demographic verification.',
        detailTe: 'ఆటోమేటిక్ ధ్రువీకరణ జరుగుతుంది.'
      },
      {
        id: 'step-launch-portal',
        label: 'Launch eshram.gov.in & Instantly Download 12-Digit UAN Card',
        labelTe: 'పోర్టల్ తెరిచి 12 అంకెల యూఏఎన్ కార్డు డౌన్‌లోడ్ చేసుకోండి',
        detail: 'Avail PMSBY accidental death/disability coverage of ₹2,00,000.',
        detailTe: 'రూ.2 లక్షల ప్రమాద బీమా ప్రయోజనం పొందండి.'
      }
    ]
  },
  {
    id: 'ap-spandana-grievance',
    title: 'AP Spandana / Public Grievance Redressal Service',
    titleTe: 'స్పందన (Spandana) ప్రజా సమస్యల పరిష్కార వేదిక',
    shortName: 'Spandana Grievance',
    category: 'Identity & Utility',
    state: 'Andhra Pradesh',
    portalName: 'AP Spandana Portal / 1902 Toll-Free',
    portalUrl: 'https://spandana.ap.gov.in/',
    department: 'Chief Minister’s Office & District Collectorates, AP',
    departmentTe: 'ముఖ్యమంత్రి కార్యాలయం & జిల్లా కలెక్టరేట్లు, ఆంధ్రప్రదేశ్',
    fee: 'Free of Cost (Citizen Redressal)',
    processingDays: 'Time-Bound SLA (7 to 30 Days)',
    description: 'Comprehensive public grievance redressal platform enabling citizens to register complaints, report delayed certificates, land issues, and civic service defaults for time-bound resolution by District Collectors.',
    descriptionTe: 'ప్రభుత్వ సేవలు, సర్టిఫికేట్లు ఆలస్యమైనా లేదా ప్రజా సమస్యల పరిష్కారం కోసం కలెక్టర్ల పర్యవేక్షణలో పనిచేసే వేదిక.',
    eligibilitySummary: [
      'Any citizen of Andhra Pradesh having a genuine grievance with any government department',
      'Provides unique tracking token with direct escalation matrix up to District Collector'
    ],
    precautions: [
      'Clearly write petition subject, dates, and previous MeeSeva application token numbers.',
      'Do not lodge frivolous or unverified allegations.'
    ],
    requiredDocumentsOrder: [
      {
        id: 'doc-petitioner-aadhaar',
        name: 'Petitioner Aadhaar Card',
        nameTe: 'ఫిర్యాదుదారు ఆధార్ కార్డు',
        type: 'Petitioner Identity',
        required: true,
        isMandatory: true,
        format: 'JPG / PNG / PDF',
        instructions: 'Clear copy of petitioner Aadhaar card.',
        whereToGet: 'UIDAI',
        whyNeeded: 'Establishes authentic identity of the citizen petitioner.'
      },
      {
        id: 'doc-grievance-petition',
        name: 'Written Representation / Grievance Application Letter',
        nameTe: 'సమస్య వివరణ దరఖాస్తు లేఖ',
        type: 'Statement of Grievance',
        required: true,
        isMandatory: true,
        format: 'JPG / PNG / PDF',
        instructions: 'Clearly stating background facts, affected department, and redress requested.',
        whereToGet: 'Drafted by petitioner',
        whyNeeded: 'Core document reviewed by District Collector / Joint Collector.'
      },
      {
        id: 'doc-previous-receipts',
        name: 'Prior Application Receipts / Service Acknowledgements (if delayed)',
        nameTe: 'మునుపటి దరఖాస్తు రశీదులు / టోకెన్లు',
        type: 'Corroborating Evidence',
        required: false,
        isMandatory: false,
        format: 'JPG / PNG / PDF',
        instructions: 'Showing the date when the certificate or service was originally applied.',
        whereToGet: 'MeeSeva / Sachivalayam receipt',
        whyNeeded: 'Proves service violation beyond statutory citizen charter timeline.'
      }
    ],
    portalProcedureSteps: [
      {
        id: 'step-doc-dossier',
        label: 'Upload grievance letter, Aadhaar & prior receipts into PDF Dossier',
        labelTe: 'ఫిర్యాదు లేఖ, ఆధార్ మరియు రశీదులను PDF ప్యాక్‌గా సిద్ధం చేయండి',
        detail: 'Formatted for District Collectorate Spandana desk.',
        detailTe: 'జిల్లా కలెక్టర్ పరిశీలన కోసం సిద్ధం చేయండి.',
        autoCheckOnAllDocs: true
      },
      {
        id: 'step-review-missing',
        label: 'Select exact Department, Mandal, and Village jurisdiction',
        labelTe: 'సంబంధిత శాఖ, మండలం మరియు గ్రామాన్ని ఎంచుకోండి',
        detail: 'Ensures petition routes straight to the responsible Mandal Officer/Tahsildar.',
        detailTe: 'సంబంధిత అధికారికి నేరుగా చేరుతుంది.'
      },
      {
        id: 'step-spellings',
        label: 'Record active mobile number for SMS status updates & call from CMO',
        labelTe: 'ఎస్ఎంఎస్ అప్‌డేట్స్ కోసం క్రియాశీల మొబైల్ నంబర్ ఇవ్వండి',
        detail: 'Department officers contact petitioner directly before closing file.',
        detailTe: 'సమస్య పరిష్కారం గురించి అధికారులు ఫోన్ చేస్తారు.'
      },
      {
        id: 'step-mobile-otp',
        label: 'Submit petition online or attend Monday Collectorate Spandana',
        labelTe: 'ఆన్‌లైన్‌లో లేదా సోమవారం కలెక్టరేట్ స్పందనలో సమర్పించండి',
        detail: 'Collect official Grievance Tracking Number.',
        detailTe: 'ఫిర్యాదు ట్రాకింగ్ నంబర్ తీసుకోండి.'
      },
      {
        id: 'step-launch-portal',
        label: 'Launch spandana.ap.gov.in & Monitor Time-Bound Action Taken Report (ATR)',
        labelTe: 'పోర్టల్ తెరిచి చర్యల నివేదికను (ATR) ఆన్‌లైన్‌లో ట్రాక్ చేయండి',
        detail: 'Review endorsement by officer and reopen if unsatisfied.',
        detailTe: 'పరిష్కారం సంతృప్తిగా లేకపోతే మళ్లీ ఓపెన్ చేయవచ్చు.'
      }
    ]
  }
];
