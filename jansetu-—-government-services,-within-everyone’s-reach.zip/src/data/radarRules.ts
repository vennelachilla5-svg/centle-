export interface RuleChangeNotice {
  id: string;
  schemeTitle: string;
  department: string;
  state: 'Andhra Pradesh' | 'Central / All India';
  verifiedNoticeUrl: string;
  sourceOld: string;
  sourceNew: string;
  effectiveDate: string;
  description: string;
  changes: Array<{
    parameter: string;
    oldValue: string;
    newValue: string;
    impact: 'High' | 'Medium' | 'Advisory';
    applicantAction: string;
    statutoryRef: string;
  }>;
}

export const RULE_CHANGE_NOTICES: RuleChangeNotice[] = [
  {
    id: 'radar-vidya-deevena',
    schemeTitle: 'Jagananna Vidya Deevena & Vasathi Deevena (Fee Reimbursement)',
    department: 'Department of Higher Education & Social Welfare, Govt of Andhra Pradesh',
    state: 'Andhra Pradesh',
    verifiedNoticeUrl: 'https://jnanabhumi.ap.gov.in/',
    sourceOld: 'G.O. Ms. No. 115 (Higher Education - EC Dept, Notification 2023-24)',
    sourceNew: 'G.O. Ms. No. 142 (Higher Education - Revised Guidelines 2025-26)',
    effectiveDate: 'Academic Year 2025–2026',
    description: 'Updated operational guidelines for full tuition reimbursement and boarding assistance in state colleges and universities.',
    changes: [
      {
        parameter: 'Aadhaar Biometric e-KYC',
        oldValue: 'Student single biometric authentication upon college admission',
        newValue: 'Dual Biometric Authentication: Mandatory monthly e-KYC for both student and mother at college/Sachivalayam',
        impact: 'High',
        applicantAction: 'Ensure mother’s Aadhaar is actively linked and biometric credentials are not locked in UIDAI portal.',
        statutoryRef: 'AP G.O. Ms. No. 142, Clause 4(A)'
      },
      {
        parameter: 'Biometric Attendance Threshold',
        oldValue: '75% aggregate attendance recorded by college faculty',
        newValue: '75% strict facial recognition attendance via integrated FRS app; 5% grace only on Tahsildar medical certificate',
        impact: 'High',
        applicantAction: 'Check that daily attendance is synced on the Jnanabhumi portal before the end of each quarter.',
        statutoryRef: 'AP G.O. Ms. No. 142, Clause 6(B)'
      },
      {
        parameter: 'Family Annual Income Ceiling',
        oldValue: '₹2,50,000 per annum verified via MeeSeva Income Certificate',
        newValue: '₹2,50,000 per annum verified automatically against Integrated Caste-Income & Rice Card database',
        impact: 'Medium',
        applicantAction: 'Validate your Rice Card active status; independent MeeSeva income certificate not required if Rice Card is valid.',
        statutoryRef: 'AP Revenue Circular Ref: Rev-VSWS/2025/11'
      },
      {
        parameter: 'Bank Account Disbursal Mode',
        oldValue: 'Joint account or student direct bank account permitted in select cases',
        newValue: 'Exclusively mother’s savings account with active NPCI Aadhaar-seeded mapper',
        impact: 'High',
        applicantAction: 'Confirm with your bank branch that the mother’s account is Aadhaar-seeded on NPCI DBT mapper.',
        statutoryRef: 'AP G.O. Ms. No. 142, Clause 9(D)'
      },
      {
        parameter: 'Agricultural Landholding Limit',
        oldValue: 'Maximum 10 acres wetland OR 25 acres dry land',
        newValue: 'Maximum 10 acres wetland OR 25 acres dry land (auto-scrutinized against Webland 2.0 revenue database)',
        impact: 'Advisory',
        applicantAction: 'Verify Webland 1B records in advance if family owns ancestral agricultural parcels.',
        statutoryRef: 'AP Land Revenue Act & G.O. Ms. 142'
      }
    ]
  },
  {
    id: 'radar-nmms-scholarship',
    schemeTitle: 'National Means-cum-Merit Scholarship Scheme (NMMSS)',
    department: 'Department of School Education & Literacy, Ministry of Education, Govt of India',
    state: 'Central / All India',
    verifiedNoticeUrl: 'https://scholarships.gov.in/',
    sourceOld: 'MoE Guidelines 2022-23 (Notice Ref: F.No.1-1/2022-SS)',
    sourceNew: 'Revised Operational Framework 2025-26 (Notice Ref: MoE/SS/NMMS/2025)',
    effectiveDate: 'Phase 2025–2026',
    description: 'Central scholarship awarded to meritorious students of economically weaker sections to arrest dropouts at class VIII.',
    changes: [
      {
        parameter: 'Parental Annual Income Ceiling',
        oldValue: '₹1,50,000 per annum',
        newValue: '₹3,50,000 per annum (increased to accommodate economic shifts)',
        impact: 'High',
        applicantAction: 'Students previously ineligible under ₹1.5L limit can now apply with updated Tahsildar income certificate.',
        statutoryRef: 'MoE Gazette Notification S.O. 1829(E)'
      },
      {
        parameter: 'One-Time Registration (OTR) Mandate',
        oldValue: 'School-level bulk enrollment with student Aadhaar number',
        newValue: 'Mandatory individual OTR using Aadhaar or Facial e-KYC on the updated NSP 2.0 portal',
        impact: 'High',
        applicantAction: 'Generate your 14-digit OTR number on NSP before attempting scholarship application.',
        statutoryRef: 'NSP Portal Advisory v2.4'
      },
      {
        parameter: 'Class VII Minimum Qualifying Marks',
        oldValue: '55% aggregate for General/OBC; 50% for SC/ST',
        newValue: '55% aggregate for General/OBC; 50% for SC/ST (maintained)',
        impact: 'Advisory',
        applicantAction: 'Upload certified marks memo signed by the Headmaster of the government or local body school.',
        statutoryRef: 'NMMSS Selection Criteria Rule 3'
      },
      {
        parameter: 'Benefit Disbursal Schedule',
        oldValue: '₹12,000 per annum (disbursed quarterly in ₹3,000 batches)',
        newValue: '₹12,000 per annum (single annual DBT transfer directly via Public Financial Management System - PFMS)',
        impact: 'Medium',
        applicantAction: 'Ensure student’s bank account is unencumbered and not classified as a minor/dormant account.',
        statutoryRef: 'PFMS Circular MoE/DBT-2025'
      }
    ]
  },
  {
    id: 'radar-ap-integrated-caste',
    schemeTitle: 'AP Integrated Certificate (Caste, Nativity & Date of Birth)',
    department: 'Revenue Department, Government of Andhra Pradesh',
    state: 'Andhra Pradesh',
    verifiedNoticeUrl: 'https://vsws.ap.gov.in/',
    sourceOld: 'AP Community Rules 1997 / MeeSeva Revenue SOP 2022',
    sourceNew: 'AP Seva Integrated Revenue Circular G.O. Ms. No. 58 (2025 Revision)',
    effectiveDate: 'Implemented Statewide',
    description: 'Single unified certificate serving community, nativity, and birth verification across all academic and public appointments.',
    changes: [
      {
        parameter: 'Digital Life & Validity Window',
        oldValue: 'Mandatory annual renewal required by select universities',
        newValue: 'Permanent validity for SC, ST, and BC communities unless revoked by District Collector',
        impact: 'High',
        applicantAction: 'Once a digitally signed barcode certificate is issued, reuse the certificate without re-applying annually.',
        statutoryRef: 'AP Act 16 of 1993, Section 5 & G.O. Ms 58'
      },
      {
        parameter: 'Statutory Processing SLA',
        oldValue: '30 working days standard turnaround',
        newValue: '15 working days guaranteed under AP Public Services Guarantee Act; 3 days for Tatkal / Sachivalayam verified records',
        impact: 'Medium',
        applicantAction: 'Track token on Spandana if application exceeds 15 days from submission date.',
        statutoryRef: 'AP Citizen Guarantee Act Schedule I'
      },
      {
        parameter: 'Official Application User Fee',
        oldValue: '₹35 MeeSeva charges + ₹10 administrative cess',
        newValue: '₹35 inclusive unified user charge across all 15,004+ Grama & Ward Secretariats',
        impact: 'Advisory',
        applicantAction: 'Refuse any additional private agent fees; official receipt for ₹35 must be generated by MeeSeva kiosk.',
        statutoryRef: 'AP ITE&C Dept Fee Notification 2024'
      }
    ]
  }
];
