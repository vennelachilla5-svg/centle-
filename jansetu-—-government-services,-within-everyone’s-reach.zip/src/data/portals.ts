export interface GovernmentPortal {
  id: string;
  name: string;
  shortCode: string;
  type: 'State (Andhra Pradesh)' | 'Central / National';
  url: string;
  department: string;
  description: string;
  bestFor: string[];
  keySchemes: string[];
  recommendedComplementaryServices: string[];
  badgeColor: string;
  instructions: string;
}

export const ALL_GOVERNMENT_PORTALS: GovernmentPortal[] = [
  {
    id: 'ap-seva',
    name: 'AP Seva Portal (VSWS Citizen)',
    shortCode: 'AP-SEVA',
    type: 'State (Andhra Pradesh)',
    url: 'https://vsws.ap.gov.in/',
    department: 'Grama & Ward Sachivalayam / Revenue Dept',
    description: 'Official single-window portal for Andhra Pradesh Grama/Ward Sachivalayam services. Apply for Integrated Caste, Nativity, Rice Cards, and local municipal certifications.',
    bestFor: [
      'AP Integrated Caste / Community Certificates',
      'Rice Card / Ration Card additions & splitting',
      'Local Grama / Ward Sachivalayam digital requests'
    ],
    keySchemes: [
      'Integrated Caste & Nativity',
      'Rice Card Services',
      'Residence Certificate',
      'Aadhaar Demographic Linking'
    ],
    recommendedComplementaryServices: [
      'ap-caste-integrated',
      'ap-rice-card',
      'ap-vidya-deevena',
      'central-nsp-scholarship'
    ],
    badgeColor: 'border-blue-300 bg-blue-50 text-blue-800',
    instructions: 'Log in with Aadhaar OTP. Submit your JanSetu compiled PDF dossier. VRO and Sachivalayam Secretary conduct doorstep/desk verification.'
  },
  {
    id: 'ap-meeseva',
    name: 'AP MeeSeva Citizen Portal',
    shortCode: 'MEESEVA',
    type: 'State (Andhra Pradesh)',
    url: 'https://onlineap.meeseva.gov.in/',
    department: 'ITE&C and Revenue Department, Govt of AP',
    description: 'Primary revenue service portal for Andhra Pradesh. Get Income Certificates, EWS Income & Asset Certificates, Birth Certificates, and Land Adangal/ROR 1B records.',
    bestFor: [
      'Income Certificate (Academic & Welfare)',
      'EWS 10% Quota Certificate',
      'Certified copy of registered Birth/Death',
      'Property & Land records'
    ],
    keySchemes: [
      'Income Certificate',
      'EWS Certificate',
      'Birth Certificate',
      'ROR 1B & Adangal'
    ],
    recommendedComplementaryServices: [
      'ap-income-certificate',
      'ap-ews-certificate',
      'ap-birth-certificate',
      'ap-vidya-deevena'
    ],
    badgeColor: 'border-emerald-300 bg-emerald-50 text-emerald-800',
    instructions: 'Register citizen login with mobile number. Select Revenue Service, attach the compiled PDF dossier, pay ₹35 user charges, and download digitally signed certificate upon Tahsildar approval.'
  },
  {
    id: 'ap-jnanabhumi',
    name: 'AP Jnanabhumi Portal',
    shortCode: 'JNANABHUMI',
    type: 'State (Andhra Pradesh)',
    url: 'https://jnanabhumi.ap.gov.in/',
    department: 'Social Welfare & Higher Education Dept, AP',
    description: 'Andhra Pradesh dedicated higher education scholarship and fee reimbursement portal. Powers Jagananna Vidya Deevena (full tuition fee) and Vasathi Deevena (hostel/mess grant).',
    bestFor: [
      'Full Tuition Fee Reimbursement for ITI, Polytechnic, Degree, Engineering, Medicine, PG',
      'Vasathi Deevena food and boarding allowances',
      'Post-matric scholarship biometric authentication'
    ],
    keySchemes: [
      'Jagananna Vidya Deevena',
      'Jagananna Vasathi Deevena',
      'Post-Matric Fee Reimbursement'
    ],
    recommendedComplementaryServices: [
      'ap-vidya-deevena',
      'ap-caste-integrated',
      'ap-income-certificate',
      'central-nsp-scholarship'
    ],
    badgeColor: 'border-indigo-300 bg-indigo-50 text-indigo-800',
    instructions: 'Link College Admission Hall Ticket, verify mother\'s bank account Aadhaar NPCI seeding, and complete monthly biometric attendance verification.'
  },
  {
    id: 'bse-ap',
    name: 'Board of Secondary Education AP (BSE AP)',
    shortCode: 'BSE-AP',
    type: 'State (Andhra Pradesh)',
    url: 'https://bse.ap.gov.in/',
    department: 'School Education Department, Govt of AP',
    description: 'Official portal for Andhra Pradesh SSC exams, NMMS (National Means-cum-Merit Scholarship) registrations, Duplicate 10th Class Marks Memos, and Migration certificates.',
    bestFor: [
      'NMMS Class VIII Scholarship (₹48,000 across 4 years)',
      'Duplicate SSC Marks Memo issuance for damaged/lost memos',
      'Equivalency and Migration Certificates'
    ],
    keySchemes: [
      'NMMS Scholarship Examination',
      'Duplicate SSC Memo',
      'Secondary Migration'
    ],
    recommendedComplementaryServices: [
      'ap-nmms-scholarship',
      'ap-ssc-duplicate-memo',
      'central-nsp-scholarship'
    ],
    badgeColor: 'border-purple-300 bg-purple-50 text-purple-800',
    instructions: 'Register online with Headmaster attestation or apply with police acknowledgment (for duplicate memos), pay official fee, and obtain certified marks statement.'
  },
  {
    id: 'bie-ap',
    name: 'Board of Intermediate Education AP (BIE AP)',
    shortCode: 'BIE-AP',
    type: 'State (Andhra Pradesh)',
    url: 'https://bie.ap.gov.in/',
    department: 'Intermediate Education, Govt of AP',
    description: 'Official intermediate portal for 11th and 12th students in Andhra Pradesh. Apply for Duplicate Intermediate Marks Memo, Migration, and Eligibility certificates.',
    bestFor: [
      'Duplicate Intermediate (Plus Two) Marks Memo',
      'Inter Migration Certificate for national university admissions',
      'Name correction in Marks Lists'
    ],
    keySchemes: [
      'Duplicate Inter Marks Memo',
      'Inter Migration Certificate',
      'Name Correction Service'
    ],
    recommendedComplementaryServices: [
      'ap-inter-duplicate-memo',
      'ap-vidya-deevena',
      'central-nsp-scholarship'
    ],
    badgeColor: 'border-sky-300 bg-sky-50 text-sky-800',
    instructions: 'Submit college principal letter, original notarized affidavit, and Aadhaar card via online fee challan.'
  },
  {
    id: 'ysr-aarogyasri',
    name: 'Dr. YSR Aarogyasri Health Care Trust',
    shortCode: 'AAROGYASRI',
    type: 'State (Andhra Pradesh)',
    url: 'https://ysraarogyasri.ap.gov.in/',
    department: 'Health, Medical & Family Welfare Dept, AP',
    description: 'Universal health coverage portal for Andhra Pradesh. Provides cashless in-patient treatment up to ₹5 Lakhs (and up to ₹25 Lakhs for critical surgeries) across network hospitals.',
    bestFor: [
      'Cashless hospital admissions for 3,257+ medical procedures',
      'Aarogyasri Card status check with Rice Card / Aadhaar',
      'Free tertiary hospital empanelment lookup'
    ],
    keySchemes: [
      'Dr. YSR Aarogyasri Card',
      'Aarogya Asara Post-operative Allowance',
      'Cashless Super-Specialty Coverage'
    ],
    recommendedComplementaryServices: [
      'central-ayushman-pmjay',
      'ap-rice-card',
      'sadarem-disability-cert'
    ],
    badgeColor: 'border-rose-300 bg-rose-50 text-rose-800',
    instructions: 'Visit any empanelled network hospital or Sachivalayam ANM/ASHA worker. Show Rice Card or Aadhaar to the Aarogya Mithra desk for immediate cashless pre-authorization.'
  },
  {
    id: 'ap-spandana',
    name: 'AP Spandana Grievance Portal',
    shortCode: 'SPANDANA',
    type: 'State (Andhra Pradesh)',
    url: 'https://spandana.ap.gov.in/',
    department: 'Chief Minister\'s Office & District Collectorates, AP',
    description: 'Apex public grievance redressal portal monitored directly by the Chief Minister\'s Office and District Collectors. Lodge complaints regarding delayed certificates, land issues, or scheme omissions.',
    bestFor: [
      'Statutory delay in Certificate issuance beyond Citizen Charter',
      'Land records and Tahsildar grievances',
      'Omission from welfare scheme eligibility lists'
    ],
    keySchemes: [
      'Public Grievance Redressal',
      'Collectorate Monday Spandana',
      'Action Taken Report (ATR) Tracking'
    ],
    recommendedComplementaryServices: [
      'ap-spandana-grievance',
      'ap-caste-integrated',
      'ap-income-certificate'
    ],
    badgeColor: 'border-amber-300 bg-amber-50 text-amber-800',
    instructions: 'Submit detailed petition with MeeSeva receipts and Aadhaar. Receive an SMS tracking token and monitored resolution within statutory SLA.'
  },
  {
    id: 'nsp-central',
    name: 'National Scholarship Portal (NSP)',
    shortCode: 'NSP',
    type: 'Central / National',
    url: 'https://scholarships.gov.in/',
    department: 'Ministry of Electronics & IT / Ministry of Education, Govt of India',
    description: 'One-stop central gateway for all central ministry and UGC/AICTE scholarships. Apply for Central Sector Scheme, Pre-Matric, Post-Matric, and Merit-cum-Means awards.',
    bestFor: [
      'Central Sector Scheme of Scholarship for College and University Students',
      'Post-Matric Scholarships for SC, ST, OBC, Minority students',
      'Direct Bank Transfer (DBT) directly into student Aadhaar-seeded accounts'
    ],
    keySchemes: [
      'Central Sector Scheme (CSSS)',
      'NMMS DBT Central Disbursal',
      'Post-Matric Central Schemes',
      'Ishan Uday & Pragati AICTE'
    ],
    recommendedComplementaryServices: [
      'central-nsp-scholarship',
      'ap-income-certificate',
      'ap-caste-integrated',
      'ap-vidya-deevena'
    ],
    badgeColor: 'border-teal-300 bg-teal-50 text-teal-800',
    instructions: 'Generate One-Time Registration (OTR) with Aadhaar FaceRD. Fill unified application and have institute nodal officer verify documents online.'
  },
  {
    id: 'pm-kisan',
    name: 'PM-KISAN Samman Nidhi Portal',
    shortCode: 'PM-KISAN',
    type: 'Central / National',
    url: 'https://pmkisan.gov.in/',
    department: 'Ministry of Agriculture & Farmers Welfare, Govt of India',
    description: 'Central farmer income support portal delivering ₹6,000 per year in 3 equal installments (₹2,000 each) directly to cultivable landholding farmer families across India.',
    bestFor: [
      '₹6,000 annual direct cash transfers for farmers',
      'Aadhaar e-KYC face/OTP authentication',
      'Beneficiary installment status check with Mobile/Aadhaar'
    ],
    keySchemes: [
      'PM-KISAN DBT ₹6,000/year',
      'Kisan Credit Card (KCC) linkage',
      'Farmer Aadhaar e-KYC'
    ],
    recommendedComplementaryServices: [
      'central-pm-kisan',
      'ap-income-certificate',
      'central-eshram-card'
    ],
    badgeColor: 'border-green-300 bg-green-50 text-green-800',
    instructions: 'Upload RoR 1B / Land Passbook and Aadhaar. Complete mandatory OTP e-KYC on the portal or via PM-KISAN FaceRD mobile app.'
  },
  {
    id: 'nha-ayushman',
    name: 'NHA Ayushman Bharat (PM-JAY)',
    shortCode: 'PM-JAY',
    type: 'Central / National',
    url: 'https://beneficiary.nha.gov.in/',
    department: 'National Health Authority (NHA), Govt of India',
    description: 'National health protection flagship covering 12+ Crore families with ₹5 Lakhs per family per year for secondary and tertiary hospitalization across pan-India empanelled hospitals.',
    bestFor: [
      'Ayushman Card (Golden Card) self-generation & download',
      'Cashless hospital admission in any empanelled hospital across India',
      'Inter-state portability for AP migrant workers'
    ],
    keySchemes: [
      'Ayushman Bharat PM-JAY Card',
      'Pan-India Hospital Cashless Network',
      'Pre-existing disease coverage from day one'
    ],
    recommendedComplementaryServices: [
      'central-ayushman-pmjay',
      'ap-rice-card',
      'sadarem-disability-cert'
    ],
    badgeColor: 'border-red-300 bg-red-50 text-red-800',
    instructions: 'Log in on beneficiary.nha.gov.in with mobile OTP. Search by Aadhaar number, complete live face or OTP e-KYC, and instantly download your PVC Ayushman Card.'
  },
  {
    id: 'uidai-myaadhaar',
    name: 'UIDAI – MyAadhaar Portal',
    shortCode: 'UIDAI',
    type: 'Central / National',
    url: 'https://myaadhaar.uidai.gov.in/',
    department: 'Unique Identification Authority of India (UIDAI)',
    description: 'National identity portal for all Indian residents. Update demographic details (address, mobile link), lock/unlock biometrics, verify bank Aadhaar seeding, and order PVC cards.',
    bestFor: [
      'Online Address Update using Electricity Bill / Rent Agreement',
      'Verify Aadhaar Bank Account NPCI DBT Linkage',
      'Download digitally signed masked/unmasked e-Aadhaar',
      'Order official waterproof PVC Aadhaar Card (₹50)'
    ],
    keySchemes: [
      'e-Aadhaar Download',
      'Online Address Update',
      'Biometric Lock/Unlock Security',
      'Aadhaar PVC Card'
    ],
    recommendedComplementaryServices: [
      'central-aadhaar-update',
      'central-pan-card',
      'central-voter-id'
    ],
    badgeColor: 'border-slate-300 bg-slate-50 text-slate-800',
    instructions: 'Log in with Aadhaar number and registered mobile OTP. Verify active status and ensure name spelling matches all other certificates.'
  },
  {
    id: 'eci-voters',
    name: 'Election Commission of India (ECI Voters)',
    shortCode: 'ECI',
    type: 'Central / National',
    url: 'https://voters.eci.gov.in/',
    department: 'Election Commission of India',
    description: 'Official national electoral service portal. Apply for New Voter Registration (Form 6), address shifting / corrections (Form 8), and download digital e-EPIC cards.',
    bestFor: [
      'New Voter ID card for citizens completing 18 years of age (Form 6)',
      'Correction in Name, DOB, or Address on Voter Card (Form 8)',
      'Instant e-EPIC PDF download'
    ],
    keySchemes: [
      'Voter ID Form 6',
      'Voter Correction Form 8',
      'e-EPIC Digital Card'
    ],
    recommendedComplementaryServices: [
      'central-voter-id',
      'central-aadhaar-update',
      'ap-caste-integrated'
    ],
    badgeColor: 'border-blue-300 bg-blue-50 text-blue-800',
    instructions: 'Register with mobile OTP. Upload photo, Aadhaar, and address proof. Track verification with Booth Level Officer (BLO).'
  },
  {
    id: 'pan-protean',
    name: 'Protean / UTIITSL (Income Tax PAN Portal)',
    shortCode: 'PAN',
    type: 'Central / National',
    url: 'https://www.onlineservices.nsdl.com/paam/endUserRegisterContact.html',
    department: 'Income Tax Department, Ministry of Finance',
    description: 'Official statutory portal for Permanent Account Number (PAN). Apply for New PAN (Form 49A), reprint PAN card, or apply for Instant e-PAN via Aadhaar e-KYC.',
    bestFor: [
      'New PAN Card for college students, bank account opening & employment',
      'Reprint of lost/damaged physical PAN card (₹50)',
      'Name/DOB corrections matching Aadhaar'
    ],
    keySchemes: [
      'PAN Card Form 49A',
      'Instant e-PAN (Free via Income Tax e-Filing)',
      'Aadhaar-PAN Linkage'
    ],
    recommendedComplementaryServices: [
      'central-pan-card',
      'central-aadhaar-update',
      'ap-income-certificate'
    ],
    badgeColor: 'border-cyan-300 bg-cyan-50 text-cyan-800',
    instructions: 'Select Form 49A. Choose paperless e-KYC with Aadhaar OTP. The digitally signed e-PAN arrives via email in 2-4 hours; physical card delivered by speed post.'
  },
  {
    id: 'morth-sarathi',
    name: 'MoRTH Parivahan Sarathi',
    shortCode: 'PARIVAHAN',
    type: 'Central / National',
    url: 'https://sarathi.parivahan.gov.in/',
    department: 'Ministry of Road Transport & Highways (MoRTH)',
    description: 'Unified national portal for Driving Licences and Learner\'s Licences. Take online computer LLR test directly from home and book practical RTO driving track slots.',
    bestFor: [
      'Online Learner\'s Licence (LLR) with home proctored test',
      'Permanent Driving Licence slot booking and issuance',
      'Renewal, duplicate DL, and international driving permit'
    ],
    keySchemes: [
      'Contactless Aadhaar-based LLR',
      'Permanent Driving Licence',
      'Driving Licence Address Change'
    ],
    recommendedComplementaryServices: [
      'central-driving-licence',
      'central-aadhaar-update',
      'ap-birth-certificate'
    ],
    badgeColor: 'border-amber-300 bg-amber-50 text-amber-800',
    instructions: 'Select Andhra Pradesh. Choose "Apply for Learner Licence with Aadhaar authentication" for instant contactless approval from home.'
  },
  {
    id: 'eshram-central',
    name: 'e-Shram National Database of Unorganised Workers',
    shortCode: 'E-SHRAM',
    type: 'Central / National',
    url: 'https://eshram.gov.in/',
    department: 'Ministry of Labour & Employment, Govt of India',
    description: 'National portal for unorganised workers (agricultural laborers, gig workers, street vendors, domestic workers, construction labor). Issues 12-digit UAN card with ₹2 Lakh accident cover.',
    bestFor: [
      'Universal 12-digit UAN Card for unorganized workers',
      '₹2 Lakh Accidental Death and Permanent Disability Insurance',
      'Direct inclusion in central disaster relief & social security benefits'
    ],
    keySchemes: [
      'e-Shram UAN Card',
      'Pradhan Mantri Suraksha Bima Yojana (PMSBY) Linkage',
      'National Unorganized Worker Database'
    ],
    recommendedComplementaryServices: [
      'central-eshram-card',
      'ap-rice-card',
      'central-pm-kisan'
    ],
    badgeColor: 'border-orange-300 bg-orange-50 text-orange-800',
    instructions: 'Enter Aadhaar linked mobile number, verify OTP, specify your occupation/skill code, and instantly download your laminated UAN card.'
  },
  {
    id: 'swavlamban-udid',
    name: 'Swavlamban UDID Portal (Disability Welfare)',
    shortCode: 'UDID',
    type: 'Central / National',
    url: 'https://www.swavlambancard.gov.in/',
    department: 'DEPwD, Ministry of Social Justice & Empowerment',
    description: 'National portal for Persons with Disabilities (PwDs). Converts state SADAREM certificates into a tamper-proof smart Unique Disability Identity Card (UDID) valid pan-India.',
    bestFor: [
      'National Smart UDID Disability Card with QR code',
      'Pan-India railway and bus travel concessions',
      'Direct eligibility for central and state disability pensions'
    ],
    keySchemes: [
      'Unique Disability ID (UDID)',
      'SADAREM to UDID Conversion',
      'Disability Pension and Assistive Aids (ADIP)'
    ],
    recommendedComplementaryServices: [
      'sadarem-disability-cert',
      'ap-rice-card',
      'ap-income-certificate'
    ],
    badgeColor: 'border-violet-300 bg-violet-50 text-violet-800',
    instructions: 'Upload SADAREM certificate or book hospital medical board assessment, attach Aadhaar and photo, and receive physical smart card by speed post.'
  }
];
