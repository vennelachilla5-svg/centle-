import React, { useState, useEffect, useRef } from 'react';
import {
  FileText,
  Upload,
  CheckCircle2,
  AlertTriangle,
  ArrowUp,
  ArrowDown,
  RotateCcw,
  Download,
  ExternalLink,
  ShieldCheck,
  Trash2,
  RefreshCw,
  Layers,
  ArrowRight,
  ArrowLeft,
  Check,
  Info,
  Eye,
  Clock,
  Coins,
  Building2,
  Volume2,
  Search,
  Bookmark,
  FolderCheck,
  Lock,
  Sparkles,
  X,
  FileCheck2,
  FileBox,
  Globe2,
  Printer,
  ChevronRight,
  ShieldAlert,
  Zap,
  PhoneCall,
  Radar,
  SlidersHorizontal,
  GraduationCap,
  Calendar,
  AlertCircle
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { SERVICES_DATA, ServiceItem, RequiredDocument } from './data/services';
import { ALL_GOVERNMENT_PORTALS, GovernmentPortal } from './data/portals';
import { RULE_CHANGE_NOTICES, RuleChangeNotice } from './data/radarRules';
import {
  ApplicantProfile,
  DEMO_APPLICANT,
  PreflightAuditReport,
  runPreflightAudit
} from './utils/preflightEngine';
import { getDemoDocumentsPackage } from './utils/demoDataHelper';
import {
  generateOfficialDossierPDF,
  UploadedDocFile,
  CompiledPdfRecord
} from './utils/pdfGenerator';
import GeminiChatbot from './components/GeminiChatbot';
import VoiceConversationModal from './components/VoiceConversationModal';
import {
  UI_STRINGS,
  getLocalizedService,
  getLocalizedDocName,
  getLocalizedServiceTitle,
  getLocalizedServiceDepartment
} from './utils/translations';

interface TrackedApplication {
  id: string;
  serviceId: string;
  serviceTitle: string;
  tokenNumber: string;
  dateStarted: string;
  status: 'Preparing Documents' | 'Ready to Apply' | 'Submitted' | 'Under Verification' | 'Approved' | 'Rejected';
  notes: string;
}

export default function App() {
  // Navigation Tabs: 'studio' | 'radar' | 'dossiers' | 'portals' | 'catalog' | 'tracker'
  const [activeTab, setActiveTab] = useState<'studio' | 'radar' | 'dossiers' | 'portals' | 'catalog' | 'tracker'>('studio');

  // Preflight Studio View: 'catalog' (all schemes hub) or 'detail' (dedicated scheme & procedure page)
  const [studioView, setStudioView] = useState<'catalog' | 'detail'>('catalog');
  const [schemeTab, setSchemeTab] = useState<'procedure' | 'preflight'>('procedure');

  // Selected Service in Studio
  const [selectedServiceId, setSelectedServiceId] = useState<string>('ap-caste-integrated');
  const [serviceCategoryFilter, setServiceCategoryFilter] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Selected Notice in Rule Change Radar
  const [selectedRadarNoticeId, setSelectedRadarNoticeId] = useState<string>(RULE_CHANGE_NOTICES[0].id);

  // Government Portals Directory States
  const [portalSearchQuery, setPortalSearchQuery] = useState<string>('');
  const [portalTypeFilter, setPortalTypeFilter] = useState<'All' | 'State (Andhra Pradesh)' | 'Central / National'>('All');

  // Progressive Disclosure Modals (to avoid visual clutter on main dashboard)
  const [selectedPortalModal, setSelectedPortalModal] = useState<GovernmentPortal | null>(null);
  const [selectedDocGuideModal, setSelectedDocGuideModal] = useState<RequiredDocument | null>(null);
  const [isStatutoryWorkflowModalOpen, setIsStatutoryWorkflowModalOpen] = useState<boolean>(false);
  const [isLandingModalOpen, setIsLandingModalOpen] = useState<boolean>(false);
  const [expandedFindingsMap, setExpandedFindingsMap] = useState<Record<string, boolean>>({});

  // AI Assistant Chatbot and Voice Modal States
  const [isChatbotOpen, setIsChatbotOpen] = useState<boolean>(false);
  const [isVoiceModalOpen, setIsVoiceModalOpen] = useState<boolean>(false);

  // 4 Sequential Stages:
  // 1: Ingestion & Upload | 2: Preflight Audit | 3: Order & Compile PDF | 4: Official Gateway Launch
  const [currentStage, setCurrentStage] = useState<1 | 2 | 3 | 4>(1);

  // Drag and Drop States
  const [dragOverDocId, setDragOverDocId] = useState<string | null>(null);
  const [isBatchDragOver, setIsBatchDragOver] = useState<boolean>(false);

  // Applicant Profile State
  const [applicant, setApplicant] = useState<ApplicantProfile>(() => {
    try {
      const saved = localStorage.getItem('jansetu_applicant_v6');
      return saved ? JSON.parse(saved) : DEMO_APPLICANT;
    } catch {
      return DEMO_APPLICANT;
    }
  });

  // Uploaded Files State: Record<serviceId, Record<docId, UploadedDocFile>>
  const [uploadedFilesMap, setUploadedFilesMap] = useState<Record<string, Record<string, UploadedDocFile>>>(() => {
    try {
      const saved = localStorage.getItem('jansetu_uploads_v6');
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });

  // Customized Document Ordering State per service
  const [customOrderMap, setCustomOrderMap] = useState<Record<string, RequiredDocument[]>>(() => {
    try {
      const saved = localStorage.getItem('jansetu_custom_orders_v6');
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });

  // Compiled PDF Dossiers Archive
  const [compiledDossiers, setCompiledDossiers] = useState<CompiledPdfRecord[]>(() => {
    try {
      const saved = localStorage.getItem('jansetu_compiled_dossiers_v6');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Procedure Checklist State
  const [checklistMap, setChecklistMap] = useState<Record<string, Record<string, boolean>>>(() => {
    try {
      const saved = localStorage.getItem('jansetu_procedure_checks_v6');
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });

  // Application Tracker State
  const [trackedApplications, setTrackedApplications] = useState<TrackedApplication[]>(() => {
    try {
      const saved = localStorage.getItem('jansetu_tracked_apps_v6');
      if (saved) return JSON.parse(saved);
      return [
        {
          id: 'track-1',
          serviceId: 'ap-caste-integrated',
          serviceTitle: 'AP Integrated Certificate (Caste, Nativity & DOB)',
          tokenNumber: 'AP-MS-2026-98124',
          dateStarted: new Date().toISOString().split('T')[0],
          status: 'Submitted',
          notes: 'Master dossier compiled and verified with JanSetu Preflight. Submitted via AP Seva VSWS.'
        }
      ];
    } catch {
      return [];
    }
  });

  // Preflight Audit Report State
  const [auditReport, setAuditReport] = useState<PreflightAuditReport | null>(null);

  // UI Toasts & Modals
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [uploadSuccessToast, setUploadSuccessToast] = useState<string | null>(null);
  const [stepLockedToast, setStepLockedToast] = useState<string | null>(null);
  const [activeUploadDocId, setActiveUploadDocId] = useState<string | null>(null);
  const [previewDoc, setPreviewDoc] = useState<UploadedDocFile | null>(null);
  const [previewPdfRecord, setPreviewPdfRecord] = useState<CompiledPdfRecord | null>(null);
  const [isCompilingPDF, setIsCompilingPDF] = useState<boolean>(false);
  const [lang, setLang] = useState<'en' | 'te' | 'hi'>('en');
  const [isPlayingAudio, setIsPlayingAudio] = useState<boolean>(false);

  // Quick Tracker Token Input
  const [quickTokenInput, setQuickTokenInput] = useState<string>('');
  const [quickTokenSaved, setQuickTokenSaved] = useState<boolean>(false);

  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const batchFileInputRef = useRef<HTMLInputElement | null>(null);

  // Sync to LocalStorage
  useEffect(() => {
    localStorage.setItem('jansetu_applicant_v6', JSON.stringify(applicant));
  }, [applicant]);

  useEffect(() => {
    localStorage.setItem('jansetu_uploads_v6', JSON.stringify(uploadedFilesMap));
  }, [uploadedFilesMap]);

  useEffect(() => {
    localStorage.setItem('jansetu_custom_orders_v6', JSON.stringify(customOrderMap));
  }, [customOrderMap]);

  useEffect(() => {
    localStorage.setItem('jansetu_compiled_dossiers_v6', JSON.stringify(compiledDossiers));
  }, [compiledDossiers]);

  useEffect(() => {
    localStorage.setItem('jansetu_procedure_checks_v6', JSON.stringify(checklistMap));
  }, [checklistMap]);

  useEffect(() => {
    localStorage.setItem('jansetu_tracked_apps_v6', JSON.stringify(trackedApplications));
  }, [trackedApplications]);

  const activeService = SERVICES_DATA.find((s) => s.id === selectedServiceId) || SERVICES_DATA[0];
  const currentDocsList: RequiredDocument[] = customOrderMap[activeService.id] || activeService.requiredDocumentsOrder;
  const currentServiceUploads = uploadedFilesMap[activeService.id] || {};
  const currentServiceChecks = checklistMap[activeService.id] || {};
  const activeCompiledPdf = compiledDossiers.find((d) => d.serviceId === activeService.id);
  const activePortal =
    ALL_GOVERNMENT_PORTALS.find(
      (p) =>
        activeService.portalUrl.toLowerCase().includes(p.url.toLowerCase()) ||
        activeService.portalName.toLowerCase().includes(p.shortCode.toLowerCase()) ||
        p.recommendedComplementaryServices.includes(activeService.id)
    ) || ALL_GOVERNMENT_PORTALS[0];

  // Localization dictionary and current localized service
  const t = UI_STRINGS[lang] || UI_STRINGS.en;
  const localizedActiveService = getLocalizedService(activeService, lang);

  // Metrics
  const totalDocs = currentDocsList.length;
  const mandatoryDocs = currentDocsList.filter((d) => d.isMandatory || d.required);
  const uploadedCount = currentDocsList.filter((d) => Boolean(currentServiceUploads[d.id])).length;
  const missingMandatoryDocs = mandatoryDocs.filter((d) => !currentServiceUploads[d.id]);
  const isStep1Complete = mandatoryDocs.length > 0 && missingMandatoryDocs.length === 0;

  // Run or update Preflight Audit automatically when uploads or applicant details change
  useEffect(() => {
    const report = runPreflightAudit(activeService, applicant, currentServiceUploads, {
      hasNameMismatch: applicant.fullName === 'Ramesh Kumar',
      hasIncomeVerificationPending: true
    });
    setAuditReport(report);
  }, [selectedServiceId, applicant, currentServiceUploads]);

  // Stage unlock conditions
  const isStep2Unlocked = true; // Preflight scrutiny can be run anytime to diagnose issues
  const isStep3Unlocked = Boolean(auditReport);
  const isStep4Unlocked = Boolean(activeCompiledPdf);

  const handleStageSelect = (stageNum: 1 | 2 | 3 | 4) => {
    if (stageNum === 3 && !isStep3Unlocked) {
      setStepLockedToast('Run the Step 2 Preflight Audit before compiling your master PDF.');
      setTimeout(() => setStepLockedToast(null), 3500);
      return;
    }
    if (stageNum === 4 && !isStep4Unlocked) {
      setStepLockedToast('Compile and bundle your Master PDF Dossier in Step 3 before launching the official portal.');
      setTimeout(() => setStepLockedToast(null), 3500);
      return;
    }
    setCurrentStage(stageNum);
  };

  // One-click Demo Application Loader
  const handleLoadDemoApplication = () => {
    setApplicant(DEMO_APPLICANT);
    const demoDocs = getDemoDocumentsPackage(activeService.id);
    setUploadedFilesMap((prev) => ({
      ...prev,
      [activeService.id]: demoDocs
    }));

    // Auto-run preflight
    const report = runPreflightAudit(activeService, DEMO_APPLICANT, demoDocs, {
      hasNameMismatch: true,
      hasIncomeVerificationPending: true
    });
    setAuditReport(report);
    setCurrentStage(2); // Jump directly to Preflight Audit screen

    setUploadSuccessToast('Demo Application loaded! 1 intentional missing document & 1 name mismatch identified for review.');
    setTimeout(() => setUploadSuccessToast(null), 4500);

    confetti({
      particleCount: 40,
      spread: 60,
      origin: { y: 0.7 }
    });
  };

  const handleTriggerPreflightAudit = () => {
    const report = runPreflightAudit(activeService, applicant, currentServiceUploads, {
      hasNameMismatch: applicant.fullName === 'Ramesh Kumar' || applicant.fullName.toLowerCase().includes('ramesh'),
      hasIncomeVerificationPending: true
    });
    setAuditReport(report);
    confetti({
      particleCount: 25,
      spread: 50,
      origin: { y: 0.8 }
    });
  };

  // File Upload Handlers
  const handleOpenFileInput = (docId: string) => {
    setActiveUploadDocId(docId);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
      fileInputRef.current.click();
    }
  };

  const handleSingleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0 || !activeUploadDocId) return;
    processAndAttachFile(files[0], activeUploadDocId);
  };

  const handleDropOnDocSlot = (files: FileList | null, docId: string) => {
    if (!files || files.length === 0) return;
    processAndAttachFile(files[0], docId);
  };

  const handleBatchDropFiles = (files: FileList | null) => {
    if (!files || files.length === 0) return;
    const fileArray = Array.from(files);

    const emptySlots = currentDocsList.filter((d) => !currentServiceUploads[d.id]);
    let attachedCount = 0;

    fileArray.forEach((file, index) => {
      const targetSlot = emptySlots[index] || currentDocsList[index % currentDocsList.length];
      if (targetSlot) {
        processAndAttachFile(file, targetSlot.id);
        attachedCount++;
      }
    });

    setUploadSuccessToast(`Attached ${attachedCount} documents into application checklist.`);
    setTimeout(() => setUploadSuccessToast(null), 3000);
  };

  const processAndAttachFile = (file: File, docId: string) => {
    setUploadError(null);
    if (file.size > 5 * 1024 * 1024) {
      setUploadError(`File "${file.name}" exceeds 5MB MeeSeva size limit. Please compress to < 5MB.`);
      return;
    }

    const isImage = file.type.startsWith('image/');
    const isPdf = file.type === 'application/pdf';

    if (!isImage && !isPdf) {
      setUploadError(`File "${file.name}" has unsupported format. Please upload PDF, JPG, or PNG.`);
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = reader.result as string;
      const sizeStr = (file.size / 1024).toFixed(0) + ' KB';

      const uploadedDoc: UploadedDocFile = {
        docId,
        name: file.name,
        size: sizeStr,
        dataUrl,
        uploadedAt: new Date().toLocaleDateString('en-IN', {
          day: 'numeric',
          month: 'short',
          hour: '2-digit',
          minute: '2-digit'
        }),
        isImage,
        pageCount: 1
      };

      setUploadedFilesMap((prev) => ({
        ...prev,
        [activeService.id]: {
          ...(prev[activeService.id] || {}),
          [docId]: uploadedDoc
        }
      }));

      setUploadSuccessToast(`"${file.name}" attached successfully.`);
      setTimeout(() => setUploadSuccessToast(null), 2500);
    };

    reader.onerror = () => {
      setUploadError('Failed to read document file. Please try again.');
    };

    reader.readAsDataURL(file);
  };

  const handleRemoveDoc = (docId: string) => {
    setUploadedFilesMap((prev) => {
      const serviceUploads = { ...(prev[activeService.id] || {}) };
      delete serviceUploads[docId];
      return {
        ...prev,
        [activeService.id]: serviceUploads
      };
    });
  };

  // Reordering in Step 3
  const handleMoveUp = (index: number) => {
    if (index <= 0) return;
    const list = [...currentDocsList];
    const temp = list[index];
    list[index] = list[index - 1];
    list[index - 1] = temp;
    setCustomOrderMap((prev) => ({
      ...prev,
      [activeService.id]: list
    }));
  };

  const handleMoveDown = (index: number) => {
    if (index >= currentDocsList.length - 1) return;
    const list = [...currentDocsList];
    const temp = list[index];
    list[index] = list[index + 1];
    list[index + 1] = temp;
    setCustomOrderMap((prev) => ({
      ...prev,
      [activeService.id]: list
    }));
  };

  const handleResetOrder = () => {
    setCustomOrderMap((prev) => {
      const copy = { ...prev };
      delete copy[activeService.id];
      return copy;
    });
  };

  // Compile Master PDF Dossier
  const handleCompilePDF = async () => {
    if (uploadedCount === 0) {
      setUploadError('Attach at least 1 document before compiling the master PDF dossier.');
      return;
    }

    setIsCompilingPDF(true);
    setUploadError(null);

    try {
      const result = await generateOfficialDossierPDF(
        activeService,
        applicant.fullName || 'Citizen Applicant',
        currentServiceUploads,
        currentDocsList
      );

      const newRecord: CompiledPdfRecord = {
        id: `pdf-${Date.now()}`,
        serviceId: activeService.id,
        serviceTitle: activeService.title,
        citizenName: applicant.fullName || 'Citizen Applicant',
        fileName: result.fileName,
        fileSize: result.fileSizeStr,
        pageCount: result.pageCount,
        dataUrl: result.dataUrl,
        timestamp: new Date().toLocaleDateString('en-IN', {
          day: 'numeric',
          month: 'short',
          year: 'numeric',
          hour: '2-digit',
          minute: '2-digit'
        }),
        attachedDocsCount: uploadedCount,
        portalName: activeService.portalName
      };

      setCompiledDossiers((prev) => [
        newRecord,
        ...prev.filter((d) => d.serviceId !== activeService.id)
      ]);

      // Mark procedure step
      setChecklistMap((prev) => ({
        ...prev,
        [activeService.id]: {
          ...(prev[activeService.id] || {}),
          'step-doc-dossier': true
        }
      }));

      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.65 }
      });
    } catch (err: any) {
      console.error('PDF compilation failed:', err);
      setUploadError('Failed to generate PDF dossier: ' + (err.message || 'Please check files.'));
    } finally {
      setIsCompilingPDF(false);
    }
  };

  const handleDownloadSavedDossier = (dossier: CompiledPdfRecord) => {
    const a = document.createElement('a');
    a.href = dossier.dataUrl;
    a.download = dossier.fileName;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const handleDeleteSavedDossier = (dossierId: string) => {
    if (confirm('Delete this compiled PDF dossier from your JanSetu archive?')) {
      setCompiledDossiers((prev) => prev.filter((d) => d.id !== dossierId));
    }
  };

  // TTS audio guide
  const handleSpeak = (text: string) => {
    if (!('speechSynthesis' in window)) return;
    if (isPlayingAudio) {
      window.speechSynthesis.cancel();
      setIsPlayingAudio(false);
      return;
    }
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 0.95;
    utterance.lang = lang === 'te' ? 'te-IN' : lang === 'hi' ? 'hi-IN' : 'en-IN';
    utterance.onend = () => setIsPlayingAudio(false);
    utterance.onerror = () => setIsPlayingAudio(false);
    setIsPlayingAudio(true);
    window.speechSynthesis.speak(utterance);
  };

  // Print Preflight Report
  const handlePrintReport = () => {
    window.print();
  };

  // Filter services with multilingual support
  const filteredServices = SERVICES_DATA.filter((s) => {
    if (serviceCategoryFilter !== 'All' && s.category !== serviceCategoryFilter) return false;
    if (searchQuery.trim() !== '') {
      const q = searchQuery.toLowerCase();
      const titleHi = getLocalizedServiceTitle(s, 'hi').toLowerCase();
      const titleTe = (s.titleTe || '').toLowerCase();
      const deptHi = getLocalizedServiceDepartment(s, 'hi').toLowerCase();
      return (
        s.title.toLowerCase().includes(q) ||
        s.shortName.toLowerCase().includes(q) ||
        s.department.toLowerCase().includes(q) ||
        s.portalName.toLowerCase().includes(q) ||
        titleHi.includes(q) ||
        titleTe.includes(q) ||
        deptHi.includes(q)
      );
    }
    return true;
  });

  const activeRadarNotice =
    RULE_CHANGE_NOTICES.find((n) => n.id === selectedRadarNoticeId) || RULE_CHANGE_NOTICES[0];

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col font-sans selection:bg-slate-900 selection:text-white">
      {/* Hidden File Inputs */}
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleSingleFileChange}
        accept=".pdf,.jpg,.jpeg,.png,.webp,application/pdf,image/jpeg,image/png,image/webp"
        className="hidden"
      />
      <input
        type="file"
        ref={batchFileInputRef}
        multiple
        onChange={(e) => handleBatchDropFiles(e.target.files)}
        accept=".pdf,.jpg,.jpeg,.png,.webp,application/pdf,image/jpeg,image/png,image/webp"
        className="hidden"
      />

      {/* ========================================================
          1. EXECUTIVE MINIMALIST HEADER
          ======================================================== */}
      <header className="sticky top-0 z-40 bg-white border-b border-slate-200 px-4 lg:px-7 py-2.5 shadow-2xs">
        <div className="max-w-[1600px] mx-auto flex items-center justify-between gap-4">
          {/* Brand Mark */}
          <div
            onClick={() => setIsLandingModalOpen(true)}
            className="flex items-center gap-3 cursor-pointer group"
            title="Click to view JanSetu Preflight overview and workflow"
          >
            <div className="w-8 h-8 rounded-lg bg-slate-950 group-hover:bg-blue-600 transition-colors flex items-center justify-center text-white shadow-xs">
              <ShieldCheck className="w-4 h-4 text-emerald-400 group-hover:text-white transition-colors" />
            </div>
            <div>
              <div className="flex items-center gap-1.5 font-bold text-sm tracking-tight text-slate-950">
                <span>{t.brand_title.split(' ')[0]}</span>
                <span className="text-blue-600 font-extrabold">{t.brand_title.split(' ').slice(1).join(' ')}</span>
                <span className="text-[10px] text-slate-500 font-normal hidden md:inline">· Official Gateway</span>
              </div>
              <p className="text-[10px] text-slate-500 tracking-tight hidden sm:block">
                {t.brand_tagline}
              </p>
            </div>
          </div>

          {/* Minimalist Segmented Navigation Tabs */}
          <nav className="flex items-center gap-1 bg-slate-100 p-1 rounded-lg border border-slate-200 text-xs">
            <button
              onClick={() => {
                setActiveTab('studio');
                setStudioView('catalog');
              }}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md font-medium transition-all ${
                activeTab === 'studio'
                  ? 'bg-white text-slate-950 shadow-2xs font-semibold'
                  : 'text-slate-600 hover:text-slate-950'
              }`}
            >
              <Layers className="w-3.5 h-3.5 text-blue-600" />
              <span>{t.nav_studio}</span>
            </button>

            <button
              onClick={() => setActiveTab('radar')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md font-medium transition-all ${
                activeTab === 'radar'
                  ? 'bg-white text-slate-950 shadow-2xs font-semibold'
                  : 'text-slate-600 hover:text-slate-950'
              }`}
            >
              <Radar className="w-3.5 h-3.5 text-amber-600" />
              <span>{t.nav_radar}</span>
            </button>

            <button
              onClick={() => setActiveTab('dossiers')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md font-medium transition-all ${
                activeTab === 'dossiers'
                  ? 'bg-white text-slate-950 shadow-2xs font-semibold'
                  : 'text-slate-600 hover:text-slate-950'
              }`}
            >
              <FileBox className="w-3.5 h-3.5 text-slate-700" />
              <span>{t.nav_dossiers} ({compiledDossiers.length})</span>
            </button>

            <button
              onClick={() => setActiveTab('portals')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md font-medium transition-all ${
                activeTab === 'portals'
                  ? 'bg-white text-slate-950 shadow-2xs font-semibold'
                  : 'text-slate-600 hover:text-slate-950'
              }`}
            >
              <Globe2 className="w-3.5 h-3.5 text-slate-700" />
              <span className="hidden md:inline">{t.nav_portals} ({ALL_GOVERNMENT_PORTALS.length})</span>
            </button>

            <button
              onClick={() => setActiveTab('tracker')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md font-medium transition-all ${
                activeTab === 'tracker'
                  ? 'bg-white text-slate-950 shadow-2xs font-semibold'
                  : 'text-slate-600 hover:text-slate-950'
              }`}
            >
              <FolderCheck className="w-3.5 h-3.5 text-slate-700" />
              <span className="hidden md:inline">{t.nav_tracker} ({trackedApplications.length})</span>
            </button>
          </nav>

          {/* Right Action Bar */}
          <div className="flex items-center gap-2">
            {/* How It Works Button */}
            <button
              onClick={() => setIsLandingModalOpen(true)}
              className="hidden lg:flex items-center gap-1 px-2.5 py-1.5 rounded-md text-xs font-semibold text-slate-700 hover:text-slate-950 hover:bg-slate-100 transition-colors border border-slate-200"
              title="See how JanSetu Preflight works"
            >
              <Info className="w-3.5 h-3.5 text-blue-600" />
              <span>{t.how_it_works}</span>
            </button>
            {/* Groq LPU Powered AI Counselor */}
            <button
              onClick={() => setIsChatbotOpen(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-950 hover:bg-slate-800 text-white text-xs font-semibold transition-all shadow-2xs"
              title="Groq LPU ultra-fast scheme counselor"
            >
              <Zap className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
              <span className="hidden sm:inline">{t.ask_ai}</span>
              <span className="text-[10px] text-emerald-400 font-mono hidden lg:inline">~250t/s</span>
            </button>

            {/* Language Switcher */}
            <div className="flex items-center gap-0.5 bg-slate-100 p-0.5 rounded-md border border-slate-200 text-[11px]">
              {(['en', 'te', 'hi'] as const).map((l) => (
                <button
                  key={l}
                  onClick={() => setLang(l)}
                  className={`px-2 py-0.5 rounded font-medium uppercase transition-colors ${
                    lang === l ? 'bg-white text-slate-900 shadow-2xs font-bold' : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {l === 'en' ? 'EN' : l === 'te' ? 'తె' : 'हि'}
                </button>
              ))}
            </div>
          </div>
        </div>
      </header>

      {/* Executive Operational Sub-Bar */}
      <div className="bg-slate-950 text-white border-b border-slate-800 px-4 lg:px-7 py-2 no-print">
        <div className="max-w-[1600px] mx-auto flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2.5 flex-wrap">
            <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider">Gateway SOP:</span>
            <span className="font-semibold text-slate-200 truncate max-w-xs md:max-w-md">
              {localizedActiveService.department} · {localizedActiveService.shortName}
            </span>
            <span className="text-slate-600 hidden md:inline">|</span>
            <span className="text-[11px] text-slate-300 hidden md:inline">
              {t.sla_time}: <strong>{activeService.processingDays}</strong>
            </span>
            <span className="text-slate-600 hidden lg:inline">|</span>
            <span className="text-[11px] text-slate-300 hidden lg:inline">
              {t.official_fee}: <strong>{activeService.fee.split(' ')[0]}</strong>
            </span>
          </div>

          <div className="flex items-center gap-2">
            {/* Load Demo Application Button */}
            <button
              onClick={handleLoadDemoApplication}
              className="px-2.5 py-1 rounded bg-blue-600 hover:bg-blue-500 text-white font-semibold text-[11px] flex items-center gap-1.5 shadow-2xs"
              title="Loads sample student application with intentional discrepancy for instant preflight testing"
            >
              <Sparkles className="w-3 h-3 text-amber-300" />
              <span>{t.load_demo}</span>
            </button>

            {/* Print Preflight Report */}
            {auditReport && (
              <button
                onClick={handlePrintReport}
                className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-[11px] flex items-center gap-1.5 border border-slate-700"
                title="Print or export Preflight Certification Report to PDF"
              >
                <Printer className="w-3 h-3 text-slate-300" />
                <span className="hidden sm:inline">{t.print_report}</span>
              </button>
            )}

            <span className="text-slate-600 hidden sm:inline">|</span>
            <div className="flex items-center gap-1 text-slate-300 text-[11px] hidden sm:flex">
              <PhoneCall className="w-3 h-3 text-emerald-400" />
              <span>Helpline: <strong className="text-white font-mono">1902</strong></span>
            </div>
          </div>
        </div>
      </div>

      {/* Toast Notifications */}
      {uploadSuccessToast && (
        <div className="max-w-[1600px] mx-auto w-full px-4 lg:px-7 pt-3 no-print">
          <div className="p-2.5 bg-emerald-50 border border-emerald-200 rounded-lg text-xs text-emerald-950 flex items-center justify-between gap-2 shadow-2xs">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span className="font-semibold">{uploadSuccessToast}</span>
            </div>
            <button onClick={() => setUploadSuccessToast(null)} className="text-emerald-700 hover:text-emerald-950 p-1">
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}

      {uploadError && (
        <div className="max-w-[1600px] mx-auto w-full px-4 lg:px-7 pt-3 no-print">
          <div className="p-2.5 bg-rose-50 border border-rose-200 rounded-lg text-xs text-rose-950 flex items-center justify-between gap-2 shadow-2xs">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
              <span>{uploadError}</span>
            </div>
            <button onClick={() => setUploadError(null)} className="text-rose-600 hover:text-rose-950 p-1">
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}

      {stepLockedToast && (
        <div className="fixed bottom-6 right-6 z-50 max-w-sm bg-slate-900 text-white p-3.5 rounded-lg shadow-xl border border-slate-700 flex items-start gap-3 no-print">
          <Lock className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
          <div className="flex-1 text-xs">
            <strong className="block text-amber-300 font-bold mb-0.5">Sequential Gate Enforced</strong>
            <p className="text-slate-200 leading-snug">{stepLockedToast}</p>
          </div>
          <button onClick={() => setStepLockedToast(null)} className="text-slate-400 hover:text-white">
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* ========================================================
          2. VIEW 1: PREFLIGHT STUDIO (3-COLUMN COMMAND CENTER)
          ======================================================== */}
      {activeTab === 'studio' && (
        <main className="flex-1 max-w-[1600px] w-full mx-auto px-4 lg:px-7 py-4 grid grid-cols-1 lg:grid-cols-12 gap-4">
          {/* ----------------------------------------------------
              COLUMN 1: SERVICE NAVIGATOR (3 cols)
              ---------------------------------------------------- */}
          <aside className="lg:col-span-3 flex flex-col gap-3 no-print">
            {/* Search and Category Filter Card */}
            <div className="pro-card p-3.5 flex flex-col gap-2.5">
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-slate-900 uppercase tracking-wider text-[11px] flex items-center gap-1.5">
                  <Bookmark className="w-3.5 h-3.5 text-blue-600" />
                  Select Scheme / Service
                </span>
                <span className="text-[11px] text-slate-500 font-mono">
                  {filteredServices.length} Total
                </span>
              </div>

              {/* Search input with shortcut hint */}
              <div className="relative">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search e.g. Caste, NMMS, Income, Rice..."
                  className="w-full bg-slate-50 border border-slate-200 rounded-md pl-8 pr-3 py-1.5 text-xs text-slate-900 placeholder-slate-400 focus:outline-none focus:border-slate-900 focus:bg-white transition-colors"
                />
              </div>

              {/* Category selector */}
              <div className="flex flex-wrap gap-1">
                {['All', 'Scholarships', 'AP Certificates', 'Agriculture', 'Identity & Utility'].map((cat) => (
                  <button
                    key={cat}
                    onClick={() => setServiceCategoryFilter(cat)}
                    className={`text-[10px] font-semibold px-2 py-0.5 rounded transition-colors ${
                      serviceCategoryFilter === cat
                        ? 'bg-slate-900 text-white'
                        : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>

            {/* List of Services */}
            <div className="pro-card p-1.5 flex flex-col gap-1 max-h-[calc(100vh-270px)] overflow-y-auto">
              {filteredServices.map((service) => {
                const isSelected = service.id === selectedServiceId;
                const uploads = uploadedFilesMap[service.id] || {};
                const reqCount = service.requiredDocumentsOrder.filter((d) => d.isMandatory || d.required).length;
                const upCount = service.requiredDocumentsOrder.filter(
                  (d) => (d.isMandatory || d.required) && Boolean(uploads[d.id])
                ).length;
                const isPdfCompiled = compiledDossiers.some((d) => d.serviceId === service.id);

                return (
                  <button
                    key={service.id}
                    onClick={() => {
                      setSelectedServiceId(service.id);
                      setCurrentStage(1);
                    }}
                    className={`w-full text-left p-2.5 rounded-md transition-all border flex flex-col gap-1 ${
                      isSelected
                        ? 'bg-slate-900 text-white border-slate-900 shadow-xs'
                        : 'bg-white border-transparent hover:border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-1 text-[10px]">
                      <span className={`font-mono ${isSelected ? 'text-slate-300' : 'text-slate-500'}`}>
                        {service.state.includes('Andhra Pradesh') ? 'AP State' : 'Central'}
                      </span>
                      {isPdfCompiled ? (
                        <span className="font-semibold text-emerald-400 flex items-center gap-1">
                          <CheckCircle2 className="w-3 h-3" /> Bundled
                        </span>
                      ) : upCount >= reqCount && reqCount > 0 ? (
                        <span className={`font-semibold ${isSelected ? 'text-blue-300' : 'text-blue-600'}`}>
                          ✓ {upCount}/{reqCount} Docs
                        </span>
                      ) : (
                        <span className={isSelected ? 'text-slate-400' : 'text-slate-500'}>
                          {upCount}/{reqCount} Docs
                        </span>
                      )}
                    </div>

                    <h4 className={`text-xs font-semibold leading-snug ${isSelected ? 'text-white' : 'text-slate-900'}`}>
                      {lang === 'te' && service.titleTe ? service.titleTe : service.title}
                    </h4>

                    <div className={`flex items-center justify-between text-[10px] mt-0.5 ${isSelected ? 'text-slate-300' : 'text-slate-500'}`}>
                      <span className="truncate max-w-[150px]">{service.portalName}</span>
                      <span className="font-mono">{service.fee.split(' ')[0]}</span>
                    </div>
                  </button>
                );
              })}
            </div>
          </aside>

          {/* ----------------------------------------------------
              COLUMN 2: PREFLIGHT WORKBENCH (6 cols)
              ---------------------------------------------------- */}
          <section className="lg:col-span-6 flex flex-col gap-3.5">
            {/* Top Service Executive Overview */}
            <div className="pro-card p-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
                <div>
                  <div className="flex items-center gap-2 text-[11px] text-slate-500 mb-1 flex-wrap">
                    <span className="font-semibold text-slate-900">{activeService.category}</span>
                    <span>·</span>
                    <span>SLA: {activeService.processingDays}</span>
                    <span>·</span>
                    <span>Official Fee: {activeService.fee}</span>
                  </div>
                  <h2 className="text-base sm:text-lg font-bold text-slate-950 tracking-tight">
                    {lang === 'te' && activeService.titleTe ? activeService.titleTe : activeService.title}
                  </h2>
                  <p className="text-xs text-slate-500 mt-0.5 flex items-center gap-1">
                    <Building2 className="w-3.5 h-3.5 text-slate-400" />
                    <span>{lang === 'te' && activeService.departmentTe ? activeService.departmentTe : activeService.department}</span>
                  </p>
                </div>

                <div className="flex items-center gap-1.5 self-start sm:self-auto flex-wrap">
                  <button
                    onClick={() => setSelectedPortalModal(activePortal)}
                    className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-md text-xs font-semibold bg-blue-50 hover:bg-blue-100 text-blue-700 border border-blue-200 transition-colors"
                    title="Click to view full portal guidelines, submission tips, and available schemes"
                  >
                    <Globe2 className="w-3.5 h-3.5 text-blue-600" />
                    <span>{activePortal.shortCode} Guidelines</span>
                  </button>

                  <button
                    onClick={() =>
                      handleSpeak(
                        `${activeService.title}. ${activeService.description}. Required documents: ${currentDocsList.map((d) => d.name).join(', ')}`
                      )
                    }
                    className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-md text-xs font-semibold border transition-all ${
                      isPlayingAudio
                        ? 'bg-slate-900 text-white border-slate-900'
                        : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    <Volume2 className="w-3.5 h-3.5 text-blue-600" />
                    <span>{isPlayingAudio ? 'Speaking...' : 'Listen'}</span>
                  </button>
                </div>
              </div>

              {/* Applicant Profile Form (Minimalist High-Density) */}
              <div className="mt-3 pt-1 grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs">
                <div className="bg-slate-50 p-2 rounded-md border border-slate-200">
                  <label className="text-[10px] text-slate-500 block mb-0.5">Applicant Full Name</label>
                  <input
                    type="text"
                    value={applicant.fullName}
                    onChange={(e) => setApplicant({ ...applicant, fullName: e.target.value })}
                    placeholder="Enter full name"
                    className="w-full bg-white border border-slate-200 rounded px-2 py-1 text-xs font-semibold text-slate-900 focus:outline-none focus:border-slate-900"
                  />
                </div>

                <div className="bg-slate-50 p-2 rounded-md border border-slate-200">
                  <label className="text-[10px] text-slate-500 block mb-0.5">Date of Birth</label>
                  <input
                    type="date"
                    value={applicant.dob}
                    onChange={(e) => setApplicant({ ...applicant, dob: e.target.value })}
                    className="w-full bg-white border border-slate-200 rounded px-2 py-1 text-xs font-semibold text-slate-900 focus:outline-none focus:border-slate-900"
                  />
                </div>

                <div className="bg-slate-50 p-2 rounded-md border border-slate-200">
                  <label className="text-[10px] text-slate-500 block mb-0.5">Annual Family Income</label>
                  <div className="relative">
                    <span className="absolute left-2 top-1 text-slate-400 text-xs">₹</span>
                    <input
                      type="number"
                      value={applicant.annualFamilyIncome}
                      onChange={(e) => setApplicant({ ...applicant, annualFamilyIncome: Number(e.target.value) })}
                      placeholder="180000"
                      className="w-full bg-white border border-slate-200 rounded pl-5 pr-2 py-1 text-xs font-semibold text-slate-900 focus:outline-none focus:border-slate-900"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Stepper Progression Navigation */}
            <div className="pro-card p-1.5 flex items-center justify-between gap-1 overflow-x-auto text-xs no-print">
              {[
                { stage: 1, label: '1. Ingestion', status: isStep1Complete ? 'Complete' : `${uploadedCount}/${totalDocs}` },
                { stage: 2, label: '2. Preflight Audit', status: auditReport ? `${auditReport.errorCount} Issues` : 'Ready' },
                { stage: 3, label: '3. Order & PDF', status: activeCompiledPdf ? 'Compiled' : 'Merge' },
                { stage: 4, label: '4. Portal Launch', status: 'Submit' }
              ].map((s, idx) => {
                const isActive = currentStage === s.stage;
                return (
                  <React.Fragment key={s.stage}>
                    {idx > 0 && <ChevronRight className="w-3.5 h-3.5 text-slate-300 shrink-0" />}
                    <button
                      onClick={() => handleStageSelect(s.stage as any)}
                      className={`flex-1 flex items-center justify-between px-3 py-1.5 rounded-md font-semibold text-xs transition-all ${
                        isActive
                          ? 'bg-slate-900 text-white shadow-2xs'
                          : 'bg-slate-50 text-slate-700 hover:bg-slate-100 border border-slate-200'
                      }`}
                    >
                      <span>{s.label}</span>
                      <span className={`text-[10px] font-mono ml-1.5 ${isActive ? 'text-slate-300' : 'text-slate-500'}`}>
                        {s.status}
                      </span>
                    </button>
                  </React.Fragment>
                );
              })}
            </div>

            {/* --------------------------------------------------
                STAGE 1: DOCUMENT INGESTION & UPLOAD
                -------------------------------------------------- */}
            {currentStage === 1 && (
              <div className="pro-card p-4 flex flex-col gap-3">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-sm font-bold text-slate-950 flex items-center gap-1.5">
                      <FileText className="w-4 h-4 text-blue-600" />
                      Step 1: Document Checklist &amp; Ingestion Matrix
                    </h3>
                    <p className="text-[11px] text-slate-500">
                      Drag files into matching slots or drop multi-file bundles below.
                    </p>
                  </div>
                  <span className="text-[11px] font-mono text-slate-600 bg-slate-100 px-2 py-0.5 rounded border border-slate-200">
                    {uploadedCount} / {totalDocs} Attached
                  </span>
                </div>

                {/* Batch Drop Zone */}
                <div
                  onDragOver={(e) => {
                    e.preventDefault();
                    setIsBatchDragOver(true);
                  }}
                  onDragLeave={() => setIsBatchDragOver(false)}
                  onDrop={(e) => {
                    e.preventDefault();
                    setIsBatchDragOver(false);
                    handleBatchDropFiles(e.dataTransfer.files);
                  }}
                  onClick={() => batchFileInputRef.current?.click()}
                  className={`p-3.5 rounded-lg border border-dashed transition-all cursor-pointer flex items-center justify-center text-center gap-3 ${
                    isBatchDragOver
                      ? 'border-blue-600 bg-blue-50/80 ring-1 ring-blue-400'
                      : 'border-slate-300 bg-slate-50/70 hover:bg-slate-100/70 hover:border-slate-400'
                  }`}
                >
                  <div className="w-7 h-7 rounded-md bg-white border border-slate-200 text-slate-700 flex items-center justify-center shrink-0">
                    <Upload className="w-3.5 h-3.5 text-blue-600" />
                  </div>
                  <div className="text-left">
                    <p className="text-xs font-semibold text-slate-900">
                      Drop document files here, or <span className="text-blue-600 underline">browse</span>
                    </p>
                    <p className="text-[10px] text-slate-500">
                      PDF, JPG, PNG accepted. Max 5MB per document.
                    </p>
                  </div>
                </div>

                {/* Document Slots List */}
                <div className="flex flex-col gap-2">
                  {currentDocsList.map((doc, idx) => {
                    const uploaded = currentServiceUploads[doc.id];
                    const isUploaded = Boolean(uploaded);
                    const isHovered = dragOverDocId === doc.id;

                    return (
                      <div
                        key={doc.id}
                        onDragOver={(e) => {
                          e.preventDefault();
                          e.stopPropagation();
                          setDragOverDocId(doc.id);
                        }}
                        onDragLeave={(e) => {
                          e.preventDefault();
                          e.stopPropagation();
                          setDragOverDocId(null);
                        }}
                        onDrop={(e) => {
                          e.preventDefault();
                          e.stopPropagation();
                          setDragOverDocId(null);
                          handleDropOnDocSlot(e.dataTransfer.files, doc.id);
                        }}
                        className={`p-3 rounded-lg border transition-all ${
                          isHovered
                            ? 'border-blue-600 bg-blue-50/70 ring-1 ring-blue-400'
                            : isUploaded
                            ? 'bg-slate-50/80 border-slate-200'
                            : 'bg-white border-slate-200 hover:border-slate-300'
                        }`}
                      >
                        <div className="flex items-center justify-between gap-2">
                          <div className="flex items-center gap-2 flex-1 min-w-0 flex-wrap">
                            <span
                              className={`w-4 h-4 rounded text-[10px] font-mono flex items-center justify-center shrink-0 ${
                                isUploaded ? 'bg-slate-900 text-white font-bold' : 'bg-slate-200 text-slate-600'
                              }`}
                            >
                              {isUploaded ? '✓' : idx + 1}
                            </span>
                            <h4 className="text-xs font-semibold text-slate-950 truncate max-w-[240px]">
                              {getLocalizedDocName(doc, lang)}
                            </h4>
                            <span className={`text-[9px] uppercase font-mono font-bold px-1.5 py-0.2 rounded border ${
                              doc.isMandatory
                                ? 'bg-rose-50 text-rose-700 border-rose-200'
                                : 'bg-slate-100 text-slate-600 border-slate-200'
                            }`}>
                              {doc.isMandatory ? t.mandatory : t.optional}
                            </span>
                            <span className="text-[9px] font-mono text-slate-500 bg-slate-100 px-1.5 py-0.2 rounded border border-slate-200">
                              {doc.format}
                            </span>
                          </div>

                          <button
                            type="button"
                            onClick={() => setSelectedDocGuideModal(doc)}
                            className="text-[11px] text-blue-600 hover:text-blue-800 hover:underline font-medium flex items-center gap-1 shrink-0"
                            title="Click to view where to get this document and statutory instructions"
                          >
                            <Info className="w-3 h-3" />
                            <span>View Guide</span>
                          </button>
                        </div>

                        {/* File slot upload action */}
                        <div className="mt-2.5 pl-6 flex items-center justify-between gap-2">
                          {isUploaded ? (
                            <div className="flex items-center justify-between w-full bg-white p-2 rounded-md border border-slate-200">
                              <div className="flex items-center gap-2 truncate">
                                {uploaded.isImage ? (
                                  <img
                                    src={uploaded.dataUrl}
                                    alt={uploaded.name}
                                    onClick={() => setPreviewDoc(uploaded)}
                                    className="w-9 h-9 object-cover rounded bg-slate-100 shrink-0 border border-slate-200 cursor-pointer"
                                  />
                                ) : (
                                  <div
                                    onClick={() => setPreviewDoc(uploaded)}
                                    className="w-9 h-9 rounded bg-slate-100 border border-slate-200 text-slate-700 flex flex-col items-center justify-center shrink-0 cursor-pointer"
                                  >
                                    <FileText className="w-4 h-4 text-slate-600" />
                                    <span className="text-[8px] font-mono font-bold">PDF</span>
                                  </div>
                                )}
                                <div className="truncate text-xs">
                                  <div className="font-semibold text-slate-900 truncate max-w-[200px]">
                                    {uploaded.name}
                                  </div>
                                  <div className="text-[10px] text-slate-500">
                                    {uploaded.size} · {uploaded.uploadedAt}
                                  </div>
                                </div>
                              </div>

                              <div className="flex items-center gap-1 shrink-0 text-xs">
                                <button
                                  onClick={() => setPreviewDoc(uploaded)}
                                  className="p-1 rounded text-slate-500 hover:text-slate-900 hover:bg-slate-100"
                                  title="Preview"
                                >
                                  <Eye className="w-3.5 h-3.5" />
                                </button>
                                <button
                                  onClick={() => handleOpenFileInput(doc.id)}
                                  className="text-[11px] font-semibold text-blue-600 hover:underline px-1"
                                >
                                  Replace
                                </button>
                                <button
                                  onClick={() => handleRemoveDoc(doc.id)}
                                  className="p-1 rounded text-rose-600 hover:text-rose-800 hover:bg-rose-50"
                                  title="Remove"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            </div>
                          ) : (
                            <button
                              type="button"
                              onClick={() => handleOpenFileInput(doc.id)}
                              className="w-full py-1.5 px-3 border border-dashed border-slate-300 hover:border-slate-500 bg-white hover:bg-slate-50 rounded text-xs font-medium text-slate-700 flex items-center justify-center gap-1.5 transition-colors"
                            >
                              <Upload className="w-3.5 h-3.5 text-blue-600" />
                              <span>Click to attach file or drag here</span>
                            </button>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>

                {/* Step 1 Footer */}
                <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
                  <span className="text-xs text-slate-500">
                    {missingMandatoryDocs.length === 0
                      ? '✓ All mandatory documents attached'
                      : `${missingMandatoryDocs.length} mandatory documents pending`}
                  </span>
                  <button
                    onClick={() => setCurrentStage(2)}
                    className="btn-gov-primary px-3.5 py-1.5 text-xs flex items-center gap-1.5"
                  >
                    <span>Run Preflight Audit →</span>
                  </button>
                </div>
              </div>
            )}

            {/* --------------------------------------------------
                STAGE 2: PREFLIGHT QUALITY & EVIDENCE AUDIT
                -------------------------------------------------- */}
            {currentStage === 2 && auditReport && (
              <div className="pro-card p-4 flex flex-col gap-3">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-sm font-bold text-slate-950 flex items-center gap-1.5">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                      Step 2: Preflight Deterministic Scrutiny Findings
                    </h3>
                    <p className="text-[11px] text-slate-500">
                      Identifies missing documents, mismatches, and statutory roadblocks before submission.
                    </p>
                  </div>
                  <button
                    onClick={() => setCurrentStage(1)}
                    className="text-xs text-blue-600 hover:underline flex items-center gap-1"
                  >
                    <ArrowLeft className="w-3 h-3" /> Back to Uploads
                  </button>
                </div>

                {/* Status Bar */}
                <div className={`p-3 rounded-lg border text-xs flex items-center justify-between ${
                  auditReport.overallStatus === 'Ready for Review'
                    ? 'bg-emerald-50 border-emerald-200 text-emerald-950'
                    : auditReport.overallStatus === 'Issues to Fix'
                    ? 'bg-rose-50 border-rose-200 text-rose-950'
                    : 'bg-amber-50 border-amber-200 text-amber-950'
                }`}>
                  <div className="flex items-center gap-2">
                    {auditReport.overallStatus === 'Ready for Review' ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    ) : (
                      <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
                    )}
                    <div>
                      <strong className="block text-xs font-bold">
                        Readiness Status: {auditReport.overallStatus}
                      </strong>
                      <span className="text-[11px] opacity-90">
                        {auditReport.errorCount} blocking errors · {auditReport.warningCount} warnings · {auditReport.infoCount} notices
                      </span>
                    </div>
                  </div>

                  <div className="text-right">
                    <span className="font-mono text-base font-bold">{auditReport.score}/100</span>
                    <span className="block text-[10px] opacity-80">Preflight Score</span>
                  </div>
                </div>

                {/* Preflight Findings List */}
                <div className="flex flex-col gap-2.5">
                  <span className="text-[11px] font-semibold text-slate-900 uppercase tracking-wider">
                    Detailed Scrutiny Evidence &amp; Actions ({auditReport.findings.length}):
                  </span>

                  {auditReport.findings.map((f) => (
                    <div
                      key={f.id}
                      className={`p-3 rounded-lg border text-xs flex flex-col gap-1.5 transition-all ${
                        f.severity === 'error'
                          ? 'bg-white border-rose-200 hover:border-rose-400'
                          : f.severity === 'warning'
                          ? 'bg-white border-amber-200 hover:border-amber-400'
                          : 'bg-white border-slate-200 hover:border-slate-300'
                      }`}
                    >
                      {/* Header with Title & Action Toggle */}
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span className={`text-[9px] uppercase font-mono font-bold px-1.5 py-0.5 rounded border ${
                            f.severity === 'error'
                              ? 'bg-rose-50 text-rose-700 border-rose-200'
                              : f.severity === 'warning'
                              ? 'bg-amber-50 text-amber-800 border-amber-200'
                              : 'bg-slate-100 text-slate-700 border-slate-200'
                          }`}>
                            {f.category}
                          </span>
                          <h4 className="font-semibold text-slate-900 text-xs">
                            {f.title}
                          </h4>
                        </div>

                        <button
                          type="button"
                          onClick={() => setExpandedFindingsMap((prev) => ({ ...prev, [f.id]: !prev[f.id] }))}
                          className="text-[10px] text-blue-600 hover:text-blue-800 font-semibold shrink-0"
                        >
                          {expandedFindingsMap[f.id] ? 'Hide Details ▴' : 'Details ▾'}
                        </button>
                      </div>

                      {/* Immediate Scannable Action */}
                      <div className="text-[11px] text-slate-700 flex items-start gap-1.5">
                        <span className="text-blue-600 font-bold shrink-0">Action:</span>
                        <span>{f.recommendedAction}</span>
                      </div>

                      {/* Collapsible Evidence Details */}
                      {expandedFindingsMap[f.id] && (
                        <div className="mt-1 pt-1.5 border-t border-slate-100 text-[10px] text-slate-600 bg-slate-50 p-2 rounded space-y-1">
                          <div>
                            <strong className="text-slate-800">Trigger:</strong> {f.triggeredBy}
                          </div>
                          <div>
                            <strong className="text-slate-800">Why It Matters:</strong> {f.explanation}
                          </div>
                          <div className="flex items-center justify-between pt-1 border-t border-slate-200/60">
                            <span className="font-mono text-slate-500 truncate max-w-[240px]">
                              Rule: {f.statutoryRuleRef}
                            </span>
                            <a
                              href={f.verifiedSourceUrl}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-blue-600 hover:underline flex items-center gap-0.5 font-semibold"
                            >
                              <span>Official Portal Source</span>
                              <ExternalLink className="w-2.5 h-2.5" />
                            </a>
                          </div>
                        </div>
                      )}
                    </div>
                  ))}
                </div>

                {/* Step 2 Footer */}
                <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
                  <button
                    onClick={() => setCurrentStage(1)}
                    className="text-xs text-slate-600 hover:text-slate-900 font-semibold"
                  >
                    ← Back to Ingestion
                  </button>
                  <button
                    onClick={() => setCurrentStage(3)}
                    className="btn-gov-primary px-3.5 py-1.5 text-xs flex items-center gap-1.5"
                  >
                    <span>Proceed to Step 3 (Arrange &amp; Merge PDF) →</span>
                  </button>
                </div>
              </div>
            )}

            {/* --------------------------------------------------
                STAGE 3: ARRANGE SEQUENCE & COMPILE MASTER PDF
                -------------------------------------------------- */}
            {currentStage === 3 && (
              <div className="pro-card p-4 flex flex-col gap-3">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-sm font-bold text-slate-950 flex items-center gap-1.5">
                      <Layers className="w-4 h-4 text-blue-600" />
                      Step 3: Arrange Sequence &amp; Compile Master PDF Dossier
                    </h3>
                    <p className="text-[11px] text-slate-500">
                      Sort files in official order. Real vector pages and images are merged with an official cover index page.
                    </p>
                  </div>
                  <button
                    onClick={handleResetOrder}
                    className="px-2 py-1 text-[11px] font-semibold text-slate-600 hover:text-slate-900 bg-slate-100 rounded border border-slate-200 flex items-center gap-1"
                  >
                    <RotateCcw className="w-3 h-3" />
                    <span>Reset</span>
                  </button>
                </div>

                {/* Reordering List */}
                <div className="space-y-1.5">
                  {currentDocsList.map((doc, index) => {
                    const uploaded = currentServiceUploads[doc.id];
                    const isUploaded = Boolean(uploaded);

                    return (
                      <div
                        key={doc.id}
                        className="p-2.5 bg-slate-50 rounded-md border border-slate-200 flex items-center justify-between gap-2 text-xs"
                      >
                        <div className="flex items-center gap-2 truncate">
                          <span className="w-5 h-5 rounded bg-slate-900 text-white font-mono text-[10px] font-bold flex items-center justify-center shrink-0">
                            {index + 1}
                          </span>
                          <div className="truncate">
                            <span className="font-semibold text-slate-900 truncate">
                              {getLocalizedDocName(doc, lang)}
                            </span>
                            <span className="text-[10px] text-slate-500 block">
                              {isUploaded ? `Attached: ${uploaded.name} (${uploaded.size})` : '(Pending upload)'}
                            </span>
                          </div>
                        </div>

                        <div className="flex items-center gap-1 shrink-0">
                          <button
                            disabled={index === 0}
                            onClick={() => handleMoveUp(index)}
                            className="p-1 rounded border border-slate-200 bg-white hover:bg-slate-100 disabled:opacity-30 disabled:cursor-not-allowed text-slate-700"
                            title="Move Up"
                          >
                            <ArrowUp className="w-3 h-3" />
                          </button>
                          <button
                            disabled={index === currentDocsList.length - 1}
                            onClick={() => handleMoveDown(index)}
                            className="p-1 rounded border border-slate-200 bg-white hover:bg-slate-100 disabled:opacity-30 disabled:cursor-not-allowed text-slate-700"
                            title="Move Down"
                          >
                            <ArrowDown className="w-3 h-3" />
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>

                {/* PDF Compilation Button */}
                <div className="pt-2 border-t border-slate-100 flex flex-col gap-2">
                  <button
                    onClick={handleCompilePDF}
                    disabled={uploadedCount === 0 || isCompilingPDF}
                    className={`w-full py-2 px-4 rounded-md text-xs font-semibold flex items-center justify-center gap-2 transition-all ${
                      uploadedCount > 0
                        ? 'btn-gov-blue cursor-pointer'
                        : 'bg-slate-100 text-slate-400 cursor-not-allowed border border-slate-200'
                    }`}
                  >
                    {isCompilingPDF ? (
                      <>
                        <RefreshCw className="w-4 h-4 animate-spin" />
                        <span>Merging Authentic Document Pages into Master PDF...</span>
                      </>
                    ) : (
                      <>
                        <Download className="w-4 h-4" />
                        <span>Compile &amp; Download Master PDF Dossier ({uploadedCount} Files)</span>
                      </>
                    )}
                  </button>

                  {activeCompiledPdf && (
                    <div className="p-2.5 bg-emerald-50 border border-emerald-200 rounded-md text-xs text-emerald-950 flex items-center justify-between gap-2">
                      <div>
                        <strong className="block font-semibold">{activeCompiledPdf.fileName}</strong>
                        <span className="text-[10px] text-slate-500">
                          {activeCompiledPdf.pageCount} Pages · {activeCompiledPdf.fileSize} · All documents stitched
                        </span>
                      </div>
                      <div className="flex items-center gap-1.5 shrink-0">
                        <button
                          onClick={() => setPreviewPdfRecord(activeCompiledPdf)}
                          className="px-2 py-1 bg-white border border-emerald-300 rounded text-emerald-800 text-[11px] font-semibold hover:bg-emerald-100/50"
                        >
                          Preview
                        </button>
                        <button
                          onClick={() => setCurrentStage(4)}
                          className="px-2.5 py-1 bg-emerald-600 text-white rounded text-[11px] font-semibold hover:bg-emerald-700"
                        >
                          Step 4 →
                        </button>
                      </div>
                    </div>
                  )}
                </div>

                {/* Step 3 Footer */}
                <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
                  <button
                    onClick={() => setCurrentStage(2)}
                    className="text-xs text-slate-600 hover:text-slate-900 font-semibold"
                  >
                    ← Back to Audit
                  </button>
                  <button
                    onClick={() => handleStageSelect(4)}
                    disabled={!isStep4Unlocked}
                    className={`px-3.5 py-1.5 rounded-md text-xs font-semibold flex items-center gap-1.5 ${
                      isStep4Unlocked
                        ? 'btn-gov-primary'
                        : 'bg-slate-100 text-slate-400 cursor-not-allowed border border-slate-200'
                    }`}
                  >
                    <span>Next: Step 4 Direct Portal Submission →</span>
                  </button>
                </div>
              </div>
            )}

            {/* --------------------------------------------------
                STAGE 4: OFFICIAL PORTAL SUBMISSION & TOKEN TRACKER
                -------------------------------------------------- */}
            {currentStage === 4 && (
              <div className="pro-card p-4 flex flex-col gap-3">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-sm font-bold text-slate-950 flex items-center gap-1.5">
                      <ExternalLink className="w-4 h-4 text-blue-600" />
                      Step 4: Launch Official Government Submission Gateway
                    </h3>
                    <p className="text-[11px] text-slate-500">
                      Your master dossier is prepared in statutory order. Submit directly to the verified official portal.
                    </p>
                  </div>
                  <button
                    onClick={() => setCurrentStage(3)}
                    className="text-xs text-blue-600 hover:underline flex items-center gap-1"
                  >
                    <ArrowLeft className="w-3 h-3" /> Back to Sequence
                  </button>
                </div>

                {/* Portal Submission Card */}
                <div className="p-3.5 rounded-lg bg-slate-900 text-white flex flex-col gap-3">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <span className="text-[10px] font-mono text-emerald-400 uppercase tracking-wider block mb-1">
                        Verified Government Gateway
                      </span>
                      <h4 className="text-sm font-bold text-white">
                        {activeService.portalName}
                      </h4>
                      <p className="text-[11px] text-slate-300 font-mono mt-0.5">
                        {activeService.portalUrl}
                      </p>
                    </div>

                    <a
                      href={activeService.portalUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="btn-gov-blue px-3 py-1.5 text-xs font-semibold flex items-center gap-1.5 shrink-0"
                    >
                      <span>Direct to Portal</span>
                      <ExternalLink className="w-3.5 h-3.5" />
                    </a>
                  </div>

                  <p className="text-[11px] text-slate-300 leading-relaxed pt-2 border-t border-slate-800">
                    Upload your compiled JanSetu Master PDF directly into the portal attachment field. All documents are indexed and ordered according to department scrutiny requirements.
                  </p>
                </div>

                {/* Save Reference Token */}
                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    if (!quickTokenInput.trim()) return;
                    const newApp: TrackedApplication = {
                      id: `track-${Date.now()}`,
                      serviceId: activeService.id,
                      serviceTitle: activeService.title,
                      tokenNumber: quickTokenInput.trim(),
                      dateStarted: new Date().toISOString().split('T')[0],
                      status: 'Submitted',
                      notes: `Master dossier bundled with JanSetu Preflight. Submitted via ${activeService.portalName}.`
                    };
                    setTrackedApplications([newApp, ...trackedApplications]);
                    setQuickTokenSaved(true);
                    setTimeout(() => setQuickTokenSaved(false), 3000);
                    setQuickTokenInput('');
                  }}
                  className="p-3 bg-slate-50 rounded-lg border border-slate-200 flex flex-col gap-2 text-xs"
                >
                  <label className="font-semibold text-slate-900">
                    Save Application Reference / Acknowledgment Token
                  </label>
                  <div className="flex items-center gap-2">
                    <input
                      type="text"
                      value={quickTokenInput}
                      onChange={(e) => setQuickTokenInput(e.target.value)}
                      placeholder="e.g. AP-MS-2026-98124"
                      className="flex-1 bg-white border border-slate-200 rounded px-2.5 py-1 text-xs text-slate-900 focus:outline-none focus:border-slate-900 font-mono"
                    />
                    <button type="submit" className="btn-gov-primary px-3 py-1 text-xs">
                      Save Token
                    </button>
                  </div>
                  {quickTokenSaved && (
                    <span className="text-[11px] text-emerald-700 font-semibold flex items-center gap-1">
                      <Check className="w-3.5 h-3.5" /> Saved to your JanSetu application tracker!
                    </span>
                  )}
                </form>
              </div>
            )}
          </section>

          {/* ----------------------------------------------------
              COLUMN 3: READINESS & COMPLIANCE DISPATCH (3 cols)
              ---------------------------------------------------- */}
          <aside className="lg:col-span-3 flex flex-col gap-3 no-print">
            {/* Preflight Health Scorecard */}
            <div className="pro-card p-3.5 flex flex-col gap-2.5 text-xs">
              <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                <span className="font-bold text-slate-900 flex items-center gap-1.5">
                  <FileCheck2 className="w-3.5 h-3.5 text-blue-600" />
                  Preflight Health
                </span>
                <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded border ${
                  auditReport?.overallStatus === 'Ready for Review'
                    ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                    : auditReport?.overallStatus === 'Issues to Fix'
                    ? 'bg-rose-50 text-rose-700 border-rose-200'
                    : 'bg-amber-50 text-amber-800 border-amber-200'
                }`}>
                  {auditReport ? auditReport.overallStatus : 'Pending'}
                </span>
              </div>

              {/* Score bar */}
              <div className="space-y-1">
                <div className="flex items-center justify-between text-[11px]">
                  <span className="text-slate-500 font-medium">Readiness Score</span>
                  <span className="font-mono font-bold text-slate-900">
                    {auditReport ? auditReport.score : 0} / 100
                  </span>
                </div>
                <div className="w-full h-1.5 bg-slate-100 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-slate-900 transition-all duration-300"
                    style={{ width: `${auditReport ? auditReport.score : 0}%` }}
                  />
                </div>
              </div>

              {/* Breakdown */}
              <div className="grid grid-cols-3 gap-1 text-[10px] pt-1">
                <div className="bg-slate-50 p-1.5 rounded border border-slate-200 text-center">
                  <span className="text-slate-500 block">Docs</span>
                  <strong className="font-mono">{auditReport?.scoreBreakdown.documentCompleteness || 0}/40</strong>
                </div>
                <div className="bg-slate-50 p-1.5 rounded border border-slate-200 text-center">
                  <span className="text-slate-500 block">Consistency</span>
                  <strong className="font-mono">{auditReport?.scoreBreakdown.dataConsistency || 0}/30</strong>
                </div>
                <div className="bg-slate-50 p-1.5 rounded border border-slate-200 text-center">
                  <span className="text-slate-500 block">Statutory</span>
                  <strong className="font-mono">{auditReport?.scoreBreakdown.statutoryCompliance || 0}/30</strong>
                </div>
              </div>

              {/* Master PDF status */}
              {activeCompiledPdf && (
                <div className="p-2 bg-emerald-50 border border-emerald-200 rounded text-[10px] text-emerald-950 flex items-center justify-between">
                  <span>✓ {activeCompiledPdf.pageCount} Pages Bundled</span>
                  <span className="font-mono font-bold">{activeCompiledPdf.fileSize}</span>
                </div>
              )}
            </div>

            {/* Quick Master PDF Compile Action */}
            <div className="pro-card p-3 flex flex-col gap-2">
              <span className="text-[11px] font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
                <FileBox className="w-3.5 h-3.5 text-blue-600" />
                Dossier Compilation
              </span>
              <p className="text-[10px] text-slate-500">
                Stitches all attached documents in statutory sequence for submission.
              </p>
              <button
                onClick={handleCompilePDF}
                disabled={uploadedCount === 0 || isCompilingPDF}
                className={`w-full py-1.5 px-3 rounded text-xs font-semibold flex items-center justify-center gap-1.5 transition-all ${
                  uploadedCount > 0
                    ? 'btn-gov-primary cursor-pointer'
                    : 'bg-slate-100 text-slate-400 cursor-not-allowed border border-slate-200'
                }`}
              >
                <Download className="w-3.5 h-3.5 text-blue-400" />
                <span>{isCompilingPDF ? 'Compiling PDF...' : 'Compile Master PDF'}</span>
              </button>
            </div>

            {/* Target Portal Inspection Action */}
            <div className="pro-card p-3 flex flex-col gap-2 text-xs">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
                  <Globe2 className="w-3.5 h-3.5 text-blue-600" />
                  Target Portal
                </span>
                <span className="text-[10px] text-slate-500 font-mono font-bold">
                  {activePortal.shortCode}
                </span>
              </div>
              <p className="text-[11px] text-slate-800 font-semibold truncate">
                {activeService.portalName}
              </p>
              <button
                type="button"
                onClick={() => setSelectedPortalModal(activePortal)}
                className="btn-gov-secondary text-xs py-1.5 px-2.5 rounded flex items-center justify-between font-semibold"
                title="Open comprehensive portal guidelines, SLA requirements, and precautions"
              >
                <span>Open Portal Guidelines &amp; Rules</span>
                <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
              </button>
            </div>
          </aside>
        </main>
      )}

      {/* ========================================================
          3. VIEW 2: RULE CHANGE RADAR (STANDOUT INNOVATION)
          ======================================================== */}
      {activeTab === 'radar' && (
        <main className="flex-1 max-w-[1600px] w-full mx-auto px-4 lg:px-7 py-4 flex flex-col gap-4">
          <div className="pro-card p-4 flex flex-col md:flex-row md:items-center justify-between gap-3">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <Radar className="w-5 h-5 text-amber-600" />
                <h2 className="text-base sm:text-lg font-bold text-slate-950">
                  Rule Change Radar — Official Notice &amp; Scheme Comparison
                </h2>
              </div>
              <p className="text-xs text-slate-500 max-w-2xl leading-relaxed">
                Compares two dated versions of an official government notification or scholarship guidelines. Highlights changes to deadlines, eligibility criteria, required documents, income limits, and disbursal modes.
              </p>
            </div>

            {/* Scheme Selector */}
            <div className="flex items-center gap-2">
              <select
                value={selectedRadarNoticeId}
                onChange={(e) => setSelectedRadarNoticeId(e.target.value)}
                className="bg-white border border-slate-200 rounded-md px-3 py-1.5 text-xs font-semibold text-slate-900 focus:outline-none focus:border-slate-900 shadow-2xs"
              >
                {RULE_CHANGE_NOTICES.map((n) => (
                  <option key={n.id} value={n.id}>
                    {n.schemeTitle}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Active Notice Details Bar */}
          <div className="pro-card p-4 bg-slate-900 text-white flex flex-col gap-2 text-xs">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <div>
                <span className="text-[10px] font-mono text-amber-400 uppercase tracking-wider block mb-0.5">
                  Comparative Gazette Audit
                </span>
                <h3 className="text-sm font-bold text-white">
                  {activeRadarNotice.schemeTitle}
                </h3>
                <p className="text-[11px] text-slate-300 mt-0.5">
                  {activeRadarNotice.department} · Effective {activeRadarNotice.effectiveDate}
                </p>
              </div>

              <a
                href={activeRadarNotice.verifiedNoticeUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="btn-gov-blue px-3 py-1 text-xs font-semibold flex items-center gap-1.5 shrink-0"
              >
                <span>Verified Official Notice</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-2 pt-2 border-t border-slate-800 text-[11px]">
              <div className="bg-slate-800/60 p-2 rounded border border-slate-700">
                <span className="text-slate-400 text-[10px] block">Previous Baseline Rule:</span>
                <strong className="text-slate-200">{activeRadarNotice.sourceOld}</strong>
              </div>
              <div className="bg-slate-800/60 p-2 rounded border border-slate-700">
                <span className="text-emerald-400 text-[10px] block">Updated Active Framework:</span>
                <strong className="text-white">{activeRadarNotice.sourceNew}</strong>
              </div>
            </div>
          </div>

          {/* Diff Matrix Table */}
          <div className="pro-card overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs pro-table">
                <thead>
                  <tr>
                    <th className="py-2.5 px-3">Requirement Parameter</th>
                    <th className="py-2.5 px-3">Old Rule (Previous Notice)</th>
                    <th className="py-2.5 px-3">New Rule (Updated Notice)</th>
                    <th className="py-2.5 px-3">Impact</th>
                    <th className="py-2.5 px-3">What Applicant Must Do</th>
                    <th className="py-2.5 px-3">Statutory Ref</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {activeRadarNotice.changes.map((c, i) => (
                    <tr key={i} className="hover:bg-slate-50/60">
                      <td className="py-3 px-3 font-semibold text-slate-900 max-w-[180px]">
                        {c.parameter}
                      </td>
                      <td className="py-3 px-3 text-slate-500 bg-rose-50/30 line-through decoration-rose-300 max-w-[220px]">
                        {c.oldValue}
                      </td>
                      <td className="py-3 px-3 font-semibold text-emerald-950 bg-emerald-50/30 max-w-[240px]">
                        {c.newValue}
                      </td>
                      <td className="py-3 px-3">
                        <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded border ${
                          c.impact === 'High'
                            ? 'bg-rose-50 text-rose-700 border-rose-200'
                            : c.impact === 'Medium'
                            ? 'bg-amber-50 text-amber-800 border-amber-200'
                            : 'bg-slate-100 text-slate-700 border-slate-200'
                        }`}>
                          {c.impact}
                        </span>
                      </td>
                      <td className="py-3 px-3 text-slate-700 max-w-[260px] leading-snug">
                        {c.applicantAction}
                      </td>
                      <td className="py-3 px-3 font-mono text-[10px] text-slate-500 truncate max-w-[160px]">
                        {c.statutoryRef}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </main>
      )}

      {/* ========================================================
          4. VIEW 3: COMPILED PDF DOSSIERS ARCHIVE
          ======================================================== */}
      {activeTab === 'dossiers' && (
        <main className="flex-1 max-w-[1600px] w-full mx-auto px-4 lg:px-7 py-4 flex flex-col gap-4">
          <div className="pro-card p-4 flex flex-col md:flex-row md:items-center justify-between gap-3">
            <div>
              <h2 className="text-base sm:text-lg font-bold text-slate-950 flex items-center gap-2">
                <FileBox className="w-5 h-5 text-blue-600" />
                Compiled Master PDF Dossiers Archive
              </h2>
              <p className="text-xs text-slate-500 mt-0.5 max-w-2xl leading-relaxed">
                Every compiled dossier bundles the authentic pages of your uploaded documents in statutory order. Access, preview, and re-download all your PDFs right here.
              </p>
            </div>
            <button
              onClick={() => setActiveTab('studio')}
              className="btn-gov-primary text-xs font-semibold py-1.5 px-3 rounded-md flex items-center gap-1.5 self-start md:self-auto"
            >
              <span>+ Create / Update Dossier</span>
            </button>
          </div>

          {compiledDossiers.length === 0 ? (
            <div className="pro-card p-12 text-center text-slate-500 flex flex-col items-center justify-center gap-2">
              <FileBox className="w-10 h-10 text-slate-300 mb-1" />
              <h3 className="text-sm font-bold text-slate-800">No Compiled PDF Dossiers Yet</h3>
              <p className="text-xs text-slate-500 max-w-md">
                Select a service in the Application Studio, upload your documents in Step 1, verify them in Step 2, and click &ldquo;Compile Master PDF&rdquo; in Step 3.
              </p>
              <button
                onClick={() => setActiveTab('studio')}
                className="btn-gov-primary px-3 py-1.5 rounded-md text-xs font-semibold mt-2"
              >
                Go to Application Studio →
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5">
              {compiledDossiers.map((dossier) => (
                <div key={dossier.id} className="pro-card p-4 flex flex-col justify-between">
                  <div>
                    <div className="flex items-center justify-between gap-2 mb-2">
                      <span className="text-[10px] font-mono font-semibold text-blue-700 bg-blue-50 border border-blue-200 px-2 py-0.5 rounded">
                        {dossier.pageCount} Pages Bundled
                      </span>
                      <span className="text-[10px] text-slate-500 font-mono">
                        {dossier.fileSize}
                      </span>
                    </div>

                    <h3 className="text-xs font-bold text-slate-900 mb-1 leading-snug">
                      {dossier.serviceTitle}
                    </h3>
                    <p className="text-[11px] text-slate-600 mb-2 truncate">
                      Applicant: <span className="font-semibold text-slate-900">{dossier.citizenName}</span>
                    </p>

                    <div className="p-2 bg-slate-50 rounded border border-slate-200 text-[10px] text-slate-600 space-y-1 mb-3">
                      <div className="flex items-center justify-between">
                        <span className="text-slate-500">Target Portal:</span>
                        <span className="font-semibold text-slate-800">{dossier.portalName}</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-slate-500">Compiled:</span>
                        <span className="text-slate-500">{dossier.timestamp}</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5 pt-2 border-t border-slate-100">
                    <button
                      onClick={() => handleDownloadSavedDossier(dossier)}
                      className="flex-1 btn-gov-primary text-xs font-semibold py-1 px-2.5 rounded flex items-center justify-center gap-1"
                    >
                      <Download className="w-3 h-3" />
                      <span>Download PDF</span>
                    </button>
                    <button
                      onClick={() => setPreviewPdfRecord(dossier)}
                      className="p-1 rounded bg-white hover:bg-slate-50 text-slate-600 border border-slate-200"
                      title="Preview"
                    >
                      <Eye className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => handleDeleteSavedDossier(dossier.id)}
                      className="p-1 rounded bg-white hover:bg-rose-50 text-rose-600 border border-slate-200"
                      title="Delete"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </main>
      )}

      {/* ========================================================
          5. VIEW 4: OFFICIAL GOVERNMENT PORTALS DIRECTORY
          ======================================================== */}
      {activeTab === 'portals' && (
        <main className="flex-1 max-w-[1600px] w-full mx-auto px-4 lg:px-7 py-4 flex flex-col gap-4">
          <div className="pro-card p-4 flex flex-col md:flex-row md:items-center justify-between gap-3">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <Globe2 className="w-5 h-5 text-blue-600" />
                <h2 className="text-base sm:text-lg font-bold text-slate-950">
                  Official Government Portals Directory
                </h2>
              </div>
              <p className="text-xs text-slate-500 max-w-2xl leading-relaxed">
                Direct verified government portals for Andhra Pradesh State and Central departments with SSL authentication.
              </p>
            </div>
          </div>

          {/* Search & Filter Bar */}
          <div className="pro-card p-3 flex flex-col sm:flex-row items-center justify-between gap-3">
            <div className="relative w-full sm:w-96">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
              <input
                type="text"
                value={portalSearchQuery}
                onChange={(e) => setPortalSearchQuery(e.target.value)}
                placeholder="Search official portals (e.g. AP Seva, MeeSeva, Jnanabhumi, PM-KISAN)..."
                className="w-full bg-slate-50 border border-slate-200 rounded-md pl-8 pr-3 py-1.5 text-xs text-slate-900 focus:outline-none focus:border-slate-900"
              />
            </div>

            <div className="flex items-center gap-1">
              {(['All', 'State (Andhra Pradesh)', 'Central / National'] as const).map((type) => (
                <button
                  key={type}
                  onClick={() => setPortalTypeFilter(type)}
                  className={`text-xs font-semibold px-2.5 py-1 rounded transition-colors ${
                    portalTypeFilter === type
                      ? 'bg-slate-900 text-white'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {type === 'All' ? 'All' : type.replace(' (Andhra Pradesh)', '')}
                </button>
              ))}
            </div>
          </div>

          {/* Portals Grid - Minimalist High-Performance Directory */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">
            {ALL_GOVERNMENT_PORTALS.filter((portal) => {
              const matchesType = portalTypeFilter === 'All' || portal.type === portalTypeFilter;
              const matchesSearch =
                portalSearchQuery.trim() === '' ||
                portal.name.toLowerCase().includes(portalSearchQuery.toLowerCase()) ||
                portal.department.toLowerCase().includes(portalSearchQuery.toLowerCase()) ||
                portal.shortCode.toLowerCase().includes(portalSearchQuery.toLowerCase());
              return matchesType && matchesSearch;
            }).map((portal) => (
              <div
                key={portal.id}
                onClick={() => setSelectedPortalModal(portal)}
                className="pro-card p-3.5 flex flex-col justify-between hover:border-slate-400 hover:shadow-xs transition-all cursor-pointer group bg-white"
              >
                <div className="flex flex-col gap-2">
                  <div className="flex items-center justify-between gap-1 text-[10px]">
                    <span className="font-mono font-bold text-slate-800 bg-slate-100 px-2 py-0.5 rounded border border-slate-200">
                      {portal.shortCode}
                    </span>
                    <span className="font-mono text-slate-500">
                      {portal.type.includes('Andhra Pradesh') ? 'AP State' : 'Central'}
                    </span>
                  </div>

                  <div>
                    <h3 className="text-xs font-bold text-slate-900 group-hover:text-blue-600 transition-colors leading-snug">
                      {portal.name}
                    </h3>
                    <p className="text-[11px] text-slate-500 truncate mt-0.5">
                      {portal.department}
                    </p>
                  </div>

                  <div className="flex items-center gap-1.5 text-[10px] text-slate-500">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                    <span>{portal.keySchemes.length} Schemes Available</span>
                  </div>
                </div>

                <div className="pt-2.5 mt-2 border-t border-slate-100 flex items-center justify-between text-xs font-semibold text-blue-600 group-hover:text-blue-700">
                  <span className="text-[11px]">Open Portal Details &amp; Guidelines</span>
                  <ChevronRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
                </div>
              </div>
            ))}
          </div>
        </main>
      )}

      {/* ========================================================
          6. VIEW 5: APPLICATION TRACKER
          ======================================================== */}
      {activeTab === 'tracker' && (
        <main className="flex-1 max-w-[1600px] w-full mx-auto px-4 lg:px-7 py-4 flex flex-col gap-4">
          <div className="pro-card p-4 flex flex-col md:flex-row md:items-center justify-between gap-3">
            <div>
              <h2 className="text-base sm:text-lg font-bold text-slate-950">
                Application Reference Tracker
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Saved acknowledgment tokens and physical enquiry status.
              </p>
            </div>
            <button
              onClick={() => setActiveTab('studio')}
              className="btn-gov-primary text-xs font-semibold py-1.5 px-3 rounded"
            >
              <span>+ New Preflight Application</span>
            </button>
          </div>

          <div className="pro-card overflow-hidden">
            {trackedApplications.length === 0 ? (
              <div className="p-8 text-center text-slate-500 text-xs">
                No tracked applications yet.
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs pro-table">
                  <thead>
                    <tr>
                      <th>Service Title</th>
                      <th>Token / App ID</th>
                      <th>Date</th>
                      <th>Status</th>
                      <th>Notes</th>
                      <th className="text-right">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {trackedApplications.map((app) => (
                      <tr key={app.id}>
                        <td className="font-semibold text-slate-900">{app.serviceTitle}</td>
                        <td className="font-mono font-bold text-blue-600">{app.tokenNumber}</td>
                        <td className="text-slate-500">{app.dateStarted}</td>
                        <td>
                          <select
                            value={app.status}
                            onChange={(e) => {
                              const newStatus = e.target.value as any;
                              setTrackedApplications(
                                trackedApplications.map((a) => (a.id === app.id ? { ...a, status: newStatus } : a))
                              );
                            }}
                            className="bg-white border border-slate-200 rounded px-2 py-0.5 text-xs text-slate-800"
                          >
                            <option value="Preparing Documents">Preparing Documents</option>
                            <option value="Ready to Apply">Ready to Apply</option>
                            <option value="Submitted">Submitted</option>
                            <option value="Under Verification">Under Verification</option>
                            <option value="Approved">Approved</option>
                            <option value="Rejected">Rejected</option>
                          </select>
                        </td>
                        <td className="text-slate-500 truncate max-w-xs">{app.notes}</td>
                        <td className="text-right">
                          <button
                            onClick={() => {
                              if (confirm('Delete record?')) {
                                setTrackedApplications(trackedApplications.filter((a) => a.id !== app.id));
                              }
                            }}
                            className="text-rose-600 hover:text-rose-800"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </main>
      )}

      {/* ========================================================
          7. DOCUMENT PREVIEW MODAL
          ======================================================== */}
      {previewDoc && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-lg max-w-2xl w-full p-4 flex flex-col gap-3 shadow-2xl">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <div>
                <h4 className="text-sm font-bold text-slate-900">{previewDoc.name}</h4>
                <p className="text-[10px] text-slate-500 font-mono">
                  {previewDoc.size} · {previewDoc.isImage ? 'Scanned Image' : 'PDF Document'}
                </p>
              </div>
              <button onClick={() => setPreviewDoc(null)} className="p-1 rounded text-slate-400 hover:text-slate-700">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex items-center justify-center bg-slate-50 rounded p-2 max-h-[70vh] overflow-hidden border border-slate-200">
              {previewDoc.isImage ? (
                <img src={previewDoc.dataUrl} alt={previewDoc.name} className="max-h-[65vh] object-contain rounded" />
              ) : (
                <iframe src={previewDoc.dataUrl} title={previewDoc.name} className="w-full h-[60vh] rounded border-0" />
              )}
            </div>
          </div>
        </div>
      )}

      {/* ========================================================
          8. MASTER PDF PREVIEW MODAL
          ======================================================== */}
      {previewPdfRecord && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-lg max-w-4xl w-full h-[85vh] p-4 flex flex-col gap-3 shadow-2xl">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <div>
                <h4 className="text-sm font-bold text-slate-900 flex items-center gap-1.5">
                  <FileText className="w-4 h-4 text-blue-600" />
                  {previewPdfRecord.fileName}
                </h4>
                <p className="text-[10px] text-slate-500 font-mono">
                  {previewPdfRecord.pageCount} Pages · {previewPdfRecord.fileSize} · {previewPdfRecord.serviceTitle}
                </p>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => handleDownloadSavedDossier(previewPdfRecord)}
                  className="btn-gov-primary px-3 py-1 text-xs font-semibold flex items-center gap-1"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download</span>
                </button>
                <button onClick={() => setPreviewPdfRecord(null)} className="p-1 rounded text-slate-400 hover:text-slate-700">
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            <div className="flex-1 bg-slate-100 rounded overflow-hidden border border-slate-200">
              <iframe src={previewPdfRecord.dataUrl} title={previewPdfRecord.fileName} className="w-full h-full border-0" />
            </div>
          </div>
        </div>
      )}

      {/* ========================================================
          8.4 LANDING & PRODUCT ARCHITECTURE MODAL: HOW IT WORKS
          ======================================================== */}
      {isLandingModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-lg max-w-2xl w-full max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
            <div className="bg-slate-950 text-white p-4 flex items-start justify-between gap-3 border-b border-slate-800">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded bg-blue-600 flex items-center justify-center text-white font-bold">
                  <ShieldCheck className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white leading-snug">
                    Your application deserves a smooth takeoff.
                  </h3>
                  <p className="text-xs text-slate-400 mt-0.5">
                    JanSetu Preflight · “Catch the problem before the application.”
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsLandingModalOpen(false)}
                className="p-1 rounded text-slate-400 hover:text-white hover:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-5 overflow-y-auto space-y-4 text-xs text-slate-700">
              <p className="text-slate-600 leading-relaxed text-xs">
                Students and citizens often face rejected scholarship applications due to easily preventable issues: a missing document, a minor spelling mismatch between two records, an outdated income certificate, or obscure portal submission rules. JanSetu Preflight executes a deterministic pre-screening audit before you submit to government portals.
              </p>

              {/* Three Core Feature Pillars */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 flex flex-col gap-1.5">
                  <div className="flex items-center gap-1.5 font-bold text-slate-950 text-xs">
                    <FileCheck2 className="w-4 h-4 text-blue-600 shrink-0" />
                    <span>Document Checks</span>
                  </div>
                  <p className="text-[11px] text-slate-600 leading-snug">
                    Verifies presence of all mandatory documents, file format, and resolution against official gazettes.
                  </p>
                </div>

                <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 flex flex-col gap-1.5">
                  <div className="flex items-center gap-1.5 font-bold text-slate-950 text-xs">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>Requirement Matching</span>
                  </div>
                  <p className="text-[11px] text-slate-600 leading-snug">
                    Compares family income ceilings, institutional criteria, and category entitlements without arbitrary guess-work.
                  </p>
                </div>

                <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 flex flex-col gap-1.5">
                  <div className="flex items-center gap-1.5 font-bold text-slate-950 text-xs">
                    <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
                    <span>Risk Detection</span>
                  </div>
                  <p className="text-[11px] text-slate-600 leading-snug">
                    Catches cross-document name spelling discrepancies and date-of-birth variances that trigger instant rejection.
                  </p>
                </div>
              </div>

              {/* 3-Step Clear Workflow */}
              <div className="p-3.5 bg-blue-50/60 rounded-lg border border-blue-200 space-y-2">
                <span className="text-[11px] font-bold text-blue-950 uppercase tracking-wider block">
                  3-Step Preflight Workflow:
                </span>
                <ol className="space-y-1.5 text-[11px] text-slate-700">
                  <li className="flex items-start gap-2">
                    <strong className="text-blue-900 font-mono">1.</strong>
                    <span><strong>Select Scheme &amp; Ingest Documents:</strong> Choose target scheme and attach required files (or click “Load Demo Application” to test).</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <strong className="text-blue-900 font-mono">2.</strong>
                    <span><strong>Run Preflight Audit:</strong> Inspect deterministic findings with statutory citations, clear evidence, and actionable fixes.</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <strong className="text-blue-900 font-mono">3.</strong>
                    <span><strong>Compile Master PDF &amp; Submit:</strong> Stitch verified vector PDF pages in statutory sequence and submit to verified official gateways.</span>
                  </li>
                </ol>
              </div>

              {/* Disclaimer */}
              <div className="p-2.5 bg-slate-100 rounded border border-slate-200 text-[10px] text-slate-500 leading-relaxed">
                <strong>Responsible-Use Disclaimer:</strong> JanSetu Preflight is an independent pre-submission advisory tool. It does not replace official government revenue scrutiny or guarantee scholarship sanctions. All final decisions rest with the competent statutory authority.
              </div>
            </div>

            <div className="p-3 bg-slate-50 border-t border-slate-200 flex items-center justify-between gap-2">
              <button
                onClick={() => {
                  setIsLandingModalOpen(false);
                  setActiveTab('portals');
                }}
                className="px-3 py-1.5 rounded text-xs font-semibold text-slate-700 hover:text-slate-950 hover:bg-slate-200 transition-colors"
              >
                Explore Portals Directory →
              </button>
              <button
                onClick={() => {
                  setIsLandingModalOpen(false);
                  setActiveTab('studio');
                }}
                className="btn-gov-primary px-4 py-1.5 text-xs font-semibold flex items-center gap-1.5"
              >
                <span>Start Preflight</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================
          8.5 PROGRESSIVE DISCLOSURE MODAL: PORTAL GUIDELINES & SCHEMES
          ======================================================== */}
      {selectedPortalModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-lg max-w-2xl w-full max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
            {/* Header */}
            <div className="bg-slate-950 text-white p-4 flex items-start justify-between gap-3 border-b border-slate-800">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700">
                    {selectedPortalModal.type}
                  </span>
                  <span className="text-[10px] font-mono text-emerald-400 font-bold">
                    {selectedPortalModal.shortCode}
                  </span>
                </div>
                <h3 className="text-base font-bold text-white leading-snug">
                  {selectedPortalModal.name}
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  {selectedPortalModal.department}
                </p>
              </div>
              <button
                onClick={() => setSelectedPortalModal(null)}
                className="p-1 rounded text-slate-400 hover:text-white hover:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Scrollable Body */}
            <div className="p-5 overflow-y-auto space-y-4 text-xs text-slate-700">
              <div>
                <h4 className="text-[11px] font-bold text-slate-900 uppercase tracking-wider mb-1">
                  Portal Overview &amp; Role
                </h4>
                <p className="text-slate-600 leading-relaxed text-xs">
                  {selectedPortalModal.description}
                </p>
              </div>

              {/* Best For Services */}
              <div className="bg-slate-50 p-3.5 rounded-lg border border-slate-200 space-y-2">
                <h4 className="text-[11px] font-bold text-slate-900 uppercase tracking-wider">
                  Available Applications &amp; Best For:
                </h4>
                <ul className="space-y-1.5">
                  {selectedPortalModal.bestFor.map((item, i) => (
                    <li key={i} className="flex items-start gap-2 text-slate-700 leading-snug">
                      <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Submission Tip */}
              <div className="bg-blue-50/60 p-3 rounded-lg border border-blue-200 text-slate-800 space-y-1">
                <span className="text-[11px] font-bold text-blue-950 uppercase tracking-wider block">
                  Official Submission Guide &amp; Tip:
                </span>
                <p className="text-[11px] text-slate-700 leading-relaxed">
                  {selectedPortalModal.instructions}
                </p>
              </div>

              {/* Associated Studio Services */}
              {SERVICES_DATA.some((s) =>
                selectedPortalModal.recommendedComplementaryServices.includes(s.id) ||
                s.portalUrl.toLowerCase().includes(selectedPortalModal.url.toLowerCase())
              ) && (
                <div>
                  <h4 className="text-[11px] font-bold text-slate-900 uppercase tracking-wider mb-2">
                    Prepare Dossier in JanSetu Studio First:
                  </h4>
                  <div className="flex flex-wrap gap-1.5">
                    {SERVICES_DATA.filter((s) =>
                      selectedPortalModal.recommendedComplementaryServices.includes(s.id) ||
                      s.portalUrl.toLowerCase().includes(selectedPortalModal.url.toLowerCase())
                    ).map((s) => (
                      <button
                        key={s.id}
                        onClick={() => {
                          setSelectedServiceId(s.id);
                          setSelectedPortalModal(null);
                          setActiveTab('studio');
                          setCurrentStage(1);
                        }}
                        className="px-2.5 py-1 bg-white hover:bg-slate-50 text-slate-800 border border-slate-200 rounded text-xs font-semibold flex items-center gap-1.5 shadow-2xs"
                      >
                        <Layers className="w-3 h-3 text-blue-600" />
                        <span>{s.shortName}</span>
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Footer Action */}
            <div className="p-3 bg-slate-50 border-t border-slate-200 flex items-center justify-between gap-2">
              <span className="text-[11px] font-mono text-slate-500 truncate max-w-xs">
                {selectedPortalModal.url}
              </span>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setSelectedPortalModal(null)}
                  className="px-3 py-1.5 rounded text-xs font-semibold text-slate-600 hover:text-slate-900"
                >
                  Close
                </button>
                <a
                  href={selectedPortalModal.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn-gov-primary px-3.5 py-1.5 text-xs font-semibold flex items-center gap-1.5"
                >
                  <span>Launch Official Portal</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================
          8.6 PROGRESSIVE DISCLOSURE MODAL: DOCUMENT REQUIREMENTS & SOURCE
          ======================================================== */}
      {selectedDocGuideModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-lg max-w-lg w-full flex flex-col shadow-2xl overflow-hidden">
            <div className="bg-slate-950 text-white p-3.5 flex items-start justify-between gap-3 border-b border-slate-800">
              <div>
                <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block mb-0.5">
                  Document Statutory Specification
                </span>
                <h3 className="text-sm font-bold text-white">
                  {selectedDocGuideModal.name}
                </h3>
              </div>
              <button
                onClick={() => setSelectedDocGuideModal(null)}
                className="p-1 rounded text-slate-400 hover:text-white hover:bg-slate-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-4 space-y-3 text-xs text-slate-700">
              <div className="flex items-center gap-2">
                <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded border ${
                  selectedDocGuideModal.isMandatory
                    ? 'bg-rose-50 text-rose-700 border-rose-200'
                    : 'bg-slate-100 text-slate-700 border-slate-200'
                }`}>
                  {selectedDocGuideModal.isMandatory ? 'Mandatory Requirement' : 'Optional Supporting Proof'}
                </span>
                <span className="text-[10px] font-mono text-slate-500 bg-slate-100 px-2 py-0.5 rounded border border-slate-200">
                  Format: {selectedDocGuideModal.format} (Max 5MB)
                </span>
              </div>

              <div>
                <strong className="text-slate-900 block mb-0.5">Scrutiny Instructions:</strong>
                <p className="text-slate-600 leading-relaxed text-[11px]">
                  {selectedDocGuideModal.instructions}
                </p>
              </div>

              <div className="p-2.5 bg-slate-50 rounded border border-slate-200 space-y-1 text-[11px]">
                <div>
                  <strong className="text-slate-900">Where to Obtain:</strong> {selectedDocGuideModal.whereToGet}
                </div>
                <div>
                  <strong className="text-slate-900">Statutory Purpose:</strong> {selectedDocGuideModal.whyNeeded}
                </div>
              </div>

              <div className="bg-emerald-50 p-2.5 rounded border border-emerald-200 text-[11px] text-emerald-950 space-y-0.5">
                <strong className="block text-emerald-900">Acceptance Standards:</strong>
                <p>• Clean, uncropped digital scan (150+ DPI resolution)</p>
                <p>• Full name and dates must be legible without blur</p>
                <p>• Valid for submission at all 15,004+ Grama &amp; Ward Secretariats</p>
              </div>
            </div>

            <div className="p-2.5 bg-slate-50 border-t border-slate-200 flex justify-end">
              <button
                onClick={() => setSelectedDocGuideModal(null)}
                className="btn-gov-primary px-3 py-1.5 text-xs font-semibold"
              >
                Got It
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================
          8.7 PROGRESSIVE DISCLOSURE MODAL: STATUTORY SLA & ANTI-REJECTION
          ======================================================== */}
      {isStatutoryWorkflowModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-lg max-w-xl w-full max-h-[88vh] flex flex-col shadow-2xl overflow-hidden">
            <div className="bg-slate-950 text-white p-3.5 flex items-start justify-between gap-3 border-b border-slate-800">
              <div>
                <span className="text-[10px] font-mono text-emerald-400 uppercase tracking-wider block mb-0.5">
                  Statutory Guarantee &amp; Scrutiny Framework
                </span>
                <h3 className="text-sm font-bold text-white">
                  {activeService.title}
                </h3>
              </div>
              <button
                onClick={() => setIsStatutoryWorkflowModalOpen(false)}
                className="p-1 rounded text-slate-400 hover:text-white hover:bg-slate-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-4 overflow-y-auto space-y-4 text-xs text-slate-700">
              {/* SLA Banner */}
              <div className="p-2.5 bg-slate-50 rounded border border-slate-200 flex items-center justify-between text-xs">
                <div>
                  <span className="text-slate-500 block text-[10px]">Guaranteed Statutory Turnaround:</span>
                  <strong className="font-mono text-slate-900 text-sm">{activeService.processingDays}</strong>
                </div>
                <div className="text-right">
                  <span className="text-slate-500 block text-[10px]">Official User Fee:</span>
                  <strong className="font-mono text-slate-900">{activeService.fee}</strong>
                </div>
              </div>

              {/* 4-Step Flow */}
              <div>
                <h4 className="text-[11px] font-bold text-slate-900 uppercase tracking-wider mb-2">
                  Official 4-Tier Revenue Verification Workflow:
                </h4>
                <div className="space-y-2 relative pl-3 border-l-2 border-slate-300 text-[11px]">
                  <div>
                    <strong className="text-slate-900 block text-xs">1. Citizen Submission</strong>
                    <span className="text-slate-600">Application and compiled JanSetu Master PDF uploaded on the official portal.</span>
                  </div>
                  <div>
                    <strong className="text-slate-900 block text-xs">2. Sachivalayam Field Scrutiny</strong>
                    <span className="text-slate-600">Village Revenue Officer (VRO) conducts local enquiry within 3 days.</span>
                  </div>
                  <div>
                    <strong className="text-slate-900 block text-xs">3. Revenue Inspector Review</strong>
                    <span className="text-slate-600">Cross-verified against Webland 2.0 and Rice Card databases.</span>
                  </div>
                  <div>
                    <strong className="text-slate-900 block text-xs">4. Tahsildar Digital Signature</strong>
                    <span className="text-slate-600">Digital signature issued within {activeService.processingDays}.</span>
                  </div>
                </div>
              </div>

              {/* Precautions */}
              <div className="bg-amber-50/70 p-3 rounded border border-amber-200">
                <h4 className="text-[11px] font-bold text-amber-950 uppercase tracking-wider mb-1.5 flex items-center gap-1">
                  <ShieldAlert className="w-3.5 h-3.5 text-amber-600" />
                  Anti-Rejection Precautions
                </h4>
                <ul className="space-y-1 text-[11px] text-amber-900">
                  {activeService.precautions.map((p, i) => (
                    <li key={i} className="flex items-start gap-1.5">
                      <span className="text-amber-600 font-bold">•</span>
                      <span>{p}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Grievance Helpdesk */}
              <div className="p-2.5 bg-slate-950 text-white rounded text-[11px] flex items-center justify-between">
                <div>
                  <strong className="block text-slate-200">Delay or Grievance Escalation:</strong>
                  <span className="text-slate-400">Toll-free 1902 (Spandana Grievance Portal)</span>
                </div>
                <a
                  href="https://spandana.ap.gov.in/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn-gov-blue px-2.5 py-1 text-[10px] font-semibold flex items-center gap-1"
                >
                  <span>Spandana</span>
                  <ExternalLink className="w-2.5 h-2.5" />
                </a>
              </div>
            </div>

            <div className="p-2.5 bg-slate-50 border-t border-slate-200 flex justify-end">
              <button
                onClick={() => setIsStatutoryWorkflowModalOpen(false)}
                className="btn-gov-primary px-3 py-1.5 text-xs font-semibold"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================
          9. AI COUNSELOR & VOICE MODAL
          ======================================================== */}
      <GeminiChatbot
        isOpen={isChatbotOpen}
        onClose={() => setIsChatbotOpen(false)}
        onOpenVoiceModal={() => setIsVoiceModalOpen(true)}
        onSelectService={(serviceId) => {
          setSelectedServiceId(serviceId);
          setActiveTab('studio');
          setCurrentStage(1);
        }}
        activeServiceTitle={activeService.title}
        citizenName={applicant.fullName}
        lang={lang}
      />

      <VoiceConversationModal
        isOpen={isVoiceModalOpen}
        onClose={() => setIsVoiceModalOpen(false)}
        onSelectService={(serviceId) => {
          setSelectedServiceId(serviceId);
          setActiveTab('studio');
          setCurrentStage(1);
        }}
        lang={lang}
      />

      {/* Floating Action Trigger for AI Counselor */}
      {!isChatbotOpen && (
        <button
          onClick={() => setIsChatbotOpen(true)}
          className="fixed bottom-5 right-5 z-40 bg-slate-950 hover:bg-slate-800 text-white rounded-lg px-3.5 py-2.5 shadow-xl flex items-center gap-2 border border-slate-700 text-xs font-semibold no-print"
          title="Open JanSetu AI Counselor"
        >
          <Zap className="w-4 h-4 text-amber-400 fill-amber-400" />
          <span>Ask AI Counselor</span>
          <span className="text-[10px] text-emerald-400 font-mono">⚡ Groq</span>
        </button>
      )}

      {/* ========================================================
          10. PRINTABLE OFFICIAL PREFLIGHT AUDIT CERTIFICATE
          ======================================================== */}
      {auditReport && (
        <div className="hidden print:block p-8 bg-white text-black font-serif text-sm">
          <div className="border-b-2 border-black pb-4 mb-4 text-center">
            <h1 className="text-xl font-bold uppercase tracking-wide">
              JANSETU PREFLIGHT — OFFICIAL STATUTORY SCRUTINY REPORT
            </h1>
            <p className="text-xs mt-1">
              National Citizen Application Pre-Screening &amp; Quality Audit Console
            </p>
            <p className="text-xs font-mono mt-0.5">
              Generated: {auditReport.timestamp} · Reference: JS-PREFLIGHT-{selectedServiceId.toUpperCase()}
            </p>
          </div>

          <div className="grid grid-cols-2 gap-4 border border-black p-3 mb-4 text-xs font-sans">
            <div>
              <p><strong>Candidate Name:</strong> {applicant.fullName}</p>
              <p><strong>Date of Birth:</strong> {applicant.dob || 'Unspecified'}</p>
              <p><strong>Institution:</strong> {applicant.institution || 'Unspecified'}</p>
            </div>
            <div>
              <p><strong>Target Scheme:</strong> {activeService.title}</p>
              <p><strong>Target Department:</strong> {activeService.department}</p>
              <p><strong>Annual Family Income:</strong> ₹{applicant.annualFamilyIncome.toLocaleString()}</p>
            </div>
          </div>

          <div className="mb-4">
            <h2 className="font-bold text-sm uppercase mb-2 font-sans border-b border-black pb-1">
              Overall Preflight Scrutiny Status: {auditReport.overallStatus} (Score: {auditReport.score}/100)
            </h2>
            <div className="space-y-3 text-xs font-sans">
              {auditReport.findings.map((f, i) => (
                <div key={i} className="border-b border-slate-300 pb-2">
                  <p className="font-bold">[{f.category.toUpperCase()}] {f.title}</p>
                  <p><strong>Finding:</strong> {f.triggeredBy}</p>
                  <p><strong>Required Action:</strong> {f.recommendedAction}</p>
                  <p className="text-[10px] text-slate-700"><strong>Statutory Citation:</strong> {f.statutoryRuleRef}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-8 pt-4 border-t border-black text-[10px] text-slate-600 font-sans">
            Disclaimer: JanSetu Preflight is an advisory scrutiny engine designed to prevent common procedural rejections. It is not an official government approval or guarantee of grant. Final eligibility determination rests exclusively with the competent statutory authority.
          </div>
        </div>
      )}

      {/* ========================================================
          11. MINIMALIST FOOTER
          ======================================================== */}
      <footer className="border-t border-slate-200 bg-white py-4 px-4 lg:px-7 mt-auto text-xs text-slate-500 no-print">
        <div className="max-w-[1600px] mx-auto flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-slate-900" />
            <span>JanSetu Preflight · “Catch the problem before the application.”</span>
          </div>
          <div className="flex items-center gap-3 text-slate-400">
            <span>Andhra Pradesh &amp; Central Schemes</span>
            <span>·</span>
            <span>Non-repudiation Master PDF Bundler</span>
            <span>·</span>
            <span className="font-mono text-[11px] text-slate-500">Groq LPU Engine Active</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
