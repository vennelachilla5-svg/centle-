# JanSetu — Government Services, Within Everyone’s Reach

**JanSetu** is an accessible, modern, citizen-friendly civic technology platform designed to bridge the gap between Indian citizens and government welfare schemes. With a primary focus on **Andhra Pradesh Government Certificates & Scholarships** alongside flagship Central Government missions, JanSetu demystifies eligibility criteria, outlines exact documents required, provides critical anti-fraud precautions, and links directly to official government portals (`.gov.in` and `.nic.in`).

---

## 🌟 Available Features

1. **Minimal, Charismatic White Application Studio (Side-by-Side Workspace):**
   - Clean, minimal white aesthetic (`#ffffff` / `#f8fafc`) with subtle borders, crisp slate typography, and single cohesive royal blue accent. Zero visual clutter or rainbow gradients.
   - **Side-by-Side layout:** Select any service on the left navigator (AP Integrated Caste, Income Certificate, Rice Card, NMMS Scholarship, EWS, Birth Certificate, PM-KISAN, etc.) and immediately interact on the center workspace while inspecting live dossier status and official portal rules on the right.

2. **Sequential Step-by-Step Progressive Unlocking:**
   - **Step 1: Document Upload & Checklist with Drag-and-Drop Zones:**
     - Batch multi-file drag-and-drop zone at the top plus individual drag-over targets on every document slot.
     - Automatically smart-matches dropped files by name into the appropriate slots or fills pending requirements.
     - Displays visual thumbnails (image previews with zoom modal for images; PDF document badges with file details and view icon for PDFs).
     - Stored reliably in local browser state (`localStorage`).
     - Completing all mandatory uploads unlocks Step 2.
   - **Step 2: Quality & Completeness Audit** (Locked until Step 1 complete). Verifies name matches, validity dates, scan legibility, and physical originals. Confirming audit unlocks Step 3.
   - **Step 3: Arrange Sequence & Compile Master PDF** (Locked until Step 2 complete). Reorder documents to match official portal sequence, enter citizen name, and compile official PDF dossier. Compiling unlocks Step 4.
   - **Step 4: Launch Official Portal** (Locked until Step 3 complete). Follow official procedure checklist, direct 1-click launch to the government portal in a new tab, and record reference tokens in the Tracker.

3. **Master PDF Dossier Bundler (`pdf-lib` Real Document Merger):**
   - Merges the **complete authentic pages of all uploaded PDFs** and embeds all uploaded images onto full-size A4 pages in exact official sequence.
   - Generates an official cover page with the document index table, citizen name, verification timestamps, and legal cautions.
   - Named for the required work and applicant: `[Work_Name]_Application_Dossier_[Applicant_Name].pdf`.
   - **All Compiled PDFs Archive (`All Compiled PDFs` Tab):** View and manage all compiled dossiers across all services in one unified place with 1-click downloads, in-browser PDF previews, and timestamps.

4. **Direct Redirection to Any Official Government Portal & AI Portal Counselor:**
   - **Direct Official Portal Redirection:** Links directly into verified official government portals online (`.gov.in` and `.nic.in` like AP Seva VSWS, AP MeeSeva, AP Jnanabhumi, BSE AP, BIE AP, Dr. YSR Aarogyasri, AP Spandana, NSP, PM-KISAN, NHA PM-JAY, UIDAI MyAadhaar, ECI Voters, Protean PAN, Parivahan Sarathi, e-Shram, and Swavlamban UDID).
   - **Official Government Portals Directory (`Official Portals` Tab):** Search, browse, and filter all 16 state and central government portals with descriptions, key schemes, step-by-step submission instructions, and direct links to prepare associated dossiers in JanSetu Studio.
   - **Suggested Alternative & Complementary Options in Step 4:** Automatically suggests other high-value schemes and portals the citizen qualifies for (e.g., college fee reimbursement on Jnanabhumi and NSP when applying for Caste/Income; e-Crop and Rythu Bharosa when applying for PM-KISAN).
   - **AI Portal Counselor (Powered by Gemini):** Interactive chat and voice assistant that answers citizen queries, analyzes family profile needs, suggests the best government schemes and cross-department welfare programs, and provides direct action buttons to launch the portal or prepare the dossier in the Studio.

2. **Dedicated Andhra Pradesh Master Guide:**
   - Exhaustive guides for:
     - **Birth Certificate & Delayed Registration** (Local register search, Non-Availability Certificate / NAC, Magistrate orders).
     - **Rice Card / Ration Card** (AP Grama-Ward Sachivalayam eligibility: income, land, and unit thresholds).
     - **Integrated Caste Certificate** (Nativity, Community, and Date of Birth on AP Seva).
     - **Income Certificate** (MeeSeva revenue issuance and academic year validity).
     - **EWS (Income & Asset) Certificate** (Central vs. State criteria, 10% quota rules).
     - **NMMS / NMMSS Scholarship** (Class VIII BSE AP exam and National Scholarship Portal DBT).
     - **Farmer Land & Scheme Registration** (e-Crop booking, RBK, and Webland integration).
     - **AP Jnanabhumi** (Post-matric fee reimbursements, Vidya Deevena, Vasathi Deevena).
     - **Disability / UDID, Voter ID Form 6, Driving Licence, PAN, and Passport Seva**.

3. **Government Scheme Explorer:**
   - Filter by categories: Education & Scholarships, Agriculture & Farmers, Healthcare, Housing, Employment & Skills, Women & Child Welfare, Senior Citizens, Social Security, and Entrepreneurship.
   - Filter by beneficiary groups (Students, Farmers, Unorganized Workers, Women, PwDs, Street Vendors, Low Income).
   - Card bookmarks with instant synchronization.

4. **Scheme Details Modal:**
   - Full eligibility checklist.
   - Concrete subsidies and benefits breakdown.
   - Step-by-step application walkthrough.
   - Direct "+ Add to Checklist" buttons for each document.
   - Verified official `.gov.in` outbound routing.

5. **Smart Scheme Finder (Interactive 4-Step Questionnaire):**
   - Questions covering:
     1. State & Urban/Rural Residence
     2. Age Group & Social Category (SC/ST/BC/EWS)
     3. Occupation (Student, Cultivator, Daily Wage, Street Vendor, PwD, etc.)
     4. Household Annual Income & Landholding
   - Deterministic client-side matching algorithm that scores schemes and explains **"Why this fits you"** alongside key caveats.

6. **Citizen Dashboard:**
   - **Saved Schemes:** Pinned schemes that persist across browser sessions.
   - **Application Tracker (CRUD):** Log applications with MeeSeva / NSP reference tokens, set status (*Interested, Preparing Documents, Ready to Apply, Submitted, Awaiting Response, Completed, Rejected*), record personal notes, and filter by status.
   - **Document Checklist:** Aggregated list of documents required for your bookmarked schemes, with progress bar, toggle checkboxes, custom document creator, and reset capability.

7. **Public Services Directory:**
   - Direct reference directory for AP MeeSeva, AP Seva, UIDAI My Aadhaar, BSE AP, NSP, AP Jnanabhumi, Parivahan Sarathi, Passport Seva, Voters Service, and UDID.

8. **Citizen Safety & Anti-Fraud Checklist:**
   - Crucial instructions on never sharing OTPs or bank PINs, avoiding middleman scams, checking spelling against Aadhaar, and keeping original certificates safe.

9. **Multi-Language Selector:**
   - Live switching between **English**, **Telugu (తెలుగు)**, and **Hindi (हिन्दी)**.

10. **Voice Accessibility (Text-to-Speech):**
    - Browser-native Web Speech API audio narration for scheme summaries and assistant answers.

11. **JanSetu Help Assistant (FAQ Chatbot):**
    - Instant answers to common questions about Andhra Pradesh certificates, NMMS scholarship, Rice Cards, and application steps.

---

## 📁 Project File Structure

```text
jansetu/
├── index.html     # Semantic HTML5 structure, navigation, sections, modals, and templates
├── style.css      # Custom Indian civic-tech CSS design system (Navy, Teal, Saffron accents)
├── script.js      # Vanilla JavaScript engine, datasets, matching algorithm, storage & audio
└── README.md      # Documentation and technical guide
```

---

## 🚀 How to Run the Application

### Option 1: Direct File Opening (No Installation Required)
JanSetu is built strictly with standard **HTML5, CSS3, and Vanilla JavaScript**.
1. Download or clone this repository.
2. Double-click `index.html` (or right-click and choose **Open with Google Chrome / Mozilla Firefox / Microsoft Edge / Safari**).
3. The application runs immediately in your browser. No Node.js, Python, package manager, or build step is required!

### Option 2: Live Local Server (Vite / AI Studio Preview)
If running inside the AI Studio dev environment or a local static server:
```bash
npm run dev
```
Open `http://localhost:3000` in your browser.

---

## 💾 How LocalStorage is Used

JanSetu uses the browser's native `localStorage` API to preserve citizen progress across reloads:
- `jansetu_saved_schemes_v1`: Array of bookmarked scheme IDs.
- `jansetu_app_tracker_v1`: Array of user-created application tracking records.
- `jansetu_doc_checklist_v1`: Key-value map of document names and their preparation state (`true` / `false`).
- `jansetu_demo_user_v1`: Simulated citizen profile session.
- `jansetu_lang_v1`: Active language choice (`en`, `te`, or `hi`).

---

## 🔒 Security & Prototype Limitations

1. **Client-Side Storage Only:** `localStorage` saves data exclusively on the local machine and browser profile where it was entered. Clearing browser cache will reset saved progress.
2. **No Live Government Sync:** The application tracker reflects progress entered manually by the citizen. It does not ping live government databases (MeeSeva or NSP) for real-time application tokens.
3. **Demo Authentication:** The login and registration modal is an interactive demonstration. It does not securely hash passwords or connect to an identity server. **Citizens must never enter their Aadhaar numbers, OTPs, or banking PINs into this prototype.**
4. **Informational Verification:** Eligibility rules, fee schedules, and deadlines can change by academic year or government order (G.O.). Citizens must always verify current notices on official `.gov.in` portals or at their local Grama/Ward Sachivalayam.

---

## 🛠️ How to Modify or Add New Schemes

To add a new scheme, open `script.js` and append an object to `SCHEMES_DATA`:

```javascript
{
  id: 'unique-scheme-id',
  name: 'Scheme Title',
  category: 'Education and Scholarships', // Or another valid category
  state: 'Andhra Pradesh', // Or 'Central / All India'
  beneficiaries: 'Target audience description',
  description: '1-2 sentence overview of the scheme.',
  eligibility: [
    'Criterion 1',
    'Criterion 2'
  ],
  benefits: [
    'Financial benefit or subsidy description'
  ],
  documents: [
    'Document 1',
    'Document 2'
  ],
  steps: [
    '1) Step 1',
    '2) Step 2'
  ],
  officialUrl: 'https://official-portal.gov.in/',
  sourceUrl: 'https://source-reference.gov.in/',
  verified: true,
  verificationStatus: 'Official Government Service'
}
```

The scheme will automatically appear in search, category filters, the Smart Finder questionnaire, and the Document Checklist!

---

## 🔮 Future Production Architecture

To transition JanSetu from a frontend prototype into a production service:
1. **Backend API:** An Express/Node.js or Python FastAPI service with rate limiting and audit logging.
2. **Database:** PostgreSQL / Cloud SQL for storing citizen tracking, reminders, and regional secretariat directories.
3. **Official Open APIs:** Digilocker API integration for verifying issued certificates directly, and UMANG API integration where authorized.
4. **SMS/WhatsApp Notifications:** Alerts for upcoming scholarship exam dates (e.g., AP NMMS notifications).

---

## ⚖️ Civic Technology Disclaimer

JanSetu is an independent educational civic prototype. It is not affiliated with, sponsored by, or endorsed by the Government of India or the Government of Andhra Pradesh. All trademarks and official names belong to their respective government departments.
