/**
 * JanSetu — Government Services, Within Everyone’s Reach
 * Complete Vanilla JavaScript Application Engine
 */

(function () {
  'use strict';

  /* ==========================================================================
     1. DATASETS: SCHEMES & PUBLIC SERVICES
     ========================================================================== */

  const SCHEMES_DATA = [
    {
      id: 'ap-caste-integrated',
      name: 'AP Integrated Certificate (Caste, Nativity & Date of Birth)',
      category: 'Education and Scholarships',
      state: 'Andhra Pradesh',
      beneficiaries: 'SC, ST, BC, Minorities and eligible communities in Andhra Pradesh',
      description: 'Single unified certificate covering community/caste, nativity, and date of birth for educational admissions, scholarships, and employment in Andhra Pradesh.',
      eligibility: [
        'Resident of Andhra Pradesh belonging to a recognized SC/ST/BC community',
        'Official school or revenue records confirming caste or parents caste record',
        'Transfer certificate (TC) or SSC marks memo showing recorded caste'
      ],
      benefits: [
        'Mandatory document for AP Jnanabhumi scholarships and post-matric fee reimbursement',
        'Valid for educational reservations in colleges, universities, and polytechnics',
        'Applicable for government job recruitments under state quota'
      ],
      documents: [
        'SSC Marks Memo or Transfer Certificate (TC) / Birth Record',
        'Previously issued Caste Certificate of applicant or parents/family member',
        'Aadhaar Card or accepted Photo Identity Proof',
        'Address Proof (Rice Card / Electricity Bill / Residence Certificate)',
        'Passport size photograph of applicant'
      ],
      steps: [
        'Visit your local Grama/Ward Sachivalayam or login to AP Seva / MeeSeva portal.',
        'Select Integrated Certificate service and verify the required checklist.',
        'Upload/submit required proofs and family caste records.',
        'Revenue officials (VRO / RI / Tahsildar) verify field details and records.',
        'Track status using MeeSeva token; download or collect the approved certificate.'
      ],
      officialUrl: 'https://vsws.ap.gov.in/',
      sourceUrl: 'https://onlineap.meeseva.gov.in/',
      verified: true,
      verificationStatus: 'Official AP Government Service'
    },
    {
      id: 'ap-nmms-scholarship',
      name: 'AP National Means-cum-Merit Scholarship Scheme (NMMS)',
      category: 'Education and Scholarships',
      state: 'Andhra Pradesh',
      beneficiaries: 'Class VIII students studying in Government, Local Body, and Aided Schools',
      description: 'Centrally sponsored scholarship awarded to meritorious students from economically weaker sections to arrest dropouts after Class VIII, funded via National Scholarship Portal.',
      eligibility: [
        'Student currently studying in Class VIII in AP Government, Zilla Parishad, Municipal, or Govt-aided school',
        'Minimum 55% marks (50% for SC/ST) in Class VII examination',
        'Parental annual income from all sources must not exceed ₹3,50,000 per annum',
        'Student must appear and qualify in the state-level NMMS examination conducted by BSE AP'
      ],
      benefits: [
        'Scholarship of ₹12,000 per year (₹1,000 per month) from Class IX to Class XII',
        'Direct Benefit Transfer (DBT) into the student’s bank account linked with Aadhaar',
        'Supports complete secondary and higher secondary education'
      ],
      documents: [
        'Class VII marks card / promotion certificate',
        'Income Certificate issued by Tahsildar (under ₹3.5 Lakh)',
        'Integrated Caste Certificate (for SC/ST/BC students)',
        'Disability Certificate (if applicable)',
        'Student Aadhaar Card & Aadhaar-seeded Bank Account passbook',
        'School Study / Bonafide Certificate'
      ],
      steps: [
        'Check BSE AP exam notification released by Directorate of Government Examinations, AP.',
        'Apply through school Headmaster / Principal with required documents and exam fee.',
        'Appear for Mental Ability Test (MAT) and Scholastic Aptitude Test (SAT).',
        'Upon selection in state merit list, complete One Time Registration (OTR) on National Scholarship Portal.',
        'Submit fresh application and renew annually with school verification on NSP.'
      ],
      officialUrl: 'https://bse.ap.gov.in/',
      sourceUrl: 'https://scholarships.gov.in/',
      verified: true,
      verificationStatus: 'Verified with BSE AP & NSP'
    },
    {
      id: 'ap-rice-card',
      name: 'Andhra Pradesh Rice Card / Ration Card',
      category: 'Social Security',
      state: 'Andhra Pradesh',
      beneficiaries: 'Eligible BPL and low-income households in Andhra Pradesh',
      description: 'Household food security card issued by the Andhra Pradesh Food & Civil Supplies Department enabling subsidized rice, essential commodities, and access to state welfare schemes.',
      eligibility: [
        'Family total income in rural areas less than ₹10,000/month; urban areas less than ₹12,000/month',
        'Total land holding less than 3 acres wetland or 10 acres dry land',
        'Monthly electricity consumption below 300 units',
        'No family member should be a government employee or pension holder (sanitation workers exempted)',
        'Family should not own a four-wheeler (taxis, tractors, autos exempted)'
      ],
      benefits: [
        'Subsidized rice (5 kg per person) and essential commodities at doorsteps / fair price shops',
        'Serves as the primary household identity key for AP welfare and health benefits',
        'Eligibility anchor for Dr. YSR Aarogyasri health coverage'
      ],
      documents: [
        'Aadhaar cards of all family members',
        'Address proof (Electricity bill, House tax receipt, or Rental agreement)',
        'Income certificate or self-declaration for verification',
        'Bank passbook copy of female head of the family',
        'Active mobile number linked to Aadhaar'
      ],
      steps: [
        'Approach the Grama / Ward Sachivalayam Digital Assistant or Welfare Assistant.',
        'Submit the application for New Rice Card or family member addition/modification.',
        'Field verification is conducted by the Village/Ward Volunteer and Welfare Assistant.',
        'Recommendation is processed by Tahsildar / Municipal Commissioner.',
        'Track status using Aadhaar number; collect QR-coded Rice Card upon approval.'
      ],
      officialUrl: 'https://vsws.ap.gov.in/',
      sourceUrl: 'https://onlineap.meeseva.gov.in/',
      verified: true,
      verificationStatus: 'Official AP Government Service'
    },
    {
      id: 'ap-income-certificate',
      name: 'Andhra Pradesh Income Certificate',
      category: 'Social Security',
      state: 'Andhra Pradesh',
      beneficiaries: 'Citizens, students, and families applying for fee reimbursements and welfare subsidies',
      description: 'Revenue authority certification of annual household income, required as formal eligibility proof for state scholarships, fee waivers, and central economic benefits.',
      eligibility: [
        'Resident of Andhra Pradesh',
        'Applicant having verifiable annual income records or non-taxable income proofs'
      ],
      benefits: [
        'Qualifies students for AP Jnanabhumi Vidya Deevena & Vasathi Deevena education benefits',
        'Used for central and state welfare scheme eligibility determinations',
        'Valid typically for one financial year from the date of issue'
      ],
      documents: [
        'Aadhaar Card of the applicant and family head',
        'Rice Card / Ration Card copy',
        'Salary certificate or Form 16 (for salaried persons) or IT returns',
        'Non-salaried: Affidavit of income, land revenue receipt or local enquiry record',
        'Electricity bill / gas connection bill for residential proof'
      ],
      steps: [
        'Log in to AP MeeSeva Citizen Portal or visit Grama/Ward Sachivalayam.',
        'Fill Income Certificate application and upload genuine income documents.',
        'Pay standard government MeeSeva processing fee.',
        'Village Revenue Officer (VRO) and Revenue Inspector (RI) review the application.',
        'Tahsildar approves digitally signed certificate downloadable with MeeSeva token.'
      ],
      officialUrl: 'https://onlineap.meeseva.gov.in/',
      sourceUrl: 'https://vsws.ap.gov.in/',
      verified: true,
      verificationStatus: 'Official AP Revenue Service'
    },
    {
      id: 'ap-birth-certificate',
      name: 'Birth Certificate & Delayed Registration (AP MeeSeva)',
      category: 'Social Security',
      state: 'Andhra Pradesh',
      beneficiaries: 'Citizens born in Andhra Pradesh requiring registered proof of birth',
      description: 'Official vital record certifying the date, time, and place of birth, issued by Municipal Commissioners or Panchayat Secretaries under the Registration of Births and Deaths Act.',
      eligibility: [
        'Birth occurred within the jurisdiction of Andhra Pradesh municipality or gram panchayat',
        'For delayed registration (after 1 year): Requires Magistrate Order / Revenue enquiry'
      ],
      benefits: [
        'Primary legal proof of age and date of birth for school admission, passport, and driving licence',
        'Essential for claiming inheritance, rights, and citizenship services'
      ],
      documents: [
        'Hospital discharge summary / institutional birth record or Form 1',
        'Parents’ Aadhaar Cards and address proof',
        'School transfer certificate or SSC memo (for delayed registrations)',
        'Affidavit explaining reasons for delayed registration (if over 1 year)',
        'Non-Availability Certificate (NAC) issued by the local registrar if record not found'
      ],
      steps: [
        'Check existing birth register at the local Municipality or Gram Panchayat office / MeeSeva.',
        'If already recorded, apply for certified extract through AP MeeSeva.',
        'If not found, obtain Non-Availability Certificate (NAC).',
        'Apply for delayed registration with Magistrate order / Revenue Divisional Officer (RDO) sanction.',
        'Download digitally signed certificate from MeeSeva once approved.'
      ],
      officialUrl: 'https://onlineap.meeseva.gov.in/',
      sourceUrl: 'https://cdma.ap.gov.in/',
      verified: true,
      verificationStatus: 'Official Vital Records Portal'
    },
    {
      id: 'ap-ews-certificate',
      name: 'Economically Weaker Section (EWS) Certificate',
      category: 'Education and Scholarships',
      state: 'Andhra Pradesh',
      beneficiaries: 'General category citizens meeting economically weaker section criteria',
      description: 'Income and Asset Certificate for general category applicants not covered under SC/ST/OBC reservations, providing 10% reservation in central and state institutions.',
      eligibility: [
        'Applicant must belong to General Category (not covered under SC, ST, or BC lists)',
        'Family gross annual income must be below ₹8,00,000 (Rupees Eight Lakhs)',
        'Family must not own 5 acres or more of agricultural land',
        'Residential flat size must be below 1000 sq. ft., or plot below 100 sq. yards in notified municipalities'
      ],
      benefits: [
        '10% reservation in Central & State Government jobs (UPSC, APPSC, SSC, Banking)',
        '10% reservation in higher education admissions (IITs, NITs, Central Universities, NEET, JEE)'
      ],
      documents: [
        'Aadhaar card of the applicant and parents',
        'Income proof (Salary slip, Form 16, or IT Return acknowledgement)',
        'Land revenue records / Pattadar passbook details',
        'House property title deeds or municipal tax receipts',
        'Affidavit certifying non-possession of excluded assets'
      ],
      steps: [
        'Verify eligibility rules specific to Central or State government benefit needed.',
        'Apply via AP MeeSeva / Grama Sachivalayam under Income & Asset Certificate for EWS.',
        'Upload verified family income, agricultural land, and residential property documents.',
        'Revenue officials carry out asset verification.',
        'Collect valid EWS certificate signed by Tahsildar.'
      ],
      officialUrl: 'https://onlineap.meeseva.gov.in/',
      sourceUrl: 'https://vsws.ap.gov.in/',
      verified: true,
      verificationStatus: 'Official AP Revenue Service'
    },
    {
      id: 'ap-farmer-registration',
      name: 'Andhra Pradesh Farmer Land & Scheme Registration',
      category: 'Agriculture and Farmers',
      state: 'Andhra Pradesh',
      beneficiaries: 'Landholder farmers and recognized tenant farmers (CCRC holders) in AP',
      description: 'Farmer database registration integrating Webland land records, e-Crop booking, and DBT agricultural support for input subsidies, crop insurance, and minimum support price (MSP).',
      eligibility: [
        'Cultivator owning agricultural land in Andhra Pradesh registered in Webland database',
        'Or tenant farmer holding Crop Cultivator Rights Card (CCRC) for the current agricultural season'
      ],
      benefits: [
        'Direct cash assistance under agricultural investment schemes',
        'Free crop insurance (Dr. YSR Free Crop Insurance) upon seasonal e-Crop booking',
        'Access to subsidized seeds, fertilizers, and zero-interest crop loans',
        'Government procurement at Minimum Support Price (MSP) through Rythu Bharosa Kendras (RBKs)'
      ],
      documents: [
        'Pattadar Passbook / 1B Namoona land record',
        'CCRC agreement (for tenant farmers)',
        'Aadhaar Card of the farmer',
        'Aadhaar-seeded bank account passbook copy',
        'Survey number and crop sowing details'
      ],
      steps: [
        'Visit your village Rythu Bharosa Kendra (RBK) or Grama Sachivalayam Agriculture Assistant.',
        'Ensure your survey numbers and land details match the Webland portal.',
        'Complete mandatory e-Crop physical verification booking during crop season.',
        'Authenticate biometrics (e-KYC) at RBK.',
        'Receive official e-Crop receipt and track DBT subsidy status.'
      ],
      officialUrl: 'https://apagrisnet.gov.in/',
      sourceUrl: 'https://onlineap.meeseva.gov.in/',
      verified: true,
      verificationStatus: 'Official AP Agriculture Department'
    },
    {
      id: 'pm-kisan',
      name: 'PM-KISAN (Pradhan Mantri Kisan Samman Nidhi)',
      category: 'Agriculture and Farmers',
      state: 'Central / All India',
      beneficiaries: 'Small and marginal landholding farmer families across India',
      description: 'Central sector welfare scheme providing income support to all landholding farmer families with cultivable land, subject to exclusion criteria.',
      eligibility: [
        'Farmer family with cultivable landholding in their name as per state revenue records',
        'Exclusions: Institutional landholders, constitutional post holders, serving/retired government employees, income tax payees, and professionals'
      ],
      benefits: [
        'Financial benefit of ₹6,000 per year transferred in three equal instalments of ₹2,000 every 4 months',
        'Transferred directly via Aadhaar-based DBT payment into farmer’s bank account'
      ],
      documents: [
        'Aadhaar Card linked with active mobile number',
        'Landownership proof (Pattadar Passbook / RoR / Khatauni)',
        'Bank account details (IFSC code, Aadhaar-seeded account)'
      ],
      steps: [
        'Visit official PM-KISAN portal (pmkisan.gov.in) -> Farmers Corner -> New Farmer Registration.',
        'Enter Aadhaar number and state; fill rural/urban farmer details.',
        'Upload land records and bank details.',
        'State government revenue officials verify land records.',
        'Complete mandatory OTP / biometric e-KYC on the portal.'
      ],
      officialUrl: 'https://pmkisan.gov.in/',
      sourceUrl: 'https://pmkisan.gov.in/',
      verified: true,
      verificationStatus: 'Verified with Ministry of Agriculture'
    },
    {
      id: 'ayushman-bharat-pmjay',
      name: 'Ayushman Bharat PM-JAY & State Health Protection',
      category: 'Healthcare',
      state: 'Central / All India',
      beneficiaries: 'Low-income and vulnerable families identified via SECC database and state Rice Card schemes',
      description: 'World’s largest government-funded health assurance scheme offering cashless secondary and tertiary hospitalization in empaneled public and private hospitals.',
      eligibility: [
        'Families listed in Socio-Economic Caste Census (SECC 2011) or possessing valid State Rice Card',
        'In Andhra Pradesh, integrated seamlessly with Dr. YSR Aarogyasri Trust coverage'
      ],
      benefits: [
        'Health cover of ₹5,00,000 per family per year for secondary and tertiary healthcare',
        'Cashless access to over 1,900 medical procedures and hospital stays',
        'Includes pre-hospitalization (3 days) and post-hospitalization (15 days) medicine costs'
      ],
      documents: [
        'Aadhaar Card of the patient / family member',
        'Ration Card / Rice Card',
        'Active mobile number for verification at hospital Aarogya Mitra kiosk'
      ],
      steps: [
        'Visit beneficiary.nha.gov.in or contact the Aarogya Mitra desk at any empaneled hospital.',
        'Check family name in eligible list using Aadhaar or Ration Card number.',
        'Complete biometric or OTP e-KYC to generate Ayushman / Aarogyasri card.',
        'Avail completely cashless treatment at any empaneled government or private hospital nationwide.'
      ],
      officialUrl: 'https://beneficiary.nha.gov.in/',
      sourceUrl: 'https://nha.gov.in/',
      verified: true,
      verificationStatus: 'Verified with National Health Authority'
    },
    {
      id: 'eshram-card',
      name: 'e-Shram Portal for Unorganized Workers',
      category: 'Employment and Skills',
      state: 'Central / All India',
      beneficiaries: 'Unorganized workers aged 16-59 (agricultural workers, street vendors, domestic workers, gig workers)',
      description: 'National database of unorganized workers offering a 12-digit Universal Account Number (UAN) card for seamless delivery of social security schemes and disaster relief benefits.',
      eligibility: [
        'Age between 16 to 59 years',
        'Working in unorganized sector (agriculture, construction, street vending, domestic help, transport, etc.)',
        'Must not be a member of EPFO (PF) or ESIC, and not an income tax payee'
      ],
      benefits: [
        'Unique 12-digit e-Shram UAN Card valid nationwide',
        'Accidental insurance cover (PMSBY) of ₹2 Lakh in case of death or permanent disability',
        'Priority access to future social security benefits, skill development, and emergency DBT relief'
      ],
      documents: [
        'Aadhaar Card linked to active mobile number',
        'Aadhaar-seeded active Bank Account details',
        'Occupation and skill details'
      ],
      steps: [
        'Visit eshram.gov.in or nearest CSC / Grama Sachivalayam centre.',
        'Click "Register on e-Shram" and authenticate with Aadhaar OTP.',
        'Fill occupation, educational qualification, and bank account details.',
        'Download the UAN card instantly. Registration is completely free of charge.'
      ],
      officialUrl: 'https://eshram.gov.in/',
      sourceUrl: 'https://labour.gov.in/',
      verified: true,
      verificationStatus: 'Verified with Ministry of Labour & Employment'
    },
    {
      id: 'pm-awas-yojana',
      name: 'Pradhan Mantri Awas Yojana (PMAY - Gramin & Urban)',
      category: 'Housing',
      state: 'Central / All India',
      beneficiaries: 'Homeless families and those living in kutcha/dilapidated houses',
      description: 'Flagship housing mission aimed at providing pukka houses with basic amenities (electricity, LPG, water, toilet) to all eligible rural and urban families.',
      eligibility: [
        'Family must not own a pucca house in their name or any family member’s name anywhere in India',
        'Rural: Selected based on SECC 2011 deprivation criteria & Awaas+ survey list',
        'Urban: Economically Weaker Section (EWS) or Low Income Group (LIG) criteria'
      ],
      benefits: [
        'Gramin: Financial assistance of ₹1,20,000 (plains) to ₹1,30,000 (hilly states) released in DBT instalments',
        'Additional 90-95 person-days of unskilled labor support under MGNREGS (approx. ₹20,000+)',
        'Urban: Credit Linked Subsidy Scheme (CLSS) interest subsidy up to ₹2.67 Lakh'
      ],
      documents: [
        'Aadhaar Card of applicant and spouse',
        'Bank Account Passbook with IFSC code',
        'MGNREGA Job Card number (for PMAY-G)',
        'Land / site ownership certificate or patta',
        'Consent letter and photo of the existing site'
      ],
      steps: [
        'Rural: Contact Gram Panchayat Secretary / Grama Sachivalayam to verify name in Awaas+ list.',
        'Urban: Apply online through pmaymis.gov.in or municipal civic center.',
        'Physical geo-tagging of site is conducted by officials at foundation, lintel, and roof stages.',
        'Instalments are credited directly to bank account based on geo-tagged photo verification.'
      ],
      officialUrl: 'https://pmayg.nic.in/',
      sourceUrl: 'https://pmaymis.gov.in/',
      verified: true,
      verificationStatus: 'Verified with Ministry of Rural Development'
    },
    {
      id: 'sukanya-samriddhi',
      name: 'Sukanya Samriddhi Yojana (SSY)',
      category: 'Women and Child Welfare',
      state: 'Central / All India',
      beneficiaries: 'Girl children below 10 years of age through parents or legal guardians',
      description: 'Government-backed savings scheme for girl child under Beti Bachao Beti Padhao campaign offering highest sovereign interest rates, tax benefits, and financial security for education and marriage.',
      eligibility: [
        'Account can be opened by biological parents or legal guardians for a girl child aged under 10 years',
        'Maximum 2 accounts per family (allowed for twins/triplets with legal affidavit)'
      ],
      benefits: [
        'High sovereign interest rate (currently 8.2% p.a., compounded annually)',
        'Triple Tax Benefit (EEE): Investment tax deduction under 80C, tax-free interest, and tax-free maturity',
        '50% partial withdrawal allowed for higher education once the girl reaches 18 years of age',
        'Account matures after 21 years from the date of opening or on marriage after 18'
      ],
      documents: [
        'Birth Certificate of the girl child',
        'Identity and Address proof of parent/guardian (Aadhaar / Voter ID / Passport)',
        'Passport size photograph of child and parent',
        'Initial deposit (minimum ₹250)'
      ],
      steps: [
        'Visit any Post Office branch or authorized public/private commercial bank.',
        'Submit Form-1 (SSY Account Opening Form) with birth certificate and guardian KYC.',
        'Deposit opening amount (minimum ₹250, maximum ₹1,50,000 per financial year).',
        'Collect SSY Passbook to track deposits and yearly compounded interest.'
      ],
      officialUrl: 'https://www.indiapost.gov.in/',
      sourceUrl: 'https://financialservices.gov.in/',
      verified: true,
      verificationStatus: 'Verified with Department of Posts'
    },
    {
      id: 'atal-pension-yojana',
      name: 'Atal Pension Yojana (APY)',
      category: 'Senior Citizens',
      state: 'Central / All India',
      beneficiaries: 'Citizens in unorganized sector aged 18 to 40 years',
      description: 'Guaranteed government pension scheme administered by PFRDA offering monthly pension of ₹1,000 to ₹5,000 after attaining 60 years of age.',
      eligibility: [
        'Indian citizen aged between 18 and 40 years',
        'Must possess active savings bank account linked to Aadhaar',
        'Applicant must not be an income tax payer (as per updated guidelines)'
      ],
      benefits: [
        'Guaranteed monthly pension (choices: ₹1,000, ₹2,000, ₹3,000, ₹4,000, or ₹5,000) for life from age 60',
        'Same monthly pension continues to spouse upon demise of subscriber',
        'Nominee receives full accumulated pension corpus upon demise of both subscriber and spouse'
      ],
      documents: [
        'Aadhaar Card',
        'Active Bank Account passbook with auto-debit consent',
        'Active Mobile Number for PRAN SMS alerts'
      ],
      steps: [
        'Approach the bank where you hold your primary savings account or use mobile banking app.',
        'Fill APY registration form and choose desired monthly pension tier.',
        'Authorize monthly auto-debit for contribution based on your entry age.',
        'Receive Permanent Retirement Account Number (PRAN) confirmation slip.'
      ],
      officialUrl: 'https://www.npscra.nsdl.co.in/',
      sourceUrl: 'https://pfrda.org.in/',
      verified: true,
      verificationStatus: 'Verified with PFRDA'
    },
    {
      id: 'pm-svanidhi',
      name: 'PM SVANidhi (Micro-Credit for Street Vendors)',
      category: 'Entrepreneurship',
      state: 'Central / All India',
      beneficiaries: 'Urban, peri-urban, and rural street vendors vending in urban areas',
      description: 'Affordable working capital collateral-free credit scheme for street vendors to resume livelihoods, incentivizing digital transactions and timely repayments.',
      eligibility: [
        'Street vendors possessing Certificate of Vending / Identity Card issued by Urban Local Body (ULB)',
        'Or vendors identified in survey or holding Letter of Recommendation (LoR) from Town Vending Committee'
      ],
      benefits: [
        'Initial collateral-free working capital loan up to ₹10,000 (1st tranche)',
        'Upon timely repayment, enhanced loan up to ₹20,000 (2nd tranche) and up to ₹50,000 (3rd tranche)',
        '7% interest subsidy credited directly to bank account on timely monthly repayments',
        'Cashback up to ₹100 per month on conducting digital payment transactions'
      ],
      documents: [
        'Aadhaar Card linked to mobile number',
        'Vending Certificate / Vending ID / LoR issued by ULB/Municipality',
        'Bank account details and QR code merchant ID'
      ],
      steps: [
        'Visit pmsvanidhi.mohua.gov.in or use PM SVANidhi Mobile App.',
        'Check mobile number linked to Aadhaar and enter Vending ID or ULB details.',
        'Select preferred lending institution / bank.',
        'Submit application online; ULB and bank review the loan sanction within 1-2 weeks.'
      ],
      officialUrl: 'https://pmsvanidhi.mohua.gov.in/',
      sourceUrl: 'https://mohua.gov.in/',
      verified: true,
      verificationStatus: 'Verified with Ministry of Housing & Urban Affairs'
    },
    {
      id: 'udid-disability',
      name: 'Unique Disability ID (UDID) & Disability Certificate',
      category: 'Social Security',
      state: 'Central / All India',
      beneficiaries: 'Persons with Disabilities (PwDs) under the RPwD Act 2016',
      description: 'Single national identification card for persons with disabilities, eliminating the need to carry physical hospital certificates for state and central travel and social welfare concessions.',
      eligibility: [
        'Person assessed with 40% or more disability by an authorized medical board/hospital authority'
      ],
      benefits: [
        'National acceptance across all central and state welfare departments and railways',
        'Rail and bus travel concessions, disability pensions, and aids/appliances under ADIP scheme',
        'Job reservations and higher education reservation quotas'
      ],
      documents: [
        'Color passport photograph',
        'Identity proof (Aadhaar Card / Voter ID)',
        'Address proof',
        'Hospital medical records / diagnosis history if previously evaluated'
      ],
      steps: [
        'Register online on the UDID portal (swavlambancard.gov.in).',
        'Fill personal details, disability type, and upload required documents.',
        'Book or receive appointment date for assessment at designated District Hospital Medical Board.',
        'Attend medical examination; Medical Superintendent issues digital certification.',
        'Track application status online; download e-UDID card and receive plastic card via speed post.'
      ],
      officialUrl: 'https://www.swavlambancard.gov.in/',
      sourceUrl: 'https://disabilityaffairs.gov.in/',
      verified: true,
      verificationStatus: 'Official Department of Empowerment of PwDs'
    },
    {
      id: 'voter-id-form6',
      name: 'Voter Registration / EPIC Voter ID (Form 6)',
      category: 'Social Security',
      state: 'Central / All India',
      beneficiaries: 'Indian citizens aged 18 years or older on qualifying dates',
      description: 'Official enrolment in electoral roll and issuance of Electors Photo Identity Card (EPIC) by the Election Commission of India.',
      eligibility: [
        'Citizen of India',
        'Attained 18 years of age on the qualifying dates (1st Jan, 1st April, 1st July, 1st October)',
        'Ordinary resident of the polling area where registration is sought'
      ],
      benefits: [
        'Constitutional right to cast vote in Parliamentary, Assembly, and Local Body elections',
        'Official government proof of identity, citizenship, and residential address nationwide'
      ],
      documents: [
        'Passport size color photograph with plain background',
        'Age proof (Birth Certificate, Aadhaar, PAN, Driving Licence, or Class 10 Certificate)',
        'Ordinary residence address proof (Electricity bill, Aadhaar, Gas bill, Water bill, or Bank passbook)'
      ],
      steps: [
        'Visit official Election Commission Voters Service Portal (voters.eci.gov.in).',
        'Sign up using mobile number and select "New registration for general electors (Form 6)".',
        'Enter assembly constituency, personal details, and upload photo and address proofs.',
        'Submit application and save the unique 16-digit Reference Number.',
        'Booth Level Officer (BLO) performs field verification; download digital e-EPIC once approved.'
      ],
      officialUrl: 'https://voters.eci.gov.in/',
      sourceUrl: 'https://eci.gov.in/',
      verified: true,
      verificationStatus: 'Official Election Commission of India Portal'
    },
    {
      id: 'driving-licence-sarathi',
      name: 'Learner & Driving Licence (Parivahan Sarathi)',
      category: 'Social Security',
      state: 'Central / All India',
      beneficiaries: 'Citizens meeting vehicle class age requirements (16 for gearless 50cc, 18 for LMV, 20 for transport)',
      description: 'Standardized national issuance of Learner’s Licence and permanent Driving Licence through the Ministry of Road Transport and Highways Parivahan Sarathi portal.',
      eligibility: [
        'Minimum age: 18 years for private cars (LMV) and motorcycles with gear; 16 years for gearless 50cc',
        'Pass online computer test for Learner’s Licence, followed by practical driving skill test at RTO'
      ],
      benefits: [
        'Legal authorization to drive vehicles across all Indian states and Union Territories',
        'Digital Smart Card Driving Licence stored in DigiLocker / mParivahan recognized by traffic police'
      ],
      documents: [
        'Age proof (Aadhaar, Birth Certificate, SSC Memo, or Passport)',
        'Address proof (Aadhaar, Voter ID, Electricity bill, or Passport)',
        'Form 1 physical fitness declaration (Form 1A medical certificate for applicants over 40 years or transport class)',
        'Passport size photographs and digital signature'
      ],
      steps: [
        'Open Parivahan portal (parivahan.gov.in) -> Drivers/Learners License -> Select Andhra Pradesh (or your state).',
        'Apply for Learner Licence (LL); upload proofs and book slot for online or RTO theory test.',
        'After qualifying LL (valid for 6 months), apply for permanent Driving Licence after 30 days.',
        'Pay fee and book slot for practical driving track test at RTO.',
        'Attend driving test with authorized vehicle; licence dispatched via registered post.'
      ],
      officialUrl: 'https://parivahan.gov.in/',
      sourceUrl: 'https://sarathi.parivahan.gov.in/',
      verified: true,
      verificationStatus: 'Official MoRTH Parivahan Portal'
    },
    {
      id: 'passport-seva',
      name: 'Passport Seva (Fresh & Reissue Application)',
      category: 'Social Security',
      state: 'Central / All India',
      beneficiaries: 'Indian citizens applying for fresh passport or renewal/reissue',
      description: 'Official travel document issuance by the Ministry of External Affairs through Passport Seva Kendras (PSK) and Post Office PSKs (POPSK).',
      eligibility: [
        'Indian citizen by birth, descent, or naturalization with no pending court disqualifications'
      ],
      benefits: [
        'Primary international travel document and sovereign proof of Indian nationality',
        'Widely accepted tier-1 identity and address proof worldwide'
      ],
      documents: [
        'Proof of Date of Birth (Birth Certificate, Aadhaar, PAN, School Leaving Certificate)',
        'Proof of Present Address (Aadhaar, Bank passbook with photo, Water/Electricity bill, Voter ID)',
        'Educational document (10th pass memo or higher for Non-ECR status)'
      ],
      steps: [
        'Register on official portal (passportindia.gov.in) and click "Apply for Fresh Passport/Reissue".',
        'Fill online application form matching school and Aadhaar records.',
        'Pay official government fee online and schedule appointment at nearest PSK / POPSK.',
        'Visit Kendra with original documents and photocopies for biometric enrolment and document scrutiny.',
        'Police verification is conducted; passport dispatched by India Post Speed Post.'
      ],
      officialUrl: 'https://www.passportindia.gov.in/',
      sourceUrl: 'https://mea.gov.in/',
      verified: true,
      verificationStatus: 'Official Ministry of External Affairs Portal'
    },
    {
      id: 'pan-card',
      name: 'PAN Card (Permanent Account Number)',
      category: 'Social Security',
      state: 'Central / All India',
      beneficiaries: 'Taxpayers, individuals, minors (through guardians), and businesses',
      description: '10-character alphanumeric identifier issued by the Income Tax Department via authorized service providers (Protean / UTIITSL) for financial and banking transactions.',
      eligibility: [
        'Any individual or business entity in India or NRIs conducting financial transactions'
      ],
      benefits: [
        'Mandatory for opening bank accounts, high-value transactions, and filing income tax returns',
        'Standardized national proof of identity'
      ],
      documents: [
        'Proof of Identity (Aadhaar Card, Voter ID, Passport, or Driving Licence)',
        'Proof of Address (Aadhaar, Electricity bill, Bank statement, or Passport)',
        'Proof of Date of Birth (Aadhaar, Birth Certificate, Class 10 Memo)'
      ],
      steps: [
        'Navigate from official Income Tax Department portal (incometax.gov.in) to authorized PAN application.',
        'Choose Form 49A (for Indian citizens) and submit applicant demographic details.',
        'For instant paperless e-PAN, use Aadhaar e-KYC route on incometax.gov.in (free of cost).',
        'Pay standard fee for physical card dispatch.',
        'Save 15-digit acknowledgement number to track delivery status.'
      ],
      officialUrl: 'https://www.incometax.gov.in/',
      sourceUrl: 'https://tin.tin.nsdl.com/',
      verified: true,
      verificationStatus: 'Official Income Tax Department Service'
    }
  ];

  const PUBLIC_SERVICES_DATA = [
    {
      id: 'srv-meeseva',
      name: 'AP MeeSeva Citizen Portal',
      category: 'Certificates and Registrations',
      audience: 'Citizens of Andhra Pradesh',
      description: 'Flagship electronic governance portal delivering 300+ government-to-citizen services including revenue certificates, birth certificates, and land records.',
      url: 'https://onlineap.meeseva.gov.in/',
      verified: true,
      department: 'ITE&C Department, Govt of AP'
    },
    {
      id: 'srv-vsws',
      name: 'AP Seva / Grama & Ward Sachivalayam Portal',
      category: 'Certificates and Registrations',
      audience: 'Rural and Urban citizens of AP',
      description: 'Hyper-local citizen service delivery mechanism connecting 15,000+ village and ward secretariats across Andhra Pradesh for welfare delivery and grievance logging.',
      url: 'https://vsws.ap.gov.in/',
      verified: true,
      department: 'Grama Ward Sachivalayam Dept, AP'
    },
    {
      id: 'srv-uidai',
      name: 'UIDAI — My Aadhaar Portal',
      category: 'Certificates and Registrations',
      audience: 'All Indian Residents',
      description: 'Official self-service portal for downloading e-Aadhaar, checking Aadhaar-Bank link status, ordering PVC cards, and locating authorized enrolment centers.',
      url: 'https://myaadhaar.uidai.gov.in/',
      verified: true,
      department: 'Unique Identification Authority of India'
    },
    {
      id: 'srv-nsp',
      name: 'National Scholarship Portal (NSP)',
      category: 'Education',
      audience: 'Pre-matric and Post-matric students across India',
      description: 'Common electronic portal by Ministry of Electronics & IT facilitating scholarship schemes from central ministries, UGC, and state departments.',
      url: 'https://scholarships.gov.in/',
      verified: true,
      department: 'Ministry of Electronics & Information Technology'
    },
    {
      id: 'srv-jnanabhumi',
      name: 'AP Jnanabhumi Portal',
      category: 'Education',
      audience: 'Post-matric and intermediate students in Andhra Pradesh',
      description: 'Integrated education ecosystem for student scholarships, admissions, fee reimbursements (Vidya Deevena & Vasathi Deevena), and college monitoring in AP.',
      url: 'https://jnanabhumi.ap.gov.in/',
      verified: true,
      department: 'Social Welfare Department, Govt of AP'
    },
    {
      id: 'srv-bse-ap',
      name: 'Directorate of Government Examinations (BSE AP)',
      category: 'Education',
      audience: 'School students, SSC candidates, NMMS applicants',
      description: 'Official board responsible for conducting SSC Board examinations, National Means-cum-Merit Scholarship (NMMS), and state education evaluations.',
      url: 'https://bse.ap.gov.in/',
      verified: true,
      department: 'School Education Department, Govt of AP'
    },
    {
      id: 'srv-parivahan',
      name: 'Parivahan Sarathi & Vahan Services',
      category: 'Utility Services',
      audience: 'Vehicle owners, drivers, and license applicants',
      description: 'Central portal for driving licence application, learner licence slot booking, vehicle registration renewals, and high security registration plate services.',
      url: 'https://parivahan.gov.in/',
      verified: true,
      department: 'Ministry of Road Transport and Highways'
    },
    {
      id: 'srv-passport',
      name: 'Passport Seva Portal',
      category: 'Certificates and Registrations',
      audience: 'Indian citizens travelling abroad',
      description: 'Official centralized service for fresh passport appointments, reissue, tatkaal services, and Police Clearance Certificate (PCC) applications.',
      url: 'https://www.passportindia.gov.in/',
      verified: true,
      department: 'Ministry of External Affairs, Govt of India'
    },
    {
      id: 'srv-voters',
      name: 'ECI Voters’ Services Portal',
      category: 'Social Welfare',
      audience: 'Indian Citizens aged 18 and older',
      description: 'Comprehensive portal for new voter registration (Form 6), constituency shifting (Form 8), tracking EPIC card dispatch, and searching electoral roll.',
      url: 'https://voters.eci.gov.in/',
      verified: true,
      department: 'Election Commission of India'
    },
    {
      id: 'srv-udid',
      name: 'Unique Disability ID (UDID) Portal',
      category: 'Healthcare',
      audience: 'Persons with Disabilities (PwDs)',
      description: 'National portal for online registration of disability, assessment slot booking at district hospitals, and issuance of permanent UDID cards.',
      url: 'https://www.swavlambancard.gov.in/',
      verified: true,
      department: 'DEPwD, Ministry of Social Justice'
    },
    {
      id: 'srv-incometax',
      name: 'Income Tax Department e-Filing & PAN Portal',
      category: 'Utility Services',
      audience: 'Taxpayers, individuals, and salaried workers',
      description: 'National portal for Instant e-PAN generation via Aadhaar e-KYC, income tax return filing, tax refund tracking, and Aadhaar-PAN linking.',
      url: 'https://www.incometax.gov.in/',
      verified: true,
      department: 'Central Board of Direct Taxes, MoF'
    },
    {
      id: 'srv-spandana',
      name: 'AP Spandana Citizen Grievance Portal',
      category: 'Citizen Grievances',
      audience: 'Citizens of Andhra Pradesh',
      description: 'State government grievance redressal platform enabling citizens to register complaints, track resolution timelines, and receive SMS updates.',
      url: 'https://www.spandana.ap.gov.in/',
      verified: true,
      department: 'Government of Andhra Pradesh'
    }
  ];

  /* ==========================================================================
     2. MULTI-LANGUAGE DICTIONARY (EN, TE, HI)
     ========================================================================== */

  const I18N = {
    en: {
      siteTitle: 'JanSetu — Government Services, Within Everyone’s Reach',
      portalNotice: 'Non-official civic technology prototype. Always verify on official .gov.in portals.',
      navHome: 'Home',
      navSchemes: 'Explore Schemes',
      navServices: 'Services Directory',
      navApGuide: 'AP Certificates Guide',
      navFinder: 'Smart Scheme Finder',
      navDashboard: 'My Dashboard',
      navLogin: 'Demo Login',
      heroTitle: 'Government Services, Within Everyone’s Reach.',
      heroSub: 'Discover schemes you qualify for, prepare the exact documents needed, and access official central & Andhra Pradesh government portals safely.',
      searchPlaceholder: 'Search schemes by keyword (e.g., NMMS, Caste, Rice Card, PM-KISAN)...',
      btnSearch: 'Search',
      btnFindSchemes: 'Find My Schemes',
      btnExploreSchemes: 'Explore All Schemes',
      btnExploreServices: 'Explore Services',
      btnApGuide: 'AP Certificates Guide',
      statSchemes: 'Flagship Schemes & Certificates',
      statPortals: 'Verified Official Portals',
      statStates: 'AP & Central Coverage',
      statCost: 'Always 100% Free Info',
      popularSchemesTitle: 'Popular Government Schemes & Certificates',
      popularSchemesSub: 'Find essential services, eligibility criteria, and step-by-step guidance.',
      howItWorksTitle: 'How JanSetu Works',
      howItWorksSub: 'Four simple steps to navigate public benefits without middlemen or confusion.',
      step1Title: '1. Discover & Search',
      step1Desc: 'Search by category, occupation, or your specific state benefit.',
      step2Title: '2. Check Eligibility',
      step2Desc: 'Review realistic income limits, age rules, and intended beneficiary criteria.',
      step3Title: '3. Prepare Documents',
      step3Desc: 'Check off verified documents and keep photocopies ready before visiting offices.',
      step4Title: '4. Apply Officially',
      step4Desc: 'Jump straight to genuine official portals or your local Grama/Ward Sachivalayam.',
      safetyTitle: 'Citizen Safety & Precautions Checklist',
      safetySub: 'Critical precautions before submitting applications at MeeSeva or online portals.',
      rule1Title: 'Keep Originals & Photocopies',
      rule1Desc: 'Offices may ask to inspect originals and retain 2-3 attested photocopies. Never leave originals without receipt.',
      rule2Title: 'Use Authorised Portals Only',
      rule2Desc: 'Apply strictly via official .gov.in websites or authorized Grama/Ward Sachivalayam / MeeSeva centres.',
      rule3Title: 'Verify Spellings Before Submit',
      rule3Desc: 'Check spelling of name, parents’ names, DOB, address, and bank IFSC code against Aadhaar before submitting.',
      rule4Title: 'Never Share OTPs or Passwords',
      rule4Desc: 'Never give anyone your OTP, password, ATM PIN or bank login. Do not pay anyone promising guaranteed approval.',
      filterAll: 'All Categories',
      filterBeneficiary: 'All Beneficiaries',
      viewDetails: 'View Details',
      saveScheme: 'Save',
      savedScheme: 'Saved',
      listenAudio: 'Listen',
      playingAudio: 'Playing...',
      noResults: 'No schemes found matching your search criteria. Try clearing filters or searching for general terms.',
      clearFilters: 'Clear Filters'
    },
    te: {
      siteTitle: 'జన్ సేతు — ప్రభుత్వ సేవలు, అందరికీ అందుబాటులో',
      portalNotice: 'అనధికారిక పౌర సాంకేతిక ప్రాజెక్ట్. అధికారిక .gov.in పోర్టల్‌లలో సరిచూడండి.',
      navHome: 'హోమ్',
      navSchemes: 'పథకాలు అన్వేషించండి',
      navServices: 'సేవల డైరెక్టరీ',
      navApGuide: 'ఏపీ సర్టిఫికేట్ల గైడ్',
      navFinder: 'స్మార్ట్ స్కీమ్ ఫైండర్',
      navDashboard: 'నా డాష్‌బోర్డ్',
      navLogin: 'డెమో లాగిన్',
      heroTitle: 'ప్రభుత్వ సేవలు, అందరికీ అందుబాటులో.',
      heroSub: 'మీకు అర్హత ఉన్న పథకాలను కనుగొనండి, అవసరమైన పత్రాలను సిద్ధం చేసుకోండి మరియు అధికారిక పోర్టల్‌లను సురక్షితంగా ఉపయోగించండి.',
      searchPlaceholder: 'పథకాల కోసం వెతకండి (ఉదా: ఎన్ఎమ్ఎమ్ఎస్, కుల ధ్రువీకరణ, బియ్యం కార్డు, పీఎం కిసాన్)...',
      btnSearch: 'వెతకండి',
      btnFindSchemes: 'నా పథకాలు కనుగొనండి',
      btnExploreSchemes: 'అన్ని పథకాలు చూడండి',
      btnExploreServices: 'సేవలు చూడండి',
      btnApGuide: 'ఏపీ సర్టిఫికేట్ల గైడ్',
      statSchemes: 'ప్రధాన పథకాలు & ధ్రువపత్రాలు',
      statPortals: 'పరిశీలించిన అధికారిక పోర్టల్స్',
      statStates: 'ఆంధ్రప్రదేశ్ & కేంద్ర పథకాలు',
      statCost: 'పూర్తిగా ఉచిత సమాచారం',
      popularSchemesTitle: 'ప్రసిద్ధ ప్రభుత్వ పథకాలు & సర్టిఫికేట్లు',
      popularSchemesSub: 'ముఖ్యమైన సేవలు, అర్హత నిబంధనలు మరియు దశలవారీ మార్గదర్శకాలను పొందండి.',
      howItWorksTitle: 'జన్ సేతు ఎలా పనిచేస్తుంది',
      howItWorksSub: 'దళారులు లేకుండా నాలుగు సులభమైన దశల్లో ప్రభుత్వ ప్రయోజనాలను పొందండి.',
      step1Title: '1. శోధించండి',
      step1Desc: 'మీ వర్గం, వృత్తి లేదా రాష్ట్రం ఆధారంగా పథకాలను కనుగొనండి.',
      step2Title: '2. అర్హతను పరిశీలించండి',
      step2Desc: 'ఆదాయ పరిమితులు, వయస్సు నియమాలు మరియు లబ్ధిదారుల నిబంధనలను తనిఖీ చేయండి.',
      step3Title: '3. పత్రాలు సిద్ధం చేయండి',
      step3Desc: 'కార్యాలయాలకు వెళ్లేముందు అవసరమైన పత్రాల జిరాక్స్ కాపీలను సరిచూసుకోండి.',
      step4Title: '4. అధికారికంగా దరఖాస్తు చేయండి',
      step4Desc: 'అధికారిక వెబ్‌సైట్ లేదా మీ గ్రామ/వార్డు సచివాలయం, మీసేవ ద్వారా దరఖాస్తు చేసుకోండి.',
      safetyTitle: 'పౌరుల భద్రత & జాగ్రత్తల జాబితా',
      safetySub: 'మీసేవ లేదా ఆన్‌లైన్ పోర్టల్‌లలో దరఖాస్తు సమర్పించే ముందు పాటించాల్సిన సూచనలు.',
      rule1Title: 'ఒరిజినల్స్ & జిరాక్స్ సిద్ధం చేసుకోండి',
      rule1Desc: 'కార్యాలయాల్లో ఒరిజినల్స్ చూపించి జిరాక్స్ ఇవ్వాల్సి ఉంటుంది. రశీదు లేకుండా ఒరిజినల్స్ ఎక్కడా ఇవ్వకండి.',
      rule2Title: 'అధికారిక కేంద్రాలనే వాడండి',
      rule2Desc: 'అధికారిక .gov.in సైట్‌లు లేదా గుర్తింపు పొందిన మీసేవ/సచివాలయాలలో మాత్రమే సేవలు పొందండి.',
      rule3Title: 'స్పెల్లింగ్‌లు సరిచూసుకోండి',
      rule3Desc: 'సమర్పించే ముందు మీ పేరు, తల్లిదండ్రుల పేర్లు, పుట్టిన తేదీ మరియు బ్యాంక్ వివరాలను సరిచూసుకోండి.',
      rule4Title: 'ఓటీపీలను ఎవరికీ చెప్పకండి',
      rule4Desc: 'మీ ఓటీపీ, పాస్‌వర్డ్, ఏటీఎం పిన్ వివరాలను ఎవరికీ ఇవ్వకండి. గ్యారెంటీ అప్రూవల్ పేరుతో ఎవరికీ డబ్బులు చెల్లించకండి.',
      filterAll: 'అన్ని విభాగాలు',
      filterBeneficiary: 'అన్ని లబ్ధిదారు వర్గాలు',
      viewDetails: 'వివరాలు చూడండి',
      saveScheme: 'సేవ్ చేయండి',
      savedScheme: 'సేవ్ అయింది',
      listenAudio: 'వినండి',
      playingAudio: 'వినిపిస్తోంది...',
      noResults: 'మీ శోధనకు తగిన పథకాలు కనిపించలేదు. ఫిల్టర్లను తొలగించి మళ్లీ ప్రయత్నించండి.',
      clearFilters: 'ఫిల్టర్లు క్లియర్ చేయండి'
    },
    hi: {
      siteTitle: 'जनसेतु — सरकारी सेवाएं, सबकी पहुंच में',
      portalNotice: 'गैर-सरकारी नागरिक तकनीकी प्रोटोटाइप। हमेशा आधिकारिक .gov.in पोर्टल्स पर पुष्टि करें।',
      navHome: 'होम',
      navSchemes: 'योजनाएं खोजें',
      navServices: 'सेवा निर्देशिका',
      navApGuide: 'आंध्र प्रदेश प्रमाण पत्र गाइड',
      navFinder: 'स्मार्ट स्कीम खोजक',
      navDashboard: 'मेरा डैशबोर्ड',
      navLogin: 'डेमो लॉगिन',
      heroTitle: 'सरकारी सेवाएं, सबकी पहुंच में।',
      heroSub: 'अपनी पात्रता वाली योजनाएं खोजें, आवश्यक दस्तावेज तैयार करें, और सुरक्षित रूप से आधिकारिक सरकारी पोर्टल्स का उपयोग करें।',
      searchPlaceholder: 'योजनाएं खोजें (जैसे: छात्रवृत्ति, जाति प्रमाण पत्र, राशन कार्ड, पीएम किसान)...',
      btnSearch: 'खोजें',
      btnFindSchemes: 'मेरी योजनाएं खोजें',
      btnExploreSchemes: 'सभी योजनाएं देखें',
      btnExploreServices: 'सरकारी सेवाएं देखें',
      btnApGuide: 'एपी प्रमाण पत्र गाइड',
      statSchemes: 'प्रमुख योजनाएं व प्रमाण पत्र',
      statPortals: 'सत्यापित आधिकारिक पोर्टल्स',
      statStates: 'एपी व केंद्रीय कवरेज',
      statCost: 'हमेशा 100% मुफ्त जानकारी',
      popularSchemesTitle: 'लोकप्रिय सरकारी योजनाएं व प्रमाण पत्र',
      popularSchemesSub: 'आवश्यक सेवाएं, पात्रता शर्तें और चरणबद्ध मार्गदर्शन प्राप्त करें।',
      howItWorksTitle: 'जनसेतु कैसे काम करता है',
      howItWorksSub: 'बिना बिचौलियों के चार सरल चरणों में सरकारी लाभों तक पहुंचें।',
      step1Title: '1. खोजें व चुनें',
      step1Desc: 'अपनी श्रेणी, व्यवसाय या राज्य के आधार पर योजनाएं खोजें।',
      step2Title: '2. पात्रता जांचें',
      step2Desc: 'आय सीमा, आयु सीमा और लाभार्थी नियमों की पुष्टि करें।',
      step3Title: '3. दस्तावेज तैयार करें',
      step3Desc: 'आवश्यक दस्तावेजों की सूची जांचें और फोटोकॉपी तैयार रखें।',
      step4Title: '4. आधिकारिक आवेदन करें',
      step4Desc: 'सत्यापित आधिकारिक वेबसाइट या अपने नजदीकी ग्राम/वार्ड सचिवालय जाएं।',
      safetyTitle: 'नागरिक सुरक्षा और सावधानियां',
      safetySub: 'मीसेवा या ऑनलाइन पोर्टल पर आवेदन करने से पहले आवश्यक सावधानियां।',
      rule1Title: 'मूल प्रतियां और फोटोकॉपी रखें',
      rule1Desc: 'कार्यालय मूल प्रतियां देख सकते हैं और फोटोकॉपी जमा करेंगे। रसीद के बिना मूल दस्तावेज कभी न छोड़ें।',
      rule2Title: 'केवल आधिकारिक केंद्र चुनें',
      rule2Desc: 'केवल आधिकारिक .gov.in वेबसाइट या अधिकृत मीसेवा/सचिवालय का उपयोग करें।',
      rule3Title: 'वर्तनी (Spelling) की जांच करें',
      rule3Desc: 'सबमिट करने से पहले नाम, माता-पिता का नाम, जन्मतिथि और बैंक खाते का मिलान करें।',
      rule4Title: 'ओटीपी कभी साझा न करें',
      rule4Desc: 'ओटीपी, पासवर्ड, एटीएम पिन किसी को न दें। गारंटीड अप्रूवल के नाम पर किसी को पैसे न दें।',
      filterAll: 'सभी श्रेणियां',
      filterBeneficiary: 'सभी लाभार्थी',
      viewDetails: 'विवरण देखें',
      saveScheme: 'सहेजें',
      savedScheme: 'सहेजा गया',
      listenAudio: 'सुनें',
      playingAudio: 'चल रहा है...',
      noResults: 'आपकी खोज के अनुसार कोई योजना नहीं मिली। कृपया फ़िल्टर साफ़ करके पुनः प्रयास करें।',
      clearFilters: 'फ़िल्टर साफ़ करें'
    }
  };

  /* ==========================================================================
     3. APPLICATION STATE & STORAGE HELPERS
     ========================================================================== */

  let currentLang = 'en';
  let activeCategoryFilter = 'all';
  let activeBeneficiaryFilter = 'all';
  let currentSearchQuery = '';
  let currentlyPlayingAudio = null;

  // LocalStorage keys
  const STORAGE_KEYS = {
    SAVED_SCHEMES: 'jansetu_saved_schemes_v1',
    TRACKER: 'jansetu_app_tracker_v1',
    DOC_CHECKLIST: 'jansetu_doc_checklist_v1',
    USER_SESSION: 'jansetu_demo_user_v1',
    LANG: 'jansetu_lang_v1'
  };

  function getStored(key, fallback) {
    try {
      const val = localStorage.getItem(key);
      return val ? JSON.parse(val) : fallback;
    } catch (e) {
      console.warn('LocalStorage read error:', e);
      return fallback;
    }
  }

  function setStored(key, val) {
    try {
      localStorage.setItem(key, JSON.stringify(val));
    } catch (e) {
      console.warn('LocalStorage write error:', e);
    }
  }

  // Pre-seed some default saved schemes if brand new
  let savedSchemes = getStored(STORAGE_KEYS.SAVED_SCHEMES, ['ap-caste-integrated', 'ap-nmms-scholarship', 'pm-kisan']);
  
  // Pre-seed tracker if empty
  let applicationTracker = getStored(STORAGE_KEYS.TRACKER, [
    {
      id: 'track-1',
      schemeId: 'ap-caste-integrated',
      schemeName: 'AP Integrated Certificate (Caste & Nativity)',
      refNo: 'AP-MS-2026-98124',
      dateStarted: '2026-09-15',
      status: 'Ready to Apply',
      notes: 'Collected school TC and father’s caste certificate copy. Going to Grama Sachivalayam tomorrow.'
    },
    {
      id: 'track-2',
      schemeId: 'ap-nmms-scholarship',
      schemeName: 'AP NMMS Scholarship Scheme',
      refNo: 'BSEAP-NMMS-4410',
      dateStarted: '2026-09-20',
      status: 'Preparing Documents',
      notes: 'Need to get latest Tahsildar Income Certificate under 3.5 Lakh.'
    }
  ]);

  // Aggregate document checklist: keys = doc names, value = boolean (isPrepared)
  let preparedDocuments = getStored(STORAGE_KEYS.DOC_CHECKLIST, {
    'Aadhaar Card': true,
    'Passport size photograph': true,
    'SSC Marks Memo or Transfer Certificate (TC)': true,
    'Income Certificate issued by Tahsildar': false,
    'Bank account passbook copy with IFSC': true,
    'Rice Card / Ration Card copy': true,
    'Land revenue record / Pattadar Passbook': false
  });

  // Current demo user state
  let demoUser = getStored(STORAGE_KEYS.USER_SESSION, null);

  /* ==========================================================================
     4. TOAST NOTIFICATIONS
     ========================================================================== */

  function showToast(message, type = 'info') {
    const container = document.getElementById('toast-container');
    if (!container) return;

    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    
    let iconSvg = '';
    if (type === 'success') {
      iconSvg = `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M20 6L9 17l-5-5"/></svg>`;
    } else if (type === 'warning') {
      iconSvg = `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>`;
    } else {
      iconSvg = `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>`;
    }

    toast.innerHTML = `${iconSvg} <span>${escapeHtml(message)}</span>`;
    container.appendChild(toast);

    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateY(10px)';
      setTimeout(() => toast.remove(), 250);
    }, 3500);
  }

  function escapeHtml(str) {
    if (!str) return '';
    return str
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  /* ==========================================================================
     5. TEXT-TO-SPEECH (TTS) ENGINE
     ========================================================================== */

  function speakText(text, btnElement = null) {
    if (!('speechSynthesis' in window)) {
      showToast('Text-to-Speech is not supported in this browser.', 'warning');
      return;
    }

    // If currently speaking this text, stop it
    if (window.speechSynthesis.speaking && currentlyPlayingAudio === text) {
      window.speechSynthesis.cancel();
      currentlyPlayingAudio = null;
      if (btnElement) {
        btnElement.classList.remove('playing');
        btnElement.innerHTML = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><path d="M15.54 8.46a5 5 0 0 1 0 7.07"/><path d="M19.07 4.93a10 10 0 0 1 0 14.14"/></svg> ${I18N[currentLang].listenAudio}`;
      }
      return;
    }

    window.speechSynthesis.cancel();

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 0.95;
    utterance.pitch = 1.0;

    // Pick appropriate language voice if available
    if (currentLang === 'te') {
      utterance.lang = 'te-IN';
    } else if (currentLang === 'hi') {
      utterance.lang = 'hi-IN';
    } else {
      utterance.lang = 'en-IN';
    }

    if (btnElement) {
      btnElement.classList.add('playing');
      btnElement.innerHTML = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="6" y="4" width="4" height="16"/><rect x="14" y="4" width="4" height="16"/></svg> ${I18N[currentLang].playingAudio}`;
    }
    currentlyPlayingAudio = text;

    utterance.onend = () => {
      currentlyPlayingAudio = null;
      if (btnElement) {
        btnElement.classList.remove('playing');
        btnElement.innerHTML = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><path d="M15.54 8.46a5 5 0 0 1 0 7.07"/><path d="M19.07 4.93a10 10 0 0 1 0 14.14"/></svg> ${I18N[currentLang].listenAudio}`;
      }
    };

    utterance.onerror = () => {
      currentlyPlayingAudio = null;
      if (btnElement) {
        btnElement.classList.remove('playing');
        btnElement.innerHTML = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><path d="M15.54 8.46a5 5 0 0 1 0 7.07"/><path d="M19.07 4.93a10 10 0 0 1 0 14.14"/></svg> ${I18N[currentLang].listenAudio}`;
      }
    };

    window.speechSynthesis.speak(utterance);
  }

  /* ==========================================================================
     6. RENDERING SCHEME CARDS & EXPLORER
     ========================================================================== */

  function renderSchemes() {
    const grid = document.getElementById('schemes-grid');
    const emptyState = document.getElementById('empty-schemes-state');
    const countDisplay = document.getElementById('schemes-count');
    if (!grid) return;

    let filtered = SCHEMES_DATA.filter(scheme => {
      // Category filter
      if (activeCategoryFilter !== 'all' && scheme.category !== activeCategoryFilter) {
        return false;
      }

      // Beneficiary filter
      if (activeBeneficiaryFilter !== 'all') {
        const benLower = scheme.beneficiaries.toLowerCase();
        const filtLower = activeBeneficiaryFilter.toLowerCase();
        if (!benLower.includes(filtLower)) {
          return false;
        }
      }

      // Search keyword filter
      if (currentSearchQuery.trim() !== '') {
        const q = currentSearchQuery.toLowerCase().trim();
        const nameMatch = scheme.name.toLowerCase().includes(q);
        const descMatch = scheme.description.toLowerCase().includes(q);
        const catMatch = scheme.category.toLowerCase().includes(q);
        const stateMatch = scheme.state.toLowerCase().includes(q);
        const benMatch = scheme.beneficiaries.toLowerCase().includes(q);
        if (!nameMatch && !descMatch && !catMatch && !stateMatch && !benMatch) {
          return false;
        }
      }

      return true;
    });

    if (countDisplay) {
      countDisplay.textContent = `${filtered.length} ${filtered.length === 1 ? 'Scheme' : 'Schemes'} Found`;
    }

    if (filtered.length === 0) {
      grid.innerHTML = '';
      if (emptyState) emptyState.style.display = 'block';
      return;
    }

    if (emptyState) emptyState.style.display = 'none';

    grid.innerHTML = filtered.map(scheme => {
      const isSaved = savedSchemes.includes(scheme.id);
      const isAP = scheme.state.includes('Andhra Pradesh');

      return `
        <article class="scheme-card" data-id="${scheme.id}">
          <div class="scheme-card-header">
            <div class="scheme-badges">
              <span class="badge ${isAP ? 'badge-ap' : 'badge-state'}">
                <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
                ${scheme.state}
              </span>
              <span class="badge badge-category">${scheme.category}</span>
              ${scheme.verified ? `<span class="badge badge-verified">✓ Official Portal</span>` : `<span class="badge badge-unverified">Demo Info</span>`}
            </div>
            <button class="save-btn ${isSaved ? 'saved' : ''}" data-scheme-id="${scheme.id}" title="${isSaved ? 'Remove from saved' : 'Save scheme'}">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="${isSaved ? 'currentColor' : 'none'}" stroke="currentColor" stroke-width="2">
                <path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/>
              </svg>
            </button>
          </div>

          <h3 class="scheme-title">${scheme.name}</h3>
          <p class="scheme-desc">${scheme.description}</p>

          <div class="scheme-key-meta">
            <div class="meta-row">
              <span class="meta-label">For:</span>
              <span class="meta-val">${scheme.beneficiaries}</span>
            </div>
            <div class="meta-row">
              <span class="meta-label">Key Benefit:</span>
              <span class="meta-val">${scheme.benefits[0]}</span>
            </div>
          </div>

          <div class="scheme-card-actions">
            <button class="btn btn-primary btn-sm view-details-btn" data-scheme-id="${scheme.id}">
              ${I18N[currentLang].viewDetails}
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="9 18 15 12 9 6"/></svg>
            </button>
            <button class="listen-btn scheme-listen-btn" data-text="${escapeHtml(scheme.name + '. ' + scheme.description)}">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><path d="M15.54 8.46a5 5 0 0 1 0 7.07"/><path d="M19.07 4.93a10 10 0 0 1 0 14.14"/></svg>
              ${I18N[currentLang].listenAudio}
            </button>
          </div>
        </article>
      `;
    }).join('');

    // Attach listeners
    grid.querySelectorAll('.view-details-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const id = btn.getAttribute('data-scheme-id');
        openSchemeModal(id);
      });
    });

    grid.querySelectorAll('.save-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const id = btn.getAttribute('data-scheme-id');
        toggleSaveScheme(id, btn);
      });
    });

    grid.querySelectorAll('.scheme-listen-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const text = btn.getAttribute('data-text');
        speakText(text, btn);
      });
    });
  }

  function toggleSaveScheme(schemeId, btnElement = null) {
    const idx = savedSchemes.indexOf(schemeId);
    let isNowSaved = false;
    const scheme = SCHEMES_DATA.find(s => s.id === schemeId);
    const schemeName = scheme ? scheme.name : 'Scheme';

    if (idx > -1) {
      savedSchemes.splice(idx, 1);
      showToast(`Removed "${schemeName}" from saved schemes.`, 'info');
      isNowSaved = false;
    } else {
      savedSchemes.push(schemeId);
      showToast(`Saved "${schemeName}" to your dashboard!`, 'success');
      isNowSaved = true;

      // Also automatically add required documents to aggregate checklist
      if (scheme && scheme.documents) {
        scheme.documents.forEach(doc => {
          if (preparedDocuments[doc] === undefined) {
            preparedDocuments[doc] = false;
          }
        });
        setStored(STORAGE_KEYS.DOC_CHECKLIST, preparedDocuments);
      }
    }

    setStored(STORAGE_KEYS.SAVED_SCHEMES, savedSchemes);
    updateSavedCounter();

    if (btnElement) {
      btnElement.classList.toggle('saved', isNowSaved);
      btnElement.innerHTML = `
        <svg width="18" height="18" viewBox="0 0 24 24" fill="${isNowSaved ? 'currentColor' : 'none'}" stroke="currentColor" stroke-width="2">
          <path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/>
        </svg>
      `;
    }

    // Refresh dashboard saved list if open
    renderDashboardSaved();
    renderChecklist();
  }

  function updateSavedCounter() {
    const countBadge = document.getElementById('saved-badge-count');
    if (countBadge) {
      countBadge.textContent = savedSchemes.length;
    }
  }

  /* ==========================================================================
     7. SCHEME DETAILS MODAL
     ========================================================================== */

  function openSchemeModal(schemeId) {
    const scheme = SCHEMES_DATA.find(s => s.id === schemeId);
    if (!scheme) return;

    const modal = document.getElementById('scheme-details-modal');
    const container = document.getElementById('scheme-modal-content');
    if (!modal || !container) return;

    const isSaved = savedSchemes.includes(scheme.id);
    const audioText = `${scheme.name}. ${scheme.description} Eligibility: ${scheme.eligibility.join('. ')}`;

    container.innerHTML = `
      <div class="modal-header">
        <div>
          <div class="scheme-badges" style="margin-bottom: 6px;">
            <span class="badge ${scheme.state.includes('Andhra Pradesh') ? 'badge-ap' : 'badge-state'}">${scheme.state}</span>
            <span class="badge badge-category">${scheme.category}</span>
            <span class="badge badge-verified">✓ ${scheme.verificationStatus}</span>
          </div>
          <h2 class="modal-title" style="font-size: 1.35rem;">${scheme.name}</h2>
        </div>
        <button class="modal-close-btn" id="close-scheme-modal-btn">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
        </button>
      </div>

      <div class="modal-body">
        <div style="display: flex; gap: 10px; margin-bottom: 20px; flex-wrap: wrap;">
          <button class="btn btn-secondary btn-sm" id="modal-listen-btn">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><path d="M15.54 8.46a5 5 0 0 1 0 7.07"/><path d="M19.07 4.93a10 10 0 0 1 0 14.14"/></svg>
            Listen to Guide
          </button>
          <button class="btn ${isSaved ? 'btn-teal' : 'btn-secondary'} btn-sm" id="modal-save-btn">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="${isSaved ? 'currentColor' : 'none'}" stroke="currentColor" stroke-width="2"><path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/></svg>
            ${isSaved ? 'Saved in Dashboard' : 'Save to Dashboard'}
          </button>
          <button class="btn btn-secondary btn-sm" id="modal-track-btn">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><polyline points="10 9 9 9 8 9"/></svg>
            Track Application
          </button>
        </div>

        <div class="detail-block">
          <p style="font-size: 0.95rem; color: var(--slate-700); line-height: 1.6; margin-bottom: 16px;">${scheme.description}</p>
        </div>

        <div class="detail-block" style="background: var(--slate-50); padding: 14px 18px; border-radius: var(--radius-md); border-left: 4px solid var(--teal-600);">
          <h4 style="margin-bottom: 4px; color: var(--navy-900);">Who is this for?</h4>
          <p style="font-size: 0.88rem; color: var(--slate-700);">${scheme.beneficiaries}</p>
        </div>

        <div class="detail-block">
          <h4>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="var(--teal-600)" stroke-width="2.5"><polyline points="9 11 12 14 22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/></svg>
            Eligibility Criteria
          </h4>
          <ul class="detail-list">
            ${scheme.eligibility.map(item => `<li>${item}</li>`).join('')}
          </ul>
        </div>

        <div class="detail-block">
          <h4>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="var(--saffron-500)" stroke-width="2.5"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
            Benefits & Subsidies
          </h4>
          <ul class="detail-list">
            ${scheme.benefits.map(item => `<li>${item}</li>`).join('')}
          </ul>
        </div>

        <div class="detail-block">
          <h4>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="var(--navy-800)" stroke-width="2.5"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
            Required Documents to Keep Ready
          </h4>
          <ul class="detail-list">
            ${scheme.documents.map(doc => `
              <li style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
                <span>${doc}</span>
                <button class="btn btn-secondary btn-sm add-single-doc-btn" data-doc="${escapeHtml(doc)}" style="padding: 2px 8px; font-size: 0.72rem;">
                  + Add to Checklist
                </button>
              </li>
            `).join('')}
          </ul>
        </div>

        <div class="detail-block">
          <h4>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="var(--emerald-600)" stroke-width="2.5"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
            Step-by-Step Application Procedure
          </h4>
          <ol class="detail-list" style="padding-left: 20px;">
            ${scheme.steps.map(step => `<li style="margin-bottom: 8px;">${step}</li>`).join('')}
          </ol>
        </div>

        <div style="background: #fffbeb; border: 1px solid #fde68a; border-radius: var(--radius-md); padding: 14px; margin-top: 24px; font-size: 0.82rem; color: #92400e; display: flex; gap: 10px; align-items: flex-start;">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#d97706" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
          <div>
            <strong>Independent Informational Guidance:</strong> JanSetu is an educational civic prototype. Rules, fees, and procedures can change. Always verify requirements directly with the relevant department or your local Grama/Ward Sachivalayam before payment.
          </div>
        </div>
      </div>

      <div class="modal-footer">
        <button class="btn btn-secondary" id="modal-close-footer-btn">Close</button>
        <a href="${scheme.officialUrl}" target="_blank" rel="noopener noreferrer" class="btn btn-teal">
          Visit Official Portal
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>
        </a>
      </div>
    `;

    modal.classList.add('open');

    // Modal internal listeners
    const closeBtn = document.getElementById('close-scheme-modal-btn');
    const closeFooter = document.getElementById('modal-close-footer-btn');
    const saveBtn = document.getElementById('modal-save-btn');
    const listenBtn = document.getElementById('modal-listen-btn');
    const trackBtn = document.getElementById('modal-track-btn');

    const closeModal = () => {
      modal.classList.remove('open');
      if (currentlyPlayingAudio) {
        window.speechSynthesis.cancel();
        currentlyPlayingAudio = null;
      }
    };

    if (closeBtn) closeBtn.onclick = closeModal;
    if (closeFooter) closeFooter.onclick = closeModal;

    if (saveBtn) {
      saveBtn.onclick = () => {
        toggleSaveScheme(scheme.id);
        const currentlySaved = savedSchemes.includes(scheme.id);
        saveBtn.className = `btn ${currentlySaved ? 'btn-teal' : 'btn-secondary'} btn-sm`;
        saveBtn.innerHTML = `
          <svg width="15" height="15" viewBox="0 0 24 24" fill="${currentlySaved ? 'currentColor' : 'none'}" stroke="currentColor" stroke-width="2"><path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/></svg>
          ${currentlySaved ? 'Saved in Dashboard' : 'Save to Dashboard'}
        `;
        renderSchemes();
      };
    }

    if (listenBtn) {
      listenBtn.onclick = () => speakText(audioText, listenBtn);
    }

    if (trackBtn) {
      trackBtn.onclick = () => {
        closeModal();
        openTrackerModal(scheme);
      };
    }

    container.querySelectorAll('.add-single-doc-btn').forEach(b => {
      b.onclick = () => {
        const d = b.getAttribute('data-doc');
        preparedDocuments[d] = false;
        setStored(STORAGE_KEYS.DOC_CHECKLIST, preparedDocuments);
        renderChecklist();
        showToast(`Added "${d}" to your Document Checklist!`, 'success');
      };
    });
  }

  /* ==========================================================================
     8. SMART SCHEME FINDER WIZARD
     ========================================================================== */

  let finderCurrentStep = 1;
  const finderResponses = {
    state: 'Andhra Pradesh',
    residence: 'Rural',
    gender: 'Any',
    ageGroup: 'Youth (18-25)',
    socialCategory: 'OBC / BC',
    occupation: 'Student',
    incomeRange: 'Below ₹1,00,000',
    landholding: 'Marginal (< 2.5 acres)'
  };

  function initFinderWizard() {
    const nextBtn = document.getElementById('finder-next-btn');
    const prevBtn = document.getElementById('finder-prev-btn');
    const resetBtn = document.getElementById('finder-reset-btn');

    if (nextBtn) {
      nextBtn.onclick = () => {
        saveFinderStepInputs(finderCurrentStep);
        if (finderCurrentStep < 4) {
          finderCurrentStep++;
          updateFinderUI();
        } else {
          runSchemeMatching();
        }
      };
    }

    if (prevBtn) {
      prevBtn.onclick = () => {
        if (finderCurrentStep > 1) {
          finderCurrentStep--;
          updateFinderUI();
        }
      };
    }

    if (resetBtn) {
      resetBtn.onclick = () => {
        finderCurrentStep = 1;
        document.getElementById('finder-results-section').style.display = 'none';
        document.getElementById('finder-wizard-section').style.display = 'block';
        updateFinderUI();
      };
    }

    // Radio option styling toggles
    document.querySelectorAll('.wizard-card input[type="radio"]').forEach(radio => {
      radio.addEventListener('change', () => {
        const name = radio.name;
        document.querySelectorAll(`input[name="${name}"]`).forEach(r => {
          r.closest('.option-label').classList.toggle('selected', r.checked);
        });
      });
    });
  }

  function saveFinderStepInputs(step) {
    if (step === 1) {
      const stateInput = document.querySelector('input[name="finder-state"]:checked');
      const resInput = document.querySelector('input[name="finder-residence"]:checked');
      if (stateInput) finderResponses.state = stateInput.value;
      if (resInput) finderResponses.residence = resInput.value;
    } else if (step === 2) {
      const ageInput = document.querySelector('input[name="finder-age"]:checked');
      const catInput = document.querySelector('input[name="finder-category"]:checked');
      if (ageInput) finderResponses.ageGroup = ageInput.value;
      if (catInput) finderResponses.socialCategory = catInput.value;
    } else if (step === 3) {
      const occInput = document.querySelector('input[name="finder-occ"]:checked');
      if (occInput) finderResponses.occupation = occInput.value;
    } else if (step === 4) {
      const incInput = document.querySelector('input[name="finder-income"]:checked');
      if (incInput) finderResponses.incomeRange = incInput.value;
    }
  }

  function updateFinderUI() {
    for (let i = 1; i <= 4; i++) {
      const stepElem = document.getElementById(`finder-step-${i}`);
      if (stepElem) {
        stepElem.classList.toggle('active', i === finderCurrentStep);
      }
    }

    const progressFill = document.getElementById('finder-progress-fill');
    const stepIndicator = document.getElementById('finder-step-text');
    const prevBtn = document.getElementById('finder-prev-btn');
    const nextBtn = document.getElementById('finder-next-btn');

    if (progressFill) {
      progressFill.style.width = `${(finderCurrentStep / 4) * 100}%`;
    }
    if (stepIndicator) {
      stepIndicator.textContent = `Step ${finderCurrentStep} of 4`;
    }
    if (prevBtn) {
      prevBtn.style.visibility = finderCurrentStep === 1 ? 'hidden' : 'visible';
    }
    if (nextBtn) {
      nextBtn.textContent = finderCurrentStep === 4 ? 'See Matching Schemes' : 'Next Step';
    }
  }

  function runSchemeMatching() {
    document.getElementById('finder-wizard-section').style.display = 'none';
    const resultsSection = document.getElementById('finder-results-section');
    resultsSection.style.display = 'block';

    const resultsGrid = document.getElementById('finder-matches-grid');
    const summaryText = document.getElementById('finder-summary-text');

    if (summaryText) {
      summaryText.textContent = `Profile: ${finderResponses.state} • ${finderResponses.occupation} • ${finderResponses.socialCategory} • ${finderResponses.incomeRange}`;
    }

    // Match algorithm: compute relevancy score for each scheme
    const scoredSchemes = SCHEMES_DATA.map(scheme => {
      let score = 0;
      let reasons = [];
      let missingInfo = [];

      // State check
      if (finderResponses.state === 'Andhra Pradesh') {
        if (scheme.state.includes('Andhra Pradesh')) {
          score += 35;
          reasons.push('Designed specifically for Andhra Pradesh residents');
        } else {
          score += 20;
          reasons.push('Central government scheme open to AP residents');
        }
      } else {
        if (!scheme.state.includes('Andhra Pradesh')) {
          score += 30;
          reasons.push('National central scheme valid in all states');
        } else {
          missingInfo.push('State-specific AP scheme (requires local domicile)');
        }
      }

      // Occupation check
      const occ = finderResponses.occupation.toLowerCase();
      const ben = scheme.beneficiaries.toLowerCase();
      const cat = scheme.category.toLowerCase();

      if (occ === 'student') {
        if (cat.includes('education') || ben.includes('student')) {
          score += 40;
          reasons.push('Tailored directly for students and education support');
        }
      } else if (occ === 'farmer') {
        if (cat.includes('agriculture') || ben.includes('farmer') || scheme.id.includes('kisan')) {
          score += 45;
          reasons.push('Matches agricultural and farmer landholding benefits');
        }
      } else if (occ === 'unorganized') {
        if (scheme.id === 'eshram-card' || scheme.id === 'atal-pension-yojana' || cat.includes('employment')) {
          score += 40;
          reasons.push('Covers unorganized sector workers and social security');
        }
      } else if (occ === 'vendor') {
        if (scheme.id === 'pm-svanidhi' || cat.includes('entrepreneurship')) {
          score += 45;
          reasons.push('Dedicated micro-credit benefit for street vendors & entrepreneurs');
        }
      } else if (occ === 'disability') {
        if (scheme.id === 'udid-disability') {
          score += 50;
          reasons.push('Official national disability certification & travel benefits');
        }
      } else if (occ === 'senior') {
        if (cat.includes('senior') || scheme.id === 'atal-pension-yojana') {
          score += 40;
          reasons.push('Pension and welfare support for senior citizens');
        }
      }

      // Income check
      const inc = finderResponses.incomeRange;
      if (inc.includes('Below') || inc.includes('1,00,000') || inc.includes('2,50,000')) {
        if (scheme.id === 'ap-rice-card' || scheme.id === 'ayushman-bharat-pmjay' || scheme.id === 'pm-awas-yojana' || scheme.id === 'ap-nmms-scholarship') {
          score += 25;
          reasons.push('Matches priority low-income welfare threshold');
        }
      }

      // Social category check
      const sc = finderResponses.socialCategory;
      if (sc.includes('SC') || sc.includes('ST') || sc.includes('BC') || sc.includes('OBC')) {
        if (scheme.id === 'ap-caste-integrated' || scheme.id === 'ap-nmms-scholarship') {
          score += 25;
          reasons.push('Applies to reserved social welfare and scholarship categories');
        }
      } else if (sc.includes('EWS') || sc.includes('General')) {
        if (scheme.id === 'ap-ews-certificate') {
          score += 30;
          reasons.push('Designed for General Category EWS candidates meeting income & asset criteria');
        }
      }

      // Universal schemes
      if (scheme.id === 'pan-card' || scheme.id === 'voter-id-form6' || scheme.id === 'driving-licence-sarathi' || scheme.id === 'ap-birth-certificate' || scheme.id === 'passport-seva') {
        score += 15;
        reasons.push('Universal identity and vital legal document');
      }

      return {
        scheme,
        score,
        reasons,
        missingInfo
      };
    });

    // Sort descending by match score
    scoredSchemes.sort((a, b) => b.score - a.score);
    const topMatches = scoredSchemes.filter(s => s.score >= 35).slice(0, 6);

    if (resultsGrid) {
      resultsGrid.innerHTML = topMatches.map(m => {
        const s = m.scheme;
        const confidence = m.score >= 60 ? 'High Match' : 'Potential Match';
        const isSaved = savedSchemes.includes(s.id);

        return `
          <div class="scheme-card" style="border-left: 4px solid ${m.score >= 60 ? 'var(--emerald-500)' : 'var(--teal-500)'};">
            <div class="scheme-card-header">
              <div class="scheme-badges">
                <span class="match-relevance-pill">${confidence} (${m.score}%)</span>
                <span class="badge ${s.state.includes('Andhra Pradesh') ? 'badge-ap' : 'badge-state'}">${s.state}</span>
              </div>
              <button class="save-btn ${isSaved ? 'saved' : ''}" data-scheme-id="${s.id}">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="${isSaved ? 'currentColor' : 'none'}" stroke="currentColor" stroke-width="2"><path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/></svg>
              </button>
            </div>

            <h3 class="scheme-title">${s.name}</h3>
            <p class="scheme-desc">${s.description}</p>

            <div style="background: var(--teal-50); border: 1px solid var(--teal-100); border-radius: var(--radius-md); padding: 12px; margin-bottom: 14px; font-size: 0.82rem;">
              <strong style="color: var(--teal-900); display: block; margin-bottom: 4px;">Why this fits you:</strong>
              <ul style="padding-left: 16px; color: var(--teal-900);">
                ${m.reasons.map(r => `<li>${r}</li>`).join('')}
              </ul>
              ${m.missingInfo.length > 0 ? `
                <div style="margin-top: 6px; color: #9a3412;">
                  <strong>Note:</strong> ${m.missingInfo.join(', ')}
                </div>
              ` : ''}
            </div>

            <div class="scheme-card-actions">
              <button class="btn btn-primary btn-sm view-details-btn" data-scheme-id="${s.id}">
                View Details & Checklist
              </button>
              <a href="${s.officialUrl}" target="_blank" rel="noopener noreferrer" class="btn btn-secondary btn-sm">
                Official Portal ↗
              </a>
            </div>
          </div>
        `;
      }).join('');

      // Re-attach listeners for dynamically rendered cards
      resultsGrid.querySelectorAll('.view-details-btn').forEach(b => {
        b.onclick = () => openSchemeModal(b.getAttribute('data-scheme-id'));
      });
      resultsGrid.querySelectorAll('.save-btn').forEach(b => {
        b.onclick = () => toggleSaveScheme(b.getAttribute('data-scheme-id'), b);
      });
    }

    // Scroll smoothly to results
    resultsSection.scrollIntoView({ behavior: 'smooth' });
  }

  /* ==========================================================================
     9. PUBLIC SERVICES DIRECTORY
     ========================================================================== */

  function renderServicesDirectory() {
    const list = document.getElementById('services-list');
    const searchInput = document.getElementById('service-search-input');
    const filterCat = document.getElementById('service-category-filter');
    if (!list) return;

    const query = searchInput ? searchInput.value.toLowerCase().trim() : '';
    const selectedCat = filterCat ? filterCat.value : 'all';

    const filtered = PUBLIC_SERVICES_DATA.filter(srv => {
      if (selectedCat !== 'all' && srv.category !== selectedCat) return false;
      if (query !== '') {
        const n = srv.name.toLowerCase();
        const d = srv.description.toLowerCase();
        const a = srv.audience.toLowerCase();
        const dep = srv.department.toLowerCase();
        if (!n.includes(query) && !d.includes(query) && !a.includes(query) && !dep.includes(query)) {
          return false;
        }
      }
      return true;
    });

    if (filtered.length === 0) {
      list.innerHTML = `
        <div style="text-align: center; padding: 40px; color: var(--slate-500);">
          No official services match your search query. Try another keyword.
        </div>
      `;
      return;
    }

    list.innerHTML = filtered.map(srv => `
      <div class="scheme-card" style="padding: 20px;">
        <div style="display: flex; justify-content: space-between; align-items: flex-start; gap: 10px; margin-bottom: 8px;">
          <div>
            <span class="badge badge-category" style="margin-bottom: 6px;">${srv.category}</span>
            <h3 style="font-size: 1.1rem; font-weight: 700; color: var(--navy-900);">${srv.name}</h3>
            <span style="font-size: 0.78rem; color: var(--slate-500); display: block; margin-top: 2px;">${srv.department}</span>
          </div>
          <span class="badge badge-verified">✓ Official Portal</span>
        </div>
        <p style="font-size: 0.88rem; color: var(--slate-600); line-height: 1.5; margin-bottom: 12px;">${srv.description}</p>
        <div style="font-size: 0.8rem; color: var(--slate-700); margin-bottom: 16px;">
          <strong>Audience:</strong> ${srv.audience}
        </div>
        <div style="margin-top: auto; display: flex; justify-content: space-between; align-items: center;">
          <a href="${srv.url}" target="_blank" rel="noopener noreferrer" class="btn btn-teal btn-sm" style="width: 100%;">
            Visit Official Portal
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>
          </a>
        </div>
      </div>
    `).join('');
  }

  /* ==========================================================================
     10. CITIZEN DASHBOARD: SAVED, TRACKER & CHECKLIST
     ========================================================================== */

  function renderDashboardSaved() {
    const container = document.getElementById('dashboard-saved-grid');
    if (!container) return;

    if (savedSchemes.length === 0) {
      container.innerHTML = `
        <div style="grid-column: 1 / -1; text-align: center; padding: 48px; background: var(--white); border-radius: var(--radius-lg); border: 1px dashed var(--slate-300);">
          <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="var(--slate-400)" stroke-width="1.5" style="margin-bottom: 12px;"><path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/></svg>
          <h4 style="font-size: 1.1rem; color: var(--navy-900); margin-bottom: 6px;">No saved schemes yet</h4>
          <p style="font-size: 0.9rem; color: var(--slate-500); margin-bottom: 16px;">Browse schemes and click the bookmark button to pin them to your personal dashboard.</p>
          <a href="#schemes" class="btn btn-teal btn-sm">Explore Schemes</a>
        </div>
      `;
      return;
    }

    const savedList = SCHEMES_DATA.filter(s => savedSchemes.includes(s.id));

    container.innerHTML = savedList.map(scheme => `
      <div class="scheme-card">
        <div class="scheme-card-header">
          <span class="badge ${scheme.state.includes('Andhra Pradesh') ? 'badge-ap' : 'badge-state'}">${scheme.state}</span>
          <button class="save-btn saved" data-scheme-id="${scheme.id}" title="Remove from saved">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" stroke-width="2"><path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/></svg>
          </button>
        </div>
        <h3 class="scheme-title">${scheme.name}</h3>
        <p class="scheme-desc">${scheme.description}</p>
        <div class="scheme-card-actions">
          <button class="btn btn-primary btn-sm view-details-btn" data-scheme-id="${scheme.id}">View Details</button>
          <button class="btn btn-secondary btn-sm track-this-scheme-btn" data-scheme-id="${scheme.id}">+ Track Application</button>
        </div>
      </div>
    `).join('');

    container.querySelectorAll('.view-details-btn').forEach(b => {
      b.onclick = () => openSchemeModal(b.getAttribute('data-scheme-id'));
    });
    container.querySelectorAll('.save-btn').forEach(b => {
      b.onclick = () => toggleSaveScheme(b.getAttribute('data-scheme-id'), b);
    });
    container.querySelectorAll('.track-this-scheme-btn').forEach(b => {
      b.onclick = () => {
        const s = SCHEMES_DATA.find(x => x.id === b.getAttribute('data-scheme-id'));
        if (s) openTrackerModal(s);
      };
    });
  }

  function renderTrackerTable() {
    const tbody = document.getElementById('tracker-table-body');
    const emptyNotice = document.getElementById('tracker-empty-notice');
    const statusFilter = document.getElementById('tracker-status-filter');
    if (!tbody) return;

    const filterVal = statusFilter ? statusFilter.value : 'all';

    const filtered = applicationTracker.filter(item => {
      if (filterVal !== 'all' && item.status !== filterVal) return false;
      return true;
    });

    if (filtered.length === 0) {
      tbody.innerHTML = '';
      if (emptyNotice) emptyNotice.style.display = 'block';
      return;
    }

    if (emptyNotice) emptyNotice.style.display = 'none';

    tbody.innerHTML = filtered.map(item => {
      const statusClass = item.status.replace(/\s+/g, '-');
      return `
        <tr>
          <td>
            <strong style="color: var(--navy-900); display: block;">${item.schemeName}</strong>
            <span style="font-size: 0.78rem; color: var(--slate-500);">${item.refNo || 'No ref no.'}</span>
          </td>
          <td>${item.dateStarted || '—'}</td>
          <td>
            <select class="form-control tracker-status-select" data-id="${item.id}" style="padding: 4px 8px; font-size: 0.8rem; width: auto; display: inline-block;">
              <option value="Interested" ${item.status === 'Interested' ? 'selected' : ''}>Interested</option>
              <option value="Preparing Documents" ${item.status === 'Preparing Documents' ? 'selected' : ''}>Preparing Documents</option>
              <option value="Ready to Apply" ${item.status === 'Ready to Apply' ? 'selected' : ''}>Ready to Apply</option>
              <option value="Submitted" ${item.status === 'Submitted' ? 'selected' : ''}>Submitted</option>
              <option value="Awaiting Response" ${item.status === 'Awaiting Response' ? 'selected' : ''}>Awaiting Response</option>
              <option value="Completed" ${item.status === 'Completed' ? 'selected' : ''}>Completed</option>
              <option value="Rejected" ${item.status === 'Rejected' ? 'selected' : ''}>Rejected</option>
            </select>
          </td>
          <td style="max-width: 280px; font-size: 0.82rem; color: var(--slate-600);">${item.notes || '—'}</td>
          <td style="text-align: right;">
            <button class="btn btn-ghost btn-sm delete-track-btn" data-id="${item.id}" style="color: #ef4444;" title="Delete Record">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
            </button>
          </td>
        </tr>
      `;
    }).join('');

    tbody.querySelectorAll('.tracker-status-select').forEach(sel => {
      sel.addEventListener('change', () => {
        const id = sel.getAttribute('data-id');
        const newStatus = sel.value;
        const entry = applicationTracker.find(t => t.id === id);
        if (entry) {
          entry.status = newStatus;
          setStored(STORAGE_KEYS.TRACKER, applicationTracker);
          showToast(`Updated status to "${newStatus}"`, 'info');
        }
      });
    });

    tbody.querySelectorAll('.delete-track-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const id = btn.getAttribute('data-id');
        if (confirm('Are you sure you want to delete this application record?')) {
          applicationTracker = applicationTracker.filter(t => t.id !== id);
          setStored(STORAGE_KEYS.TRACKER, applicationTracker);
          renderTrackerTable();
          showToast('Record deleted.', 'info');
        }
      });
    });
  }

  function openTrackerModal(prefillScheme = null) {
    const modal = document.getElementById('tracker-modal');
    if (!modal) return;

    const schemeSelect = document.getElementById('tracker-scheme-select');
    const refInput = document.getElementById('tracker-ref-input');
    const dateInput = document.getElementById('tracker-date-input');
    const statusSelect = document.getElementById('tracker-status-input');
    const notesInput = document.getElementById('tracker-notes-input');

    if (schemeSelect) {
      schemeSelect.innerHTML = SCHEMES_DATA.map(s => `
        <option value="${s.id}" ${prefillScheme && prefillScheme.id === s.id ? 'selected' : ''}>${s.name}</option>
      `).join('');
    }

    if (refInput) refInput.value = '';
    if (dateInput) dateInput.value = new Date().toISOString().split('T')[0];
    if (statusSelect) statusSelect.value = 'Preparing Documents';
    if (notesInput) notesInput.value = '';

    modal.classList.add('open');
  }

  function renderChecklist() {
    const listContainer = document.getElementById('checklist-items');
    const progressBar = document.getElementById('checklist-progress-fill');
    const progressLabel = document.getElementById('checklist-progress-label');
    if (!listContainer) return;

    const docKeys = Object.keys(preparedDocuments);

    if (docKeys.length === 0) {
      listContainer.innerHTML = `<p style="color: var(--slate-500); padding: 12px 0;">No documents added to checklist yet. Save schemes or add documents below.</p>`;
      if (progressBar) progressBar.style.width = '0%';
      if (progressLabel) progressLabel.textContent = '0 / 0 Ready (0%)';
      return;
    }

    let preparedCount = 0;

    listContainer.innerHTML = docKeys.map(doc => {
      const isDone = preparedDocuments[doc] === true;
      if (isDone) preparedCount++;

      return `
        <div class="checklist-item ${isDone ? 'done' : ''}">
          <div class="checklist-left">
            <input type="checkbox" class="doc-checkbox" data-doc="${escapeHtml(doc)}" ${isDone ? 'checked' : ''}>
            <div>
              <span class="doc-title">${doc}</span>
              <span style="font-size: 0.74rem; color: var(--slate-500); display: block;">Carry original + 2-3 attested photocopies</span>
            </div>
          </div>
          <button class="btn btn-ghost btn-sm remove-doc-btn" data-doc="${escapeHtml(doc)}" title="Remove document" style="color: var(--slate-400);">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
          </button>
        </div>
      `;
    }).join('');

    const pct = Math.round((preparedCount / docKeys.length) * 100);
    if (progressBar) progressBar.style.width = `${pct}%`;
    if (progressLabel) progressLabel.textContent = `${preparedCount} of ${docKeys.length} Ready (${pct}%)`;

    // Attach listeners
    listContainer.querySelectorAll('.doc-checkbox').forEach(cb => {
      cb.addEventListener('change', () => {
        const d = cb.getAttribute('data-doc');
        preparedDocuments[d] = cb.checked;
        setStored(STORAGE_KEYS.DOC_CHECKLIST, preparedDocuments);
        renderChecklist();
        if (cb.checked) {
          showToast(`Marked "${d}" as prepared!`, 'success');
        }
      });
    });

    listContainer.querySelectorAll('.remove-doc-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const d = btn.getAttribute('data-doc');
        delete preparedDocuments[d];
        setStored(STORAGE_KEYS.DOC_CHECKLIST, preparedDocuments);
        renderChecklist();
        showToast(`Removed "${d}" from checklist.`, 'info');
      });
    });
  }

  /* ==========================================================================
     11. JANSETU FAQ HELP ASSISTANT (CHATBOT)
     ========================================================================== */

  const FAQ_KNOWLEDGE_BASE = [
    {
      keywords: ['caste', 'integrated', 'community', 'nativity'],
      reply: 'In Andhra Pradesh, the Integrated Certificate covers Caste/Community, Nativity, and Date of Birth in one document. You need your SSC marks memo or School Transfer Certificate (TC), parent’s previous caste certificate, and Aadhaar card. Apply through the Grama/Ward Sachivalayam or AP Seva portal. Verification is conducted by the VRO and RI before approval by the Tahsildar.'
    },
    {
      keywords: ['nmms', 'scholarship', 'school', '8th', 'class 8'],
      reply: 'The National Means-cum-Merit Scholarship Scheme (NMMS) is for Class VIII students studying in AP Government, Zilla Parishad, Municipal, and Aided schools. Selection is via a state exam conducted by BSE AP (Directorate of Government Examinations). Selected students receive ₹12,000/year (₹1,000/month) through DBT on the National Scholarship Portal (NSP). Parental annual income must be under ₹3.5 Lakh.'
    },
    {
      keywords: ['rice card', 'ration card', 'food', 'ration'],
      reply: 'Andhra Pradesh Rice Cards are household-based and issued to families with monthly income under ₹10,000 (rural) or ₹12,000 (urban), owning less than 3 acres wetland / 10 acres dry land, and consuming under 300 electricity units. Apply or request modifications through your Village/Ward Volunteer and Sachivalayam Welfare Assistant.'
    },
    {
      keywords: ['income', 'income certificate', 'tahsildar'],
      reply: 'AP Income Certificates certify annual household income and are required for scholarships (AP Jnanabhumi, NSP) and fee reimbursements. Valid for one financial year. Keep Aadhaar, Rice Card, electricity bill, and salary proof or affidavit ready before applying at MeeSeva.'
    },
    {
      keywords: ['birth', 'delayed', 'non-availability', 'nac'],
      reply: 'For a Birth Certificate: First contact the local Registrar/Municipality/Gram Panchayat where the birth occurred to search the register. If not registered within 1 year, you must obtain a Non-Availability Certificate (NAC) and apply for delayed registration via Magistrate/RDO enquiry with hospital and school records.'
    },
    {
      keywords: ['ews', 'general', 'asset'],
      reply: 'The EWS Income and Asset Certificate is for General category applicants not covered under SC/ST/BC reservations. Gross annual family income must be below ₹8 Lakh, with agricultural land under 5 acres and residential flat under 1000 sq ft. It grants 10% reservation in central and state education admissions and jobs.'
    },
    {
      keywords: ['precaution', 'safety', 'otp', 'scam', 'middleman'],
      reply: 'Safety Checklist: 1) Never share OTPs, passwords, or bank PINs with anyone. 2) Only use official .gov.in websites or authorized MeeSeva/Sachivalayam offices. 3) Check spellings of your name and DOB against Aadhaar before pressing Submit. 4) Never pay anyone promising "guaranteed approval". 5) Carry originals and 2-3 photocopies.'
    },
    {
      keywords: ['tracker', 'track', 'status', 'dashboard'],
      reply: 'To track applications in JanSetu, click "My Dashboard" in the navigation bar. You can add your MeeSeva token or application reference number, choose status (e.g., Preparing Documents, Submitted, Awaiting Response), and take personal notes. Note: This saves privately in your browser local storage.'
    },
    {
      keywords: ['kisan', 'farmer', 'pm-kisan', 'land'],
      reply: 'PM-KISAN provides ₹6,000/year in 3 DBT instalments of ₹2,000 for landholder farmers. In Andhra Pradesh, farmers also register through Rythu Bharosa Kendras (RBKs) for seasonal e-Crop booking and free crop insurance linked with Webland records.'
    }
  ];

  function initHelpAssistant() {
    const toggleBtn = document.getElementById('assistant-toggle-btn');
    const panel = document.getElementById('assistant-panel');
    const closeBtn = document.getElementById('assistant-close-btn');
    const input = document.getElementById('assistant-input');
    const sendBtn = document.getElementById('assistant-send-btn');
    const msgContainer = document.getElementById('assistant-messages');

    if (!panel || !toggleBtn) return;

    toggleBtn.onclick = () => panel.classList.toggle('open');
    if (closeBtn) closeBtn.onclick = () => panel.classList.remove('open');

    function sendQuery(text) {
      if (!text || text.trim() === '') return;

      // Add user message
      const userDiv = document.createElement('div');
      userDiv.className = 'chat-msg user';
      userDiv.textContent = text;
      msgContainer.appendChild(userDiv);
      msgContainer.scrollTop = msgContainer.scrollHeight;

      // Clean input
      if (input) input.value = '';

      // Match answer
      const q = text.toLowerCase();
      let matchedReply = null;

      for (const item of FAQ_KNOWLEDGE_BASE) {
        if (item.keywords.some(k => q.includes(k))) {
          matchedReply = item.reply;
          break;
        }
      }

      if (!matchedReply) {
        matchedReply = "I couldn't find an exact match for that query. You can ask about AP Caste Certificates, NMMS Scholarship, Rice Cards, Income Certificates, EWS, Birth Registration, or Safety precautions. You can also explore our Schemes directory or visit official government portals directly.";
      }

      // Simulate slight bot typing delay
      setTimeout(() => {
        const botDiv = document.createElement('div');
        botDiv.className = 'chat-msg bot';
        botDiv.innerHTML = `
          <div>${matchedReply}</div>
          <button class="listen-btn bot-tts-btn" style="margin-top: 8px; font-size: 0.72rem; padding: 3px 8px;">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><path d="M15.54 8.46a5 5 0 0 1 0 7.07"/></svg>
            Listen
          </button>
        `;
        msgContainer.appendChild(botDiv);
        msgContainer.scrollTop = msgContainer.scrollHeight;

        const ttsBtn = botDiv.querySelector('.bot-tts-btn');
        if (ttsBtn) {
          ttsBtn.onclick = () => speakText(matchedReply, ttsBtn);
        }
      }, 300);
    }

    if (sendBtn && input) {
      sendBtn.onclick = () => sendQuery(input.value);
      input.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') sendQuery(input.value);
      });
    }

    document.querySelectorAll('.assistant-quick-chip').forEach(chip => {
      chip.addEventListener('click', () => {
        const text = chip.getAttribute('data-query');
        sendQuery(text);
      });
    });
  }

  /* ==========================================================================
     12. DEMO LOGIN & REGISTRATION
     ========================================================================== */

  function initAuthModal() {
    const modal = document.getElementById('login-modal');
    const openBtns = document.querySelectorAll('.open-login-btn');
    const closeBtn = document.getElementById('close-login-btn');
    const loginTab = document.getElementById('tab-login-btn');
    const regTab = document.getElementById('tab-register-btn');
    const loginForm = document.getElementById('demo-login-form');
    const regForm = document.getElementById('demo-register-form');
    const userDisplay = document.getElementById('nav-user-display');

    if (!modal) return;

    openBtns.forEach(b => {
      b.onclick = () => {
        if (demoUser) {
          if (confirm(`Logged in as ${demoUser.name}. Do you want to sign out?`)) {
            demoUser = null;
            setStored(STORAGE_KEYS.USER_SESSION, null);
            updateUserNav();
            showToast('Signed out of demo session.', 'info');
          }
        } else {
          modal.classList.add('open');
        }
      };
    });

    if (closeBtn) closeBtn.onclick = () => modal.classList.remove('open');

    if (loginTab && regTab) {
      loginTab.onclick = () => {
        loginTab.classList.add('active');
        regTab.classList.remove('active');
        loginForm.style.display = 'block';
        regForm.style.display = 'none';
      };
      regTab.onclick = () => {
        regTab.classList.add('active');
        loginTab.classList.remove('active');
        loginForm.style.display = 'none';
        regForm.style.display = 'block';
      };
    }

    if (loginForm) {
      loginForm.onsubmit = (e) => {
        e.preventDefault();
        const email = document.getElementById('login-email').value;
        demoUser = {
          name: email.split('@')[0] || 'Citizen',
          email: email
        };
        setStored(STORAGE_KEYS.USER_SESSION, demoUser);
        updateUserNav();
        modal.classList.remove('open');
        showToast(`Welcome back, ${demoUser.name}! (Demo Mode)`, 'success');
      };
    }

    if (regForm) {
      regForm.onsubmit = (e) => {
        e.preventDefault();
        const name = document.getElementById('reg-name').value;
        const email = document.getElementById('reg-email').value;
        demoUser = {
          name: name || 'Citizen',
          email: email
        };
        setStored(STORAGE_KEYS.USER_SESSION, demoUser);
        updateUserNav();
        modal.classList.remove('open');
        showToast(`Account profile created for ${name}! (Demo Mode)`, 'success');
      };
    }

    function updateUserNav() {
      if (!userDisplay) return;
      if (demoUser) {
        userDisplay.innerHTML = `
          <div style="display: flex; align-items: center; gap: 8px;">
            <span style="font-size: 0.85rem; font-weight: 600; color: var(--navy-900);">Namaste, ${demoUser.name}</span>
            <button class="btn btn-ghost btn-sm open-login-btn" style="padding: 4px 8px; font-size: 0.75rem;">(Sign Out)</button>
          </div>
        `;
        userDisplay.querySelector('.open-login-btn').onclick = () => {
          demoUser = null;
          setStored(STORAGE_KEYS.USER_SESSION, null);
          updateUserNav();
          showToast('Signed out of demo session.', 'info');
        };
      } else {
        userDisplay.innerHTML = `
          <button class="btn btn-secondary btn-sm open-login-btn">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
            Demo Login
          </button>
        `;
        userDisplay.querySelector('.open-login-btn').onclick = () => modal.classList.add('open');
      }
    }

    updateUserNav();
  }

  /* ==========================================================================
     13. LANGUAGE TRANSLATION SWITCHER
     ========================================================================== */

  function setLanguage(lang) {
    if (!I18N[lang]) return;
    currentLang = lang;
    setStored(STORAGE_KEYS.LANG, lang);

    document.querySelectorAll('.lang-btn').forEach(btn => {
      btn.classList.toggle('active', btn.getAttribute('data-lang') === lang);
    });

    // Update static translatable nodes
    document.querySelectorAll('[data-i18n]').forEach(elem => {
      const key = elem.getAttribute('data-i18n');
      if (I18N[lang][key]) {
        elem.textContent = I18N[lang][key];
      }
    });

    // Update search placeholders
    const searchInputs = document.querySelectorAll('#hero-search-input, #main-scheme-search');
    searchInputs.forEach(inp => {
      inp.placeholder = I18N[lang].searchPlaceholder;
    });

    renderSchemes();
  }

  /* ==========================================================================
     14. INITIALIZATION & EVENT LISTENERS
     ========================================================================== */

  document.addEventListener('DOMContentLoaded', () => {
    // 1. Language Init
    const savedLang = getStored(STORAGE_KEYS.LANG, 'en');
    setLanguage(savedLang);

    document.querySelectorAll('.lang-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        setLanguage(btn.getAttribute('data-lang'));
      });
    });

    // 2. Mobile Nav Toggle
    const mobileBtn = document.getElementById('mobile-menu-toggle-btn');
    const navLinks = document.getElementById('nav-links-menu');
    if (mobileBtn && navLinks) {
      mobileBtn.onclick = () => navLinks.classList.toggle('mobile-open');
      navLinks.querySelectorAll('a').forEach(a => {
        a.onclick = () => navLinks.classList.remove('mobile-open');
      });
    }

    // 3. Search & Category Filters
    const heroSearchInput = document.getElementById('hero-search-input');
    const heroSearchBtn = document.getElementById('hero-search-btn');
    const mainSearchInput = document.getElementById('main-scheme-search');
    const benSelect = document.getElementById('scheme-beneficiary-filter');
    const clearFiltersBtn = document.getElementById('clear-filters-btn');

    if (heroSearchBtn && heroSearchInput) {
      heroSearchBtn.onclick = () => {
        currentSearchQuery = heroSearchInput.value;
        if (mainSearchInput) mainSearchInput.value = currentSearchQuery;
        renderSchemes();
        const schemesSection = document.getElementById('schemes');
        if (schemesSection) schemesSection.scrollIntoView({ behavior: 'smooth' });
      };
      heroSearchInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') heroSearchBtn.click();
      });
    }

    if (mainSearchInput) {
      mainSearchInput.addEventListener('input', () => {
        currentSearchQuery = mainSearchInput.value;
        renderSchemes();
      });
    }

    if (benSelect) {
      benSelect.addEventListener('change', () => {
        activeBeneficiaryFilter = benSelect.value;
        renderSchemes();
      });
    }

    if (clearFiltersBtn) {
      clearFiltersBtn.onclick = () => {
        activeCategoryFilter = 'all';
        activeBeneficiaryFilter = 'all';
        currentSearchQuery = '';
        if (mainSearchInput) mainSearchInput.value = '';
        if (heroSearchInput) heroSearchInput.value = '';
        if (benSelect) benSelect.value = 'all';
        document.querySelectorAll('.category-card').forEach(c => c.classList.remove('active'));
        renderSchemes();
      };
    }

    // Category Cards Clicks
    document.querySelectorAll('.category-card').forEach(card => {
      card.addEventListener('click', (e) => {
        e.preventDefault();
        const cat = card.getAttribute('data-category');
        if (activeCategoryFilter === cat) {
          activeCategoryFilter = 'all';
          card.classList.remove('active');
        } else {
          activeCategoryFilter = cat;
          document.querySelectorAll('.category-card').forEach(c => c.classList.remove('active'));
          card.classList.add('active');
        }
        renderSchemes();
        const schemesElem = document.getElementById('schemes');
        if (schemesElem) schemesElem.scrollIntoView({ behavior: 'smooth' });
      });
    });

    // 4. Dashboard Tabs
    document.querySelectorAll('.dashboard-tab-btn').forEach(tab => {
      tab.addEventListener('click', () => {
        document.querySelectorAll('.dashboard-tab-btn').forEach(t => t.classList.remove('active'));
        document.querySelectorAll('.dashboard-pane').forEach(p => p.style.display = 'none');

        tab.classList.add('active');
        const target = tab.getAttribute('data-target');
        const pane = document.getElementById(target);
        if (pane) pane.style.display = 'block';
      });
    });

    // 5. Application Tracker Controls
    const addTrackerBtn = document.getElementById('add-tracker-entry-btn');
    const trackerForm = document.getElementById('tracker-form');
    const closeTrackerModalBtn = document.getElementById('close-tracker-modal-btn');
    const cancelTrackerBtn = document.getElementById('cancel-tracker-btn');
    const trackerFilter = document.getElementById('tracker-status-filter');

    if (addTrackerBtn) addTrackerBtn.onclick = () => openTrackerModal();
    if (closeTrackerModalBtn) {
      closeTrackerModalBtn.onclick = () => document.getElementById('tracker-modal').classList.remove('open');
    }
    if (cancelTrackerBtn) {
      cancelTrackerBtn.onclick = () => document.getElementById('tracker-modal').classList.remove('open');
    }

    if (trackerForm) {
      trackerForm.onsubmit = (e) => {
        e.preventDefault();
        const sId = document.getElementById('tracker-scheme-select').value;
        const sObj = SCHEMES_DATA.find(x => x.id === sId);
        const newRecord = {
          id: 'track-' + Date.now(),
          schemeId: sId,
          schemeName: sObj ? sObj.name : 'Government Scheme',
          refNo: document.getElementById('tracker-ref-input').value.trim() || '—',
          dateStarted: document.getElementById('tracker-date-input').value,
          status: document.getElementById('tracker-status-input').value,
          notes: document.getElementById('tracker-notes-input').value.trim()
        };

        applicationTracker.unshift(newRecord);
        setStored(STORAGE_KEYS.TRACKER, applicationTracker);
        document.getElementById('tracker-modal').classList.remove('open');
        renderTrackerTable();
        showToast('Application record saved to your dashboard tracker!', 'success');
      };
    }

    if (trackerFilter) {
      trackerFilter.addEventListener('change', renderTrackerTable);
    }

    // 6. Checklist Custom Add & Reset
    const addCustomDocForm = document.getElementById('add-custom-doc-form');
    const resetChecklistBtn = document.getElementById('reset-checklist-btn');

    if (addCustomDocForm) {
      addCustomDocForm.onsubmit = (e) => {
        e.preventDefault();
        const input = document.getElementById('custom-doc-name');
        if (input && input.value.trim() !== '') {
          const docName = input.value.trim();
          preparedDocuments[docName] = false;
          setStored(STORAGE_KEYS.DOC_CHECKLIST, preparedDocuments);
          input.value = '';
          renderChecklist();
          showToast(`Added "${docName}" to your checklist!`, 'success');
        }
      };
    }

    if (resetChecklistBtn) {
      resetChecklistBtn.onclick = () => {
        if (confirm('Reset all document checklist statuses?')) {
          Object.keys(preparedDocuments).forEach(k => preparedDocuments[k] = false);
          setStored(STORAGE_KEYS.DOC_CHECKLIST, preparedDocuments);
          renderChecklist();
          showToast('Document checklist reset.', 'info');
        }
      };
    }

    // 7. Services Directory Search & Filter
    const srvSearch = document.getElementById('service-search-input');
    const srvCat = document.getElementById('service-category-filter');
    if (srvSearch) srvSearch.addEventListener('input', renderServicesDirectory);
    if (srvCat) srvCat.addEventListener('change', renderServicesDirectory);

    // 8. FAQ Accordions
    document.querySelectorAll('.faq-question').forEach(btn => {
      btn.addEventListener('click', () => {
        const card = btn.closest('.faq-card');
        const isOpen = card.classList.contains('open');
        document.querySelectorAll('.faq-card').forEach(c => c.classList.remove('open'));
        if (!isOpen) card.classList.add('open');
      });
    });

    // 9. Initial Subsystem Boots
    renderSchemes();
    updateSavedCounter();
    renderDashboardSaved();
    renderTrackerTable();
    renderChecklist();
    renderServicesDirectory();
    initFinderWizard();
    initHelpAssistant();
    initAuthModal();

    // 10. Close Modals on Overlay Click
    document.querySelectorAll('.modal-overlay').forEach(overlay => {
      overlay.addEventListener('click', (e) => {
        if (e.target === overlay) {
          overlay.classList.remove('open');
          if (currentlyPlayingAudio) {
            window.speechSynthesis.cancel();
            currentlyPlayingAudio = null;
          }
        }
      });
    });
  });

})();
