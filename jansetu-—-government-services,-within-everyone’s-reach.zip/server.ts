import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json({ limit: '20mb' }));

// Groq & Gemini Client Configuration
const GROQ_API_KEY = process.env.GROQ_API_KEY || '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';
const GEMINI_API_KEY = process.env.GEMINI_API_KEY;

let geminiAi: GoogleGenAI | null = null;
if (GEMINI_API_KEY) {
  geminiAi = new GoogleGenAI({
    apiKey: GEMINI_API_KEY,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

const SYSTEM_INSTRUCTION = `You are JanSetu AI, an expert Senior Government Schemes & Official Portals Counselor for India and Andhra Pradesh.
Your mission is to guide citizens, explain government welfare programs, suggest the best possible alternative schemes and options across different government departments and portals, and get every official portal ready for the user.

You have comprehensive knowledge of:
1. Andhra Pradesh State Portals:
   - AP Seva Portal (VSWS - https://vsws.ap.gov.in/): Integrated Caste, Nativity, Rice Card, Grama/Ward Sachivalayam services.
   - AP MeeSeva (https://onlineap.meeseva.gov.in/): Income Certificate, EWS Certificate, Birth Certificate, Residence Certificate.
   - AP Jnanabhumi (https://jnanabhumi.ap.gov.in/): Jagananna Vidya Deevena (full tuition fee reimbursement) & Vasathi Deevena.
   - BSE AP (https://bse.ap.gov.in/): NMMS Scholarship, Duplicate SSC Marks Memo, Migration.
   - BIE AP (https://bie.ap.gov.in/): Intermediate Marks Memos, Equivalency, Migration.
   - Dr. YSR Aarogyasri Trust (https://ysraarogyasri.ap.gov.in/): Free cashless healthcare up to 5 Lakhs.
   - AP e-Panta / e-Crop & Rythu Seva Kendram: Crop booking, input subsidy, tenant farmer CCPA.
   - AP Spandana (https://spandana.ap.gov.in/): Grievance redressal with District Collectors.

2. Central / National Portals:
   - National Scholarship Portal (https://scholarships.gov.in/): Pre-Matric, Post-Matric, CSSS, Merit-cum-Means.
   - PM-KISAN (https://pmkisan.gov.in/): ₹6,000/year farmer DBT.
   - NHA Ayushman Bharat (https://beneficiary.nha.gov.in/): PM-JAY Golden Card.
   - UIDAI MyAadhaar (https://myaadhaar.uidai.gov.in/): Enrolment, Address Update, PVC Card.
   - Election Commission of India (https://voters.eci.gov.in/): Voter ID Form 6, Form 8, e-EPIC download.
   - Protean / UTIITSL (https://www.onlineservices.nsdl.com/paam/endUserRegisterContact.html): Instant e-PAN, PAN Card 49A.
   - MoRTH Parivahan Sarathi (https://sarathi.parivahan.gov.in/): Online LLR test from home, DL Driving Test.
   - e-Shram Portal (https://eshram.gov.in/): UAN Card for unorganized workers with ₹2 Lakh accident insurance.
   - Swavlamban UDID (https://www.swavlambancard.gov.in/): Unique Disability ID, SADAREM.

When answering:
1. Provide a direct, empathetic, and clear response.
2. Outline the exact eligibility criteria and document checklist.
3. Crucially, proactively suggest OTHER POSSIBLE BEST OPTIONS or cross-department applications the user can also benefit from (e.g. if a student asks about caste/income certificates, immediately tell them about Vidya Deevena fee reimbursement on Jnanabhumi and NMMS/NSP scholarships; if a farmer asks about PM-KISAN, suggest AP e-Crop booking and Rythu Bharosa).
4. Provide structured portal actions so the frontend can display interactive "Launch Official Portal" and "Open in Studio" action cards!
Include links in markdown format [Portal Name](https://...) and clearly list the verified portal name, official fee, and required documents.
Never promise guaranteed approvals; always emphasize zero OTP sharing and official verification.
Respond in English, Telugu (తెలుగు), or Hindi (हिन्दी) based on user prompt language.`;

// High-performance Groq LPU completion runner
async function runGroqChat(
  messages: Array<{ role: string; content: string }>,
  modelPreference: string = 'openai/gpt-oss-120b',
  systemOverride?: string
) {
  const startTime = Date.now();
  const candidateModels = [modelPreference, 'openai/gpt-oss-20b', 'qwen/qwen3.8-27b'];

  let lastError: any = null;

  for (const model of candidateModels) {
    try {
      const formattedMessages = [
        { role: 'system', content: systemOverride || SYSTEM_INSTRUCTION },
        ...messages.map((m) => ({
          role: m.role === 'model' || m.role === 'assistant' ? 'assistant' : 'user',
          content: m.content,
        })),
      ];

      const resp = await fetch('https://api.groq.com/openai/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${GROQ_API_KEY}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model,
          messages: formattedMessages,
          temperature: 0.6,
          max_tokens: 2048,
        }),
      });

      if (!resp.ok) {
        const errText = await resp.text();
        console.warn(`Groq model ${model} failed (${resp.status}): ${errText}`);
        lastError = new Error(errText);
        continue;
      }

      const data = await resp.json();
      const reply =
        data.choices?.[0]?.message?.content ||
        data.choices?.[0]?.message?.reasoning ||
        '';

      if (reply) {
        const latencyMs = Date.now() - startTime;
        return {
          reply,
          latencyMs,
          model,
          provider: 'Groq LPU',
          tokens: data.usage?.total_tokens || 0,
        };
      }
    } catch (err) {
      console.warn(`Groq model ${model} attempt error:`, err);
      lastError = err;
    }
  }

  throw lastError || new Error('All Groq models failed');
}

// Fallback to Gemini if needed
async function runGeminiChat(messages: Array<{ role: string; content: string }>) {
  if (!geminiAi) {
    throw new Error('Gemini API key is not configured');
  }

  const startTime = Date.now();
  const contents = messages.map((m) => ({
    role: m.role === 'assistant' ? 'model' : 'user',
    parts: [{ text: m.content }],
  }));

  const response = await geminiAi.models.generateContent({
    model: 'gemini-3.5-flash',
    contents,
    config: {
      systemInstruction: SYSTEM_INSTRUCTION,
      temperature: 0.7,
    },
  });

  const reply = response.text || 'Unable to generate response at this time.';
  return {
    reply,
    latencyMs: Date.now() - startTime,
    model: 'gemini-3.5-flash',
    provider: 'Google Gemini',
  };
}

// API Route: AI Status Check
app.get('/api/ai-status', (_req, res) => {
  res.json({
    groqConfigured: Boolean(GROQ_API_KEY),
    geminiConfigured: Boolean(GEMINI_API_KEY),
    provider: GROQ_API_KEY ? 'Groq LPU (Ultra-Fast)' : (GEMINI_API_KEY ? 'Google Gemini' : 'Offline'),
    primaryModel: 'openai/gpt-oss-120b',
    fastModel: 'openai/gpt-oss-20b',
    multilingualModel: 'qwen/qwen3.8-27b',
    speed: '~250-800 tokens/sec',
    status: 'Operational',
  });
});

// API Route: Multi-turn Chat with Groq LPU & Gemini fallback
app.post('/api/chat', async (req, res) => {
  try {
    const { messages, model } = req.body;
    if (!messages || !Array.isArray(messages)) {
      return res.status(400).json({ error: 'Missing or invalid messages array' });
    }

    // Prioritize Groq with the user's API key
    if (GROQ_API_KEY) {
      try {
        const groqResult = await runGroqChat(messages, model || 'openai/gpt-oss-120b');
        return res.json(groqResult);
      } catch (groqErr: any) {
        console.warn('Groq failed, attempting Gemini fallback:', groqErr?.message);
      }
    }

    // Gemini fallback
    if (geminiAi) {
      const geminiResult = await runGeminiChat(messages);
      return res.json(geminiResult);
    }

    return res.status(500).json({
      error: 'AI service temporarily unavailable. Please verify API keys in server configuration.',
    });
  } catch (error: any) {
    console.error('Error in /api/chat:', error);
    res.status(500).json({
      error: error.message || 'An error occurred while generating counsel.',
    });
  }
});

// API Route: Voice Conversation / Real-time Voice Counsel
app.post('/api/voice-chat', async (req, res) => {
  try {
    const { message, lang = 'en' } = req.body;
    if (!message || typeof message !== 'string') {
      return res.status(400).json({ error: 'Missing or invalid message string' });
    }

    let replyText = '';
    let latencyMs = 0;
    let provider = 'Groq LPU';

    const voicePrompt = `The user spoke: "${message}". Please respond directly in a conversational, helpful voice persona for spoken conversation. Explain the best government scheme options, which official portal to use, and what documents are required. Keep it concise (under 120 words) suitable for speech narration in language: ${lang}.`;

    // Use Groq ultra-fast model (openai/gpt-oss-20b) for instant sub-200ms voice counsel
    if (GROQ_API_KEY) {
      try {
        const startTime = Date.now();
        const groqResult = await runGroqChat(
          [{ role: 'user', content: voicePrompt }],
          'openai/gpt-oss-20b'
        );
        replyText = groqResult.reply;
        latencyMs = Date.now() - startTime;
      } catch (err) {
        console.warn('Groq voice generation error, falling back to Gemini:', err);
      }
    }

    if (!replyText && geminiAi) {
      const startTime = Date.now();
      const textResponse = await geminiAi.models.generateContent({
        model: 'gemini-3.5-flash',
        contents: [
          {
            role: 'user',
            parts: [{ text: voicePrompt }],
          },
        ],
        config: {
          systemInstruction: SYSTEM_INSTRUCTION,
          temperature: 0.7,
        },
      });
      replyText = textResponse.text || '';
      latencyMs = Date.now() - startTime;
      provider = 'Google Gemini';
    }

    if (!replyText) {
      replyText = 'Welcome to JanSetu. You can explore state welfare schemes, certificates, and central scholarships using our portal directory.';
    }

    // Audio synthesis via Gemini TTS if configured (with 1.5s timeout race so voice never hangs), or client will use native browser speech synthesis
    let audioBase64: string | null = null;
    if (geminiAi) {
      try {
        const voiceName = lang === 'te' || lang === 'hi' ? 'Kore' : 'Zephyr';
        const ttsPromise = geminiAi.models.generateContent({
          model: 'gemini-3.8-flash-lite-tts',
          contents: [
            {
              role: 'user',
              parts: [{ text: replyText }],
            },
          ],
          config: {
            responseModalities: ['AUDIO'],
            speechConfig: {
              voiceConfig: {
                prebuiltVoiceConfig: { voiceName },
              },
            },
          },
        });

        const timeoutPromise = new Promise<null>((resolve) => setTimeout(() => resolve(null), 1500));
        const speechResponse: any = await Promise.race([ttsPromise, timeoutPromise]);

        if (speechResponse) {
          audioBase64 =
            speechResponse.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data || null;
        }
      } catch (ttsErr) {
        // Fallback to browser SpeechSynthesis
      }
    }

    res.json({
      reply: replyText,
      audioBase64,
      latencyMs,
      provider,
    });
  } catch (error: any) {
    console.error('Error in /api/voice-chat:', error);
    res.status(500).json({
      error: error.message || 'Voice generation failed.',
    });
  }
});

// Mount Vite in development or serve static in production
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, () => {
    console.log(`JanSetu full-stack server running on http://localhost:${PORT}`);
  });
}

startServer();
